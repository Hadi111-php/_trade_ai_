import { NextResponse } from "next/server";
import { db } from "@/db";
import { trades, virtualWallets, botConfigs } from "@/db/schema";
import { eq } from "drizzle-orm";

export async function POST() {
  try {
    // Close all open trades
    await db
      .update(trades)
      .set({ status: "CANCELLED", closedAt: new Date(), closedReason: "Manual reset" })
      .where(eq(trades.status, "OPEN"));

    // Reset wallet
    await db
      .update(virtualWallets)
      .set({
        currentBalance: "10000",
        totalPnl: "0",
        totalPnlPercent: "0",
        winCount: 0,
        lossCount: 0,
        totalTrades: 0,
        updatedAt: new Date(),
      })
      .where(eq(virtualWallets.id, 1));

    // Stop bot
    await db
      .update(botConfigs)
      .set({ isRunning: false, updatedAt: new Date() })
      .where(eq(botConfigs.walletId, 1));

    return NextResponse.json({ success: true, message: "Wallet reset to 10,000 USDT" });
  } catch (err) {
    console.error("Reset error:", err);
    return NextResponse.json({ error: "Reset failed" }, { status: 500 });
  }
}
