import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { botConfigs } from "@/db/schema";
import { eq } from "drizzle-orm";
import { getOrCreateBotConfig } from "@/lib/tradeEngine";

export async function GET() {
  try {
    const config = await getOrCreateBotConfig(1);
    return NextResponse.json({ config });
  } catch (err) {
    console.error("Config GET error:", err);
    return NextResponse.json({ error: "Failed to get config" }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const config = await getOrCreateBotConfig(1);

    const [updated] = await db
      .update(botConfigs)
      .set({
        isRunning: body.isRunning ?? config.isRunning,
        symbol: body.symbol ?? config.symbol,
        timeframe: body.timeframe ?? config.timeframe,
        leverage: body.leverage ?? config.leverage,
        riskPerTrade: body.riskPerTrade?.toString() ?? config.riskPerTrade,
        maxOpenTrades: body.maxOpenTrades ?? config.maxOpenTrades,
        strategy: body.strategy ?? config.strategy,
        autoSl: body.autoSl ?? config.autoSl,
        autoTp: body.autoTp ?? config.autoTp,
        slPercent: body.slPercent?.toString() ?? config.slPercent,
        tpPercent: body.tpPercent?.toString() ?? config.tpPercent,
        updatedAt: new Date(),
      })
      .where(eq(botConfigs.id, config.id))
      .returning();

    return NextResponse.json({ config: updated });
  } catch (err) {
    console.error("Config POST error:", err);
    return NextResponse.json({ error: "Failed to update config" }, { status: 500 });
  }
}
