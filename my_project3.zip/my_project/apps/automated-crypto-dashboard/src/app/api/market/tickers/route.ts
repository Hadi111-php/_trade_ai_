import { NextResponse } from "next/server";
import { fetchMultipleTickers } from "@/lib/binance";
import { SUPPORTED_SYMBOLS } from "@/lib/binance";

export async function GET() {
  try {
    const tickers = await fetchMultipleTickers(SUPPORTED_SYMBOLS);
    return NextResponse.json({ tickers });
  } catch (err) {
    console.error("Tickers error:", err);
    return NextResponse.json({ error: "Failed to fetch tickers" }, { status: 500 });
  }
}
