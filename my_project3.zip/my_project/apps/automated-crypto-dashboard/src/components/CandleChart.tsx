"use client";

import { useEffect, useRef } from "react";
import {
  createChart,
  ColorType,
  CandlestickSeries,
  HistogramSeries,
  CrosshairMode,
  type IChartApi,
  type ISeriesApi,
  type CandlestickData,
  type HistogramData,
  type Time,
} from "lightweight-charts";

interface Kline {
  openTime: number;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
}

interface Props {
  klines: Kline[];
  symbol: string;
  interval: string;
  currentPrice?: number;
}

export default function CandleChart({
  klines,
  symbol,
  interval,
  currentPrice,
}: Props) {
  const chartContainerRef = useRef<HTMLDivElement>(null);
  const chartRef = useRef<IChartApi | null>(null);
  const candleSeriesRef = useRef<ISeriesApi<"Candlestick"> | null>(null);
  const volumeSeriesRef = useRef<ISeriesApi<"Histogram"> | null>(null);

  useEffect(() => {
    if (!chartContainerRef.current) return;

    const chart = createChart(chartContainerRef.current, {
      layout: {
        background: { type: ColorType.Solid, color: "#131c2e" },
        textColor: "#8892a4",
        fontSize: 11,
      },
      grid: {
        vertLines: { color: "rgba(30, 45, 69, 0.4)" },
        horzLines: { color: "rgba(30, 45, 69, 0.4)" },
      },
      crosshair: {
        mode: CrosshairMode.Normal,
        vertLine: { color: "#3b82f6", width: 1, style: 2 },
        horzLine: { color: "#3b82f6", width: 1, style: 2 },
      },
      rightPriceScale: {
        borderColor: "#1e2d45",
        scaleMargins: { top: 0.1, bottom: 0.25 },
      },
      timeScale: {
        borderColor: "#1e2d45",
        timeVisible: true,
        secondsVisible: false,
      },
      width: chartContainerRef.current.clientWidth,
      height: 420,
    });

    // v5 API: chart.addSeries(SeriesType, options)
    const candleSeries = chart.addSeries(CandlestickSeries, {
      upColor: "#10b981",
      downColor: "#ef4444",
      borderUpColor: "#10b981",
      borderDownColor: "#ef4444",
      wickUpColor: "#10b981",
      wickDownColor: "#ef4444",
    });

    const volumeSeries = chart.addSeries(
      HistogramSeries,
      {
        priceFormat: { type: "volume" },
        priceScaleId: "volume",
      },
      1
    );

    chart.panes()[1]?.setHeight(80);

    chartRef.current = chart;
    candleSeriesRef.current = candleSeries;
    volumeSeriesRef.current = volumeSeries;

    const handleResize = () => {
      if (chartContainerRef.current) {
        chart.applyOptions({ width: chartContainerRef.current.clientWidth });
      }
    };
    window.addEventListener("resize", handleResize);

    return () => {
      window.removeEventListener("resize", handleResize);
      chart.remove();
    };
  }, []);

  useEffect(() => {
    if (!candleSeriesRef.current || !volumeSeriesRef.current || !klines.length)
      return;

    const candleData: CandlestickData<Time>[] = klines.map((k) => ({
      time: Math.floor(k.openTime / 1000) as Time,
      open: k.open,
      high: k.high,
      low: k.low,
      close: k.close,
    }));

    const volumeData: HistogramData<Time>[] = klines.map((k) => ({
      time: Math.floor(k.openTime / 1000) as Time,
      value: k.volume,
      color:
        k.close >= k.open
          ? "rgba(16, 185, 129, 0.4)"
          : "rgba(239, 68, 68, 0.4)",
    }));

    candleSeriesRef.current.setData(candleData);
    volumeSeriesRef.current.setData(volumeData);

    chartRef.current?.timeScale().fitContent();
  }, [klines]);

  // Update last candle with current price
  useEffect(() => {
    if (!candleSeriesRef.current || !klines.length || !currentPrice) return;
    const lastKline = klines[klines.length - 1];
    candleSeriesRef.current.update({
      time: Math.floor(lastKline.openTime / 1000) as Time,
      open: lastKline.open,
      high: Math.max(lastKline.high, currentPrice),
      low: Math.min(lastKline.low, currentPrice),
      close: currentPrice,
    });
  }, [currentPrice, klines]);

  return (
    <div className="relative">
      <div className="absolute top-3 left-3 z-10 flex items-center gap-3">
        <span className="text-white font-bold text-sm">{symbol}</span>
        <span
          className="text-xs px-2 py-0.5 rounded"
          style={{
            background: "rgba(30,45,69,0.8)",
            color: "var(--text-secondary)",
          }}
        >
          {interval}
        </span>
        {currentPrice && (
          <span
            className="font-mono text-sm"
            style={{ color: "var(--accent-cyan)" }}
          >
            $
            {currentPrice.toLocaleString(undefined, {
              minimumFractionDigits: 2,
              maximumFractionDigits: 2,
            })}
          </span>
        )}
      </div>
      <div ref={chartContainerRef} className="w-full" />
    </div>
  );
}
