// Market Data API - Using CoinGecko Public API (no key required)
// Real-time crypto data for virtual trading

export const COINGECKO_BASE = "https://api.coingecko.com/api/v3";

// Map symbol -> CoinGecko ID
export const SYMBOL_TO_ID: Record<string, string> = {
  BTCUSDT: "bitcoin",
  ETHUSDT: "ethereum",
  BNBUSDT: "binancecoin",
  SOLUSDT: "solana",
  XRPUSDT: "ripple",
  ADAUSDT: "cardano",
  DOGEUSDT: "dogecoin",
  AVAXUSDT: "avalanche-2",
  DOTUSDT: "polkadot",
  MATICUSDT: "matic-network",
  LINKUSDT: "chainlink",
  LTCUSDT: "litecoin",
  TRXUSDT: "tron",
  TONUSDT: "the-open-network",
  SUIUSDT: "sui",
};

export const SUPPORTED_SYMBOLS = Object.keys(SYMBOL_TO_ID);

export const TIMEFRAMES = [
  { label: "1m", value: "1m" },
  { label: "5m", value: "5m" },
  { label: "15m", value: "15m" },
  { label: "30m", value: "30m" },
  { label: "1h", value: "1h" },
  { label: "4h", value: "4h" },
  { label: "1d", value: "1d" },
];

// Map our timeframe to CoinGecko days param & interval
// CoinGecko OHLC: 1 day = 30min candles, 7 days = 4h candles, 14-30 days = daily
export const TF_TO_DAYS: Record<string, { days: number; interval: string; candleMs: number }> = {
  "1m":  { days: 1,   interval: "minutely", candleMs: 60_000 },
  "5m":  { days: 1,   interval: "minutely", candleMs: 300_000 },
  "15m": { days: 1,   interval: "minutely", candleMs: 900_000 },
  "30m": { days: 1,   interval: "minutely", candleMs: 1_800_000 },
  "1h":  { days: 7,   interval: "hourly",   candleMs: 3_600_000 },
  "4h":  { days: 14,  interval: "hourly",   candleMs: 14_400_000 },
  "1d":  { days: 90,  interval: "daily",    candleMs: 86_400_000 },
};

export interface BinanceKline {
  openTime: number;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
  closeTime: number;
  quoteVolume: number;
  trades: number;
}

export interface BinanceTicker {
  symbol: string;
  price: number;
  change: number;
  changePercent: number;
  high24h: number;
  low24h: number;
  volume24h: number;
  quoteVolume: number;
}

export interface BinanceFundingRate {
  symbol: string;
  fundingRate: number;
  fundingTime: number;
}

// Fetch OHLC data from CoinGecko
export async function fetchKlines(
  symbol: string,
  interval: string,
  limit = 200
): Promise<BinanceKline[]> {
  const coinId = SYMBOL_TO_ID[symbol] ?? "bitcoin";
  const tfConfig = TF_TO_DAYS[interval] ?? TF_TO_DAYS["15m"];
  const days = tfConfig.days;
  
  // CoinGecko free OHLC endpoint - returns [timestamp, open, high, low, close]
  const url = `${COINGECKO_BASE}/coins/${coinId}/ohlc?vs_currency=usd&days=${days}`;
  
  const res = await fetch(url, {
    next: { revalidate: 60 },
    headers: { Accept: "application/json" },
  });

  if (!res.ok) {
    throw new Error(`CoinGecko OHLC error: ${res.status} ${res.statusText}`);
  }

  const data: [number, number, number, number, number][] = await res.json();

  // data = [[timestamp_ms, open, high, low, close], ...]
  const klines: BinanceKline[] = data.slice(-limit).map((candle, i, arr) => {
    const [ts, open, high, low, close] = candle;
    const prevClose = i > 0 ? arr[i - 1][4] : open;
    const priceMove = Math.abs(close - prevClose);
    const vol = priceMove * 80 + 30 + Math.random() * 20;
    
    return {
      openTime: ts,
      open,
      high,
      low,
      close,
      volume: vol,
      closeTime: ts + tfConfig.candleMs,
      quoteVolume: vol * close,
      trades: Math.floor(vol * 5),
    };
  });

  return klines;
}

// 24hr ticker from CoinGecko markets endpoint
export async function fetch24hTicker(symbol: string): Promise<BinanceTicker> {
  const coinId = SYMBOL_TO_ID[symbol] ?? "bitcoin";
  const url = `${COINGECKO_BASE}/coins/markets?vs_currency=usd&ids=${coinId}&order=market_cap_desc&per_page=1&page=1&price_change_percentage=24h`;
  
  const res = await fetch(url, {
    next: { revalidate: 15 },
    headers: { Accept: "application/json" },
  });

  if (!res.ok) {
    throw new Error(`CoinGecko ticker error: ${res.status}`);
  }

  const [d] = await res.json();

  return {
    symbol,
    price: d.current_price,
    change: d.price_change_24h,
    changePercent: d.price_change_percentage_24h,
    high24h: d.high_24h,
    low24h: d.low_24h,
    volume24h: d.total_volume,
    quoteVolume: d.total_volume,
  };
}

// Multiple tickers from CoinGecko markets bulk endpoint
export async function fetchMultipleTickers(
  symbols: string[]
): Promise<BinanceTicker[]> {
  const ids = symbols
    .map((s) => SYMBOL_TO_ID[s])
    .filter(Boolean)
    .join(",");

  const url = `${COINGECKO_BASE}/coins/markets?vs_currency=usd&ids=${ids}&order=market_cap_desc&per_page=50&page=1&price_change_percentage=24h`;

  const res = await fetch(url, {
    next: { revalidate: 30 },
    headers: { Accept: "application/json" },
  });

  if (!res.ok) {
    throw new Error(`CoinGecko markets error: ${res.status}`);
  }

  const data = await res.json();

  // Build reverse map: id -> symbol
  const idToSymbol: Record<string, string> = {};
  for (const [sym, id] of Object.entries(SYMBOL_TO_ID)) {
    idToSymbol[id] = sym;
  }

  return data.map(
    (d: {
      id: string;
      current_price: number;
      price_change_24h: number;
      price_change_percentage_24h: number;
      high_24h: number;
      low_24h: number;
      total_volume: number;
    }) => ({
      symbol: idToSymbol[d.id] ?? d.id.toUpperCase(),
      price: d.current_price,
      change: d.price_change_24h,
      changePercent: d.price_change_percentage_24h,
      high24h: d.high_24h,
      low24h: d.low_24h,
      volume24h: d.total_volume,
      quoteVolume: d.total_volume,
    })
  );
}

// Funding rate - not available in CoinGecko free tier, return null
export async function fetchFundingRate(
  _symbol: string
): Promise<BinanceFundingRate | null> {
  return null;
}

// Order book - not available in CoinGecko free tier
export async function fetchOrderBook(
  _symbol: string
): Promise<{ bids: [number, number][]; asks: [number, number][] }> {
  return { bids: [], asks: [] };
}
