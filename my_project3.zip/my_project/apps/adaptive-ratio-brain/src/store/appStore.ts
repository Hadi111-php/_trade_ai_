import { create } from 'zustand';

export type AppPage = 'dashboard' | 'market' | 'signals' | 'validation' | 'autotrade' | 'settings' | 'brain' | 'health' | 'apikeys' | 'datainject';

export interface VirtualTrade {
  id: string;
  symbol: string;
  side: 'LONG' | 'SHORT';
  entryPrice: number;
  exitPrice?: number;
  quantity: number;
  leverage: number;
  stopLoss: number;
  takeProfit: number;
  status: 'OPEN' | 'CLOSED' | 'STOPPED' | 'TP_HIT';
  openTime: number;
  closeTime?: number;
  pnl?: number;
  pnlPercent?: number;
}

export interface SignalEntry {
  id: string;
  symbol: string;
  signal: string;
  score: number;
  reasons: string[];
  price: number;
  timestamp: number;
}

export interface SystemSettings {
  defaultLeverage: number;
  riskPercent: number;
  virtualBalance: number;
  favoriteSymbols: string[];
  autoTradeEnabled: boolean;
  signalThreshold: number;
  refreshInterval: number;
}

interface AppState {
  currentPage: AppPage;
  setPage: (page: AppPage) => void;
  
  watchlist: string[];
  addToWatchlist: (symbol: string) => void;
  removeFromWatchlist: (symbol: string) => void;
  
  virtualTrades: VirtualTrade[];
  addVirtualTrade: (trade: VirtualTrade) => void;
  closeVirtualTrade: (id: string, exitPrice: number) => void;
  
  signals: SignalEntry[];
  addSignal: (signal: SignalEntry) => void;
  clearSignals: () => void;
  
  settings: SystemSettings;
  updateSettings: (settings: Partial<SystemSettings>) => void;
  
  selectedSymbol: string;
  setSelectedSymbol: (symbol: string) => void;
}

export const useAppStore = create<AppState>((set) => ({
  currentPage: 'dashboard',
  setPage: (page) => set({ currentPage: page }),
  
  watchlist: ['BTCUSDT', 'ETHUSDT', 'BNBUSDT', 'SOLUSDT', 'XRPUSDT', 'DOGEUSDT', 'ADAUSDT', 'AVAXUSDT'],
  addToWatchlist: (symbol) => set((s) => ({
    watchlist: s.watchlist.includes(symbol) ? s.watchlist : [...s.watchlist, symbol]
  })),
  removeFromWatchlist: (symbol) => set((s) => ({
    watchlist: s.watchlist.filter(s2 => s2 !== symbol)
  })),
  
  virtualTrades: [],
  addVirtualTrade: (trade) => set((s) => ({ virtualTrades: [...s.virtualTrades, trade] })),
  closeVirtualTrade: (id, exitPrice) => set((s) => ({
    virtualTrades: s.virtualTrades.map(t => {
      if (t.id !== id) return t;
      const pnl = t.side === 'LONG'
        ? (exitPrice - t.entryPrice) * t.quantity * t.leverage
        : (t.entryPrice - exitPrice) * t.quantity * t.leverage;
      const pnlPercent = (pnl / (t.entryPrice * t.quantity)) * 100;
      return { ...t, exitPrice, status: 'CLOSED' as const, closeTime: Date.now(), pnl, pnlPercent };
    })
  })),
  
  signals: [],
  addSignal: (signal) => set((s) => ({ signals: [signal, ...s.signals].slice(0, 100) })),
  clearSignals: () => set({ signals: [] }),
  
  settings: {
    defaultLeverage: 10,
    riskPercent: 2,
    virtualBalance: 10000,
    favoriteSymbols: ['BTCUSDT', 'ETHUSDT', 'SOLUSDT'],
    autoTradeEnabled: false,
    signalThreshold: 3,
    refreshInterval: 10,
  },
  updateSettings: (newSettings) => set((s) => ({
    settings: { ...s.settings, ...newSettings }
  })),
  
  selectedSymbol: 'BTCUSDT',
  setSelectedSymbol: (symbol) => set({ selectedSymbol: symbol }),
}));
