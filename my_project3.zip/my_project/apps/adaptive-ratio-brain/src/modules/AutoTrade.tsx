import { useState } from 'react';
import { useAppStore, type VirtualTrade } from '../store/appStore';
import { getFuturesTicker } from '../lib/binanceApi';
import { Bot, Plus, X, TrendingUp, TrendingDown, DollarSign, Percent, RefreshCw } from 'lucide-react';

export function AutoTrade() {
  const { virtualTrades, addVirtualTrade, closeVirtualTrade, settings, selectedSymbol } = useAppStore();
  const [showForm, setShowForm] = useState(false);
  const [formSymbol, setFormSymbol] = useState(selectedSymbol);
  const [formSide, setFormSide] = useState<'LONG' | 'SHORT'>('LONG');
  const [formQuantity, setFormQuantity] = useState('0.01');
  const [formLeverage, setFormLeverage] = useState(String(settings.defaultLeverage));
  const [formStopLoss, setFormStopLoss] = useState('2');
  const [formTakeProfit, setFormTakeProfit] = useState('4');
  const [submitting, setSubmitting] = useState(false);

  const openTrades = virtualTrades.filter(t => t.status === 'OPEN');
  const closedTrades = virtualTrades.filter(t => t.status !== 'OPEN');
  const totalPnl = closedTrades.reduce((sum, t) => sum + (t.pnl || 0), 0);
  const winRate = closedTrades.length > 0
    ? (closedTrades.filter(t => (t.pnl || 0) > 0).length / closedTrades.length) * 100
    : 0;

  const handleOpenTrade = async () => {
    setSubmitting(true);
    try {
      const ticker = await getFuturesTicker(formSymbol.toUpperCase());
      const entryPrice = parseFloat(ticker.lastPrice);
      const leverage = parseFloat(formLeverage);
      const slPercent = parseFloat(formStopLoss) / 100;
      const tpPercent = parseFloat(formTakeProfit) / 100;

      const trade: VirtualTrade = {
        id: `VT-${Date.now()}`,
        symbol: formSymbol.toUpperCase(),
        side: formSide,
        entryPrice,
        quantity: parseFloat(formQuantity),
        leverage,
        stopLoss: formSide === 'LONG' ? entryPrice * (1 - slPercent) : entryPrice * (1 + slPercent),
        takeProfit: formSide === 'LONG' ? entryPrice * (1 + tpPercent) : entryPrice * (1 - tpPercent),
        status: 'OPEN',
        openTime: Date.now(),
      };

      addVirtualTrade(trade);
      setShowForm(false);
    } catch (err) {
      console.error('Failed to open trade:', err);
    }
    setSubmitting(false);
  };

  const handleCloseTrade = async (trade: VirtualTrade) => {
    try {
      const ticker = await getFuturesTicker(trade.symbol);
      closeVirtualTrade(trade.id, parseFloat(ticker.lastPrice));
    } catch (err) {
      console.error('Failed to close trade:', err);
    }
  };

  return (
    <div className="space-y-4">
      {/* Stats */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <StatBox icon={<Bot size={18} className="text-cyan-400" />} label="Open Trades" value={String(openTrades.length)} />
        <StatBox icon={<DollarSign size={18} className="text-yellow-400" />} label="Virtual Balance" value={`$${settings.virtualBalance.toLocaleString()}`} />
        <StatBox icon={<TrendingUp size={18} className={totalPnl >= 0 ? 'text-green-400' : 'text-red-400'} />} label="Total P&L" value={`${totalPnl >= 0 ? '+' : ''}$${totalPnl.toFixed(2)}`} />
        <StatBox icon={<Percent size={18} className="text-purple-400" />} label="Win Rate" value={`${winRate.toFixed(0)}%`} />
      </div>

      {/* Open Trade Button */}
      <button
        onClick={() => setShowForm(!showForm)}
        className="flex items-center gap-2 px-4 py-2 bg-cyan-500/20 text-cyan-400 rounded-lg border border-cyan-500/30 hover:bg-cyan-500/30"
      >
        {showForm ? <X size={16} /> : <Plus size={16} />}
        {showForm ? 'Cancel' : 'Open Virtual Trade'}
      </button>

      {/* Trade Form */}
      {showForm && (
        <div className="bg-gray-900 rounded-xl border border-gray-800 p-4 space-y-4">
          <h3 className="text-sm font-medium text-gray-300">📝 New Virtual Trade (Paper Trading)</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
            <div>
              <label className="text-xs text-gray-500">Symbol</label>
              <input
                value={formSymbol}
                onChange={e => setFormSymbol(e.target.value.toUpperCase())}
                className="w-full mt-1 px-3 py-2 bg-gray-800 rounded-lg border border-gray-700 text-sm outline-none focus:border-cyan-500"
              />
            </div>
            <div>
              <label className="text-xs text-gray-500">Side</label>
              <div className="flex gap-2 mt-1">
                <button
                  onClick={() => setFormSide('LONG')}
                  className={`flex-1 py-2 rounded-lg text-sm font-medium ${formSide === 'LONG' ? 'bg-green-500/20 text-green-400 border border-green-500/30' : 'bg-gray-800 text-gray-400'}`}
                >
                  LONG ▲
                </button>
                <button
                  onClick={() => setFormSide('SHORT')}
                  className={`flex-1 py-2 rounded-lg text-sm font-medium ${formSide === 'SHORT' ? 'bg-red-500/20 text-red-400 border border-red-500/30' : 'bg-gray-800 text-gray-400'}`}
                >
                  SHORT ▼
                </button>
              </div>
            </div>
            <div>
              <label className="text-xs text-gray-500">Quantity</label>
              <input
                value={formQuantity}
                onChange={e => setFormQuantity(e.target.value)}
                type="number"
                step="0.001"
                className="w-full mt-1 px-3 py-2 bg-gray-800 rounded-lg border border-gray-700 text-sm outline-none focus:border-cyan-500"
              />
            </div>
            <div>
              <label className="text-xs text-gray-500">Leverage</label>
              <input
                value={formLeverage}
                onChange={e => setFormLeverage(e.target.value)}
                type="number"
                min="1"
                max="125"
                className="w-full mt-1 px-3 py-2 bg-gray-800 rounded-lg border border-gray-700 text-sm outline-none focus:border-cyan-500"
              />
            </div>
            <div>
              <label className="text-xs text-gray-500">Stop Loss (%)</label>
              <input
                value={formStopLoss}
                onChange={e => setFormStopLoss(e.target.value)}
                type="number"
                step="0.5"
                className="w-full mt-1 px-3 py-2 bg-gray-800 rounded-lg border border-gray-700 text-sm outline-none focus:border-cyan-500"
              />
            </div>
            <div>
              <label className="text-xs text-gray-500">Take Profit (%)</label>
              <input
                value={formTakeProfit}
                onChange={e => setFormTakeProfit(e.target.value)}
                type="number"
                step="0.5"
                className="w-full mt-1 px-3 py-2 bg-gray-800 rounded-lg border border-gray-700 text-sm outline-none focus:border-cyan-500"
              />
            </div>
          </div>
          <button
            onClick={handleOpenTrade}
            disabled={submitting}
            className={`w-full py-3 rounded-lg font-medium ${formSide === 'LONG' ? 'bg-green-600 hover:bg-green-500' : 'bg-red-600 hover:bg-red-500'} disabled:opacity-50`}
          >
            {submitting ? 'Opening...' : `Open ${formSide} @ Market Price`}
          </button>
        </div>
      )}

      {/* Open Trades */}
      {openTrades.length > 0 && (
        <div className="bg-gray-900 rounded-xl border border-gray-800 p-4">
          <h3 className="text-sm font-medium text-gray-400 mb-3">🟢 Open Positions</h3>
          <div className="space-y-2">
            {openTrades.map(t => (
              <div key={t.id} className="flex flex-wrap items-center justify-between p-3 bg-gray-800/50 rounded-lg gap-2">
                <div className="flex items-center gap-3">
                  {t.side === 'LONG' ? <TrendingUp size={16} className="text-green-400" /> : <TrendingDown size={16} className="text-red-400" />}
                  <div>
                    <span className="font-medium text-sm">{t.symbol}</span>
                    <span className={`ml-2 text-xs px-2 py-0.5 rounded ${t.side === 'LONG' ? 'bg-green-500/20 text-green-400' : 'bg-red-500/20 text-red-400'}`}>
                      {t.side} {t.leverage}x
                    </span>
                  </div>
                </div>
                <div className="text-xs text-gray-400 space-x-3">
                  <span>Entry: ${t.entryPrice.toLocaleString()}</span>
                  <span>SL: ${t.stopLoss.toFixed(2)}</span>
                  <span>TP: ${t.takeProfit.toFixed(2)}</span>
                  <span>Qty: {t.quantity}</span>
                </div>
                <button
                  onClick={() => handleCloseTrade(t)}
                  className="px-3 py-1 bg-yellow-500/20 text-yellow-400 rounded text-xs hover:bg-yellow-500/30"
                >
                  <RefreshCw size={12} className="inline mr-1" /> Close @ Market
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Closed Trades History */}
      {closedTrades.length > 0 && (
        <div className="bg-gray-900 rounded-xl border border-gray-800 p-4">
          <h3 className="text-sm font-medium text-gray-400 mb-3">📊 Trade History</h3>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="text-xs text-gray-500 border-b border-gray-800">
                  <th className="text-left py-2">Symbol</th>
                  <th className="text-left py-2">Side</th>
                  <th className="text-right py-2">Entry</th>
                  <th className="text-right py-2">Exit</th>
                  <th className="text-right py-2">P&L</th>
                  <th className="text-right py-2">P&L %</th>
                  <th className="text-right py-2">Date</th>
                </tr>
              </thead>
              <tbody>
                {closedTrades.slice(0, 20).map(t => (
                  <tr key={t.id} className="border-b border-gray-800/50">
                    <td className="py-2">{t.symbol.replace('USDT', '')}</td>
                    <td className={`py-2 ${t.side === 'LONG' ? 'text-green-400' : 'text-red-400'}`}>{t.side} {t.leverage}x</td>
                    <td className="py-2 text-right">${t.entryPrice.toLocaleString()}</td>
                    <td className="py-2 text-right">${t.exitPrice?.toLocaleString()}</td>
                    <td className={`py-2 text-right font-medium ${(t.pnl || 0) >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                      {(t.pnl || 0) >= 0 ? '+' : ''}${(t.pnl || 0).toFixed(2)}
                    </td>
                    <td className={`py-2 text-right ${(t.pnlPercent || 0) >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                      {(t.pnlPercent || 0) >= 0 ? '+' : ''}{(t.pnlPercent || 0).toFixed(2)}%
                    </td>
                    <td className="py-2 text-right text-gray-500 text-xs">
                      {t.closeTime ? new Date(t.closeTime).toLocaleString('en', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' }) : ''}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {virtualTrades.length === 0 && !showForm && (
        <div className="text-center py-12 bg-gray-900 rounded-xl border border-gray-800">
          <Bot size={40} className="mx-auto text-gray-600 mb-4" />
          <p className="text-gray-400">No virtual trades yet</p>
          <p className="text-gray-500 text-sm mt-1">Open a paper trade to test your strategy without risk</p>
        </div>
      )}
    </div>
  );
}

function StatBox({ icon, label, value }: { icon: React.ReactNode; label: string; value: string }) {
  return (
    <div className="bg-gray-900 rounded-lg border border-gray-800 p-3 flex items-center gap-3">
      {icon}
      <div>
        <p className="text-xs text-gray-500">{label}</p>
        <p className="text-sm font-semibold">{value}</p>
      </div>
    </div>
  );
}
