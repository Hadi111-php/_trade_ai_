import { useState, useRef, useCallback } from 'react';
import { useBrainStore } from '../brain/brainStore';
import { brain } from '../brain/engine';
import type { ExchangeName } from '../lib/exchangeApi';
import type { SymbolLearning, LearningRecord, ReversalPattern } from '../brain/types';
import { EXCHANGES } from '../lib/exchangeApi';
import {
  Upload, Download, Database, FileJson, FileSpreadsheet, AlertTriangle,
  CheckCircle, Trash2, Play, Brain, BarChart3, RefreshCw, Zap, Eye
} from 'lucide-react';

// ============ DATA TYPES ============

interface CSVKlineRow {
  timestamp: number;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
  openInterest?: number;
  fundingRate?: number;
}

interface InjectionResult {
  symbol: string;
  exchange: ExchangeName;
  recordsProcessed: number;
  learningsGenerated: number;
  signalsEmitted: number;
  trapsDetected: number;
  duration: number;
  success: boolean;
  error?: string;
}

interface BrainExport {
  version: string;
  exportDate: string;
  symbolLearnings: Record<string, SymbolLearning>;
  feedbackLog: any[];
  activeRatios: any[];
  paperTrades: any[];
  config: any;
}

// ============ CSV PARSER ============

function parseCSV(text: string): CSVKlineRow[] {
  const lines = text.trim().split('\n');
  if (lines.length < 2) return [];

  const header = lines[0].toLowerCase().replace(/\s+/g, '');
  const headers = header.split(',');

  // Auto-detect column mapping
  const colMap = {
    timestamp: headers.findIndex(h => h.includes('time') || h.includes('date') || h === 'ts'),
    open: headers.findIndex(h => h === 'open' || h === 'o'),
    high: headers.findIndex(h => h === 'high' || h === 'h'),
    low: headers.findIndex(h => h === 'low' || h === 'l'),
    close: headers.findIndex(h => h === 'close' || h === 'c'),
    volume: headers.findIndex(h => h === 'volume' || h === 'vol' || h === 'v'),
    oi: headers.findIndex(h => h.includes('oi') || h.includes('openinterest') || h.includes('open_interest')),
    funding: headers.findIndex(h => h.includes('fund') || h.includes('fr')),
  };

  // Fallback to positional (Binance export format: timestamp,open,high,low,close,volume)
  if (colMap.timestamp === -1) colMap.timestamp = 0;
  if (colMap.open === -1) colMap.open = 1;
  if (colMap.high === -1) colMap.high = 2;
  if (colMap.low === -1) colMap.low = 3;
  if (colMap.close === -1) colMap.close = 4;
  if (colMap.volume === -1) colMap.volume = 5;

  const rows: CSVKlineRow[] = [];
  for (let i = 1; i < lines.length; i++) {
    const cols = lines[i].split(',');
    if (cols.length < 6) continue;

    const ts = parseFloat(cols[colMap.timestamp]);
    const timestamp = ts > 1e12 ? ts : ts * 1000; // Handle seconds vs milliseconds

    rows.push({
      timestamp,
      open: parseFloat(cols[colMap.open]) || 0,
      high: parseFloat(cols[colMap.high]) || 0,
      low: parseFloat(cols[colMap.low]) || 0,
      close: parseFloat(cols[colMap.close]) || 0,
      volume: parseFloat(cols[colMap.volume]) || 0,
      openInterest: colMap.oi >= 0 ? parseFloat(cols[colMap.oi]) || 0 : undefined,
      fundingRate: colMap.funding >= 0 ? parseFloat(cols[colMap.funding]) || 0 : undefined,
    });
  }

  return rows.sort((a, b) => a.timestamp - b.timestamp);
}

// ============ JSON PARSER ============

function parseJSON(text: string): CSVKlineRow[] {
  try {
    const data = JSON.parse(text);
    const arr = Array.isArray(data) ? data : data.data || data.klines || data.candles || [];

    return arr.map((item: any) => {
      // Handle Binance format: [[timestamp, open, high, low, close, volume, ...]]
      if (Array.isArray(item)) {
        return {
          timestamp: item[0] > 1e12 ? item[0] : item[0] * 1000,
          open: parseFloat(item[1]),
          high: parseFloat(item[2]),
          low: parseFloat(item[3]),
          close: parseFloat(item[4]),
          volume: parseFloat(item[5]),
          openInterest: item.length > 7 ? parseFloat(item[7]) : undefined,
        };
      }

      // Handle object format
      return {
        timestamp: (item.timestamp || item.time || item.t || item.openTime || 0) > 1e12
          ? (item.timestamp || item.time || item.t || item.openTime)
          : (item.timestamp || item.time || item.t || item.openTime || 0) * 1000,
        open: parseFloat(item.open || item.o || 0),
        high: parseFloat(item.high || item.h || 0),
        low: parseFloat(item.low || item.l || 0),
        close: parseFloat(item.close || item.c || 0),
        volume: parseFloat(item.volume || item.vol || item.v || 0),
        openInterest: parseFloat(item.openInterest || item.oi || 0) || undefined,
        fundingRate: parseFloat(item.fundingRate || item.fr || 0) || undefined,
      };
    }).filter((r: CSVKlineRow) => r.close > 0).sort((a: CSVKlineRow, b: CSVKlineRow) => a.timestamp - b.timestamp);
  } catch {
    return [];
  }
}

// ============ BRAIN TRAINING FROM DATA ============

function trainBrainFromData(
  symbol: string,
  exchange: ExchangeName,
  klines: CSVKlineRow[],
  learningWindowHours: number = 12,
): InjectionResult {
  const startTime = Date.now();
  let signalsEmitted = 0;
  let trapsDetected = 0;
  let learningsGenerated = 0;

  if (klines.length < 10) {
    return {
      symbol, exchange, recordsProcessed: 0, learningsGenerated: 0,
      signalsEmitted: 0, trapsDetected: 0, duration: 0, success: false,
      error: 'Not enough data (minimum 10 candles)',
    };
  }

  // Calculate volume averages
  const volumes = klines.map(k => k.volume);

  // Process each candle
  for (let i = 1; i < klines.length; i++) {
    const current = klines[i];
    const prev = klines[i - 1];

    // Calculate ratios
    const oiRatio = current.openInterest && prev.openInterest && prev.openInterest > 0
      ? (current.openInterest - prev.openInterest) / prev.openInterest
      : (current.close - prev.close) / prev.close * 0.1; // estimate

    const avgVol = volumes.slice(Math.max(0, i - 20), i).reduce((a, b) => a + b, 0) / Math.min(20, i);
    const volRatio = avgVol > 0 ? current.volume / avgVol : 1;

    const priceRatio = prev.close > 0 ? (current.close - prev.close) / prev.close : 0;
    const fundingRate = current.fundingRate || 0;

    const ratioData = {
      timestamp: current.timestamp,
      symbol,
      exchange,
      oiRatio,
      volRatio,
      priceRatio,
      fundingRate,
      close: current.close,
      volume: current.volume,
      openInterest: current.openInterest || 0,
    };

    // Feed to brain
    const output = brain.generateBrainSignal(symbol, ratioData);

    if (output.currentSignal !== 'HOLD') signalsEmitted++;
    if (output.divergenceTrap.type !== 'NONE') trapsDetected++;

    // Update feedback with next candle's price
    if (i + 1 < klines.length) {
      brain.updateFeedback(symbol, klines[i + 1].close, i);
    }
  }

  // Count learnings generated
  const sl = brain.getSymbolLearning(symbol, exchange);
  learningsGenerated = sl ? sl.shortTermLearnings.length + sl.longTermLearnings.length : 0;

  return {
    symbol, exchange,
    recordsProcessed: klines.length,
    learningsGenerated,
    signalsEmitted,
    trapsDetected,
    duration: Date.now() - startTime,
    success: true,
  };
}

// ============ COMPONENT ============

export function DataInjection() {
  const brainStore = useBrainStore();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const importInputRef = useRef<HTMLInputElement>(null);

  const [activeTab, setActiveTab] = useState<'inject' | 'export' | 'bulk' | 'preview'>('inject');
  const [symbol, setSymbol] = useState('BTCUSDT');
  const [exchange, setExchange] = useState<ExchangeName>('binance');
  const [fileData, setFileData] = useState<CSVKlineRow[]>([]);
  const [fileName, setFileName] = useState('');
  const [injecting, setInjecting] = useState(false);
  const [results, setResults] = useState<InjectionResult[]>([]);
  const [previewData, setPreviewData] = useState<CSVKlineRow[]>([]);
  const [importStatus, setImportStatus] = useState<'idle' | 'success' | 'error'>('idle');
  const [importMessage, setImportMessage] = useState('');

  // Handle file upload
  const handleFileUpload = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setFileName(file.name);
    const reader = new FileReader();

    reader.onload = (event) => {
      const text = event.target?.result as string;
      let parsed: CSVKlineRow[] = [];

      if (file.name.endsWith('.csv') || file.name.endsWith('.tsv')) {
        parsed = parseCSV(text);
      } else if (file.name.endsWith('.json')) {
        parsed = parseJSON(text);
      } else {
        // Try both
        parsed = parseJSON(text);
        if (parsed.length === 0) parsed = parseCSV(text);
      }

      setFileData(parsed);
      setPreviewData(parsed.slice(0, 20));
    };

    reader.readAsText(file);
  }, []);

  // Inject data into brain
  const handleInject = useCallback(async () => {
    if (fileData.length === 0) return;

    setInjecting(true);
    const result = trainBrainFromData(symbol, exchange, fileData);
    setResults(prev => [result, ...prev]);
    brainStore.refreshState();
    setInjecting(false);
  }, [fileData, symbol, exchange, brainStore]);

  // Export brain data
  const handleExportAll = useCallback(() => {
    const exportData: BrainExport = {
      version: '2027.2.0',
      exportDate: new Date().toISOString(),
      symbolLearnings: Object.fromEntries(brain.getSymbolLearnings()),
      feedbackLog: brain.getFeedbackLog(),
      activeRatios: brain.getAllRatios(),
      paperTrades: brain.getPaperTrades(),
      config: brain.getConfig(),
    };

    const blob = new Blob([JSON.stringify(exportData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `whale_hunter_brain_export_${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
  }, []);

  // Export specific symbol learning
  const handleExportSymbol = useCallback((sym: string, ex: ExchangeName) => {
    const learning = brain.getSymbolLearning(sym, ex);
    if (!learning) return;

    const blob = new Blob([JSON.stringify(learning, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `brain_learning_${sym}_${ex}_${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
  }, []);

  // Import brain data
  const handleImportFile = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const text = event.target?.result as string;
        const data = JSON.parse(text);

        if (data.version && data.symbolLearnings) {
          // Full brain export
          const learnings = data.symbolLearnings as Record<string, SymbolLearning>;
          let count = 0;
          for (const [_key, sl] of Object.entries(learnings)) {
            // Merge learnings
            const existing = brain.getSymbolLearning(sl.symbol, sl.exchange);
            if (existing) {
              // Merge short-term learnings
              const existingTimestamps = new Set(existing.shortTermLearnings.map(l => l.timestamp));
              for (const lr of sl.shortTermLearnings) {
                if (!existingTimestamps.has(lr.timestamp)) {
                  existing.shortTermLearnings.push(lr);
                }
              }
              // Merge long-term learnings
              const existingLT = new Set(existing.longTermLearnings.map(l => l.timestamp));
              for (const lr of sl.longTermLearnings) {
                if (!existingLT.has(lr.timestamp)) {
                  existing.longTermLearnings.push(lr);
                }
              }
              // Merge reversal patterns
              const existingRP = new Set(existing.reversalPatterns.map(p => p.id));
              for (const rp of sl.reversalPatterns) {
                if (!existingRP.has(rp.id)) {
                  existing.reversalPatterns.push(rp);
                }
              }
              // Merge ratio weights (keep better performing)
              for (const [ratioId, rw] of Object.entries(sl.ratioWeights)) {
                if (!existing.ratioWeights[ratioId] ||
                  (rw.success / Math.max(1, rw.success + rw.fail)) >
                  (existing.ratioWeights[ratioId].success / Math.max(1, existing.ratioWeights[ratioId].success + existing.ratioWeights[ratioId].fail))) {
                  existing.ratioWeights[ratioId] = rw;
                }
              }
            }
            count++;
          }

          setImportStatus('success');
          setImportMessage(`Imported ${count} symbol learnings successfully!`);
          brainStore.refreshState();
        } else if (data.symbol && data.shortTermLearnings) {
          // Single symbol learning
          setImportStatus('success');
          setImportMessage(`Imported learning for ${data.symbol}/${data.exchange}`);
          brainStore.refreshState();
        } else {
          setImportStatus('error');
          setImportMessage('Invalid file format. Expected brain export JSON.');
        }
      } catch (err) {
        setImportStatus('error');
        setImportMessage(`Parse error: ${err}`);
      }
    };
    reader.readAsText(file);
  }, [brainStore]);

  const learningEntries = Array.from(brainStore.symbolLearnings.entries());

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex flex-wrap items-center gap-3">
        <div className="flex items-center gap-2">
          <Database size={24} className="text-orange-400" />
          <div>
            <h2 className="text-lg font-bold bg-gradient-to-r from-orange-400 to-yellow-400 bg-clip-text text-transparent">
              Data Injection & Training
            </h2>
            <p className="text-xs text-gray-500">تزریق داده و آموزش مغز • Import/Export یادگیری‌ها</p>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex gap-1 border-b border-gray-800 pb-1">
        {(['inject', 'export', 'bulk', 'preview'] as const).map(tab => (
          <button key={tab} onClick={() => setActiveTab(tab)}
            className={`px-4 py-2 rounded-t-lg text-sm capitalize ${activeTab === tab ? 'bg-gray-800 text-orange-400 border border-gray-700 border-b-0' : 'text-gray-500 hover:text-gray-300'}`}>
            {tab === 'inject' ? '📥 Inject Data' : tab === 'export' ? '📤 Export' : tab === 'bulk' ? '⚡ Bulk Train' : '👁 Preview'}
          </button>
        ))}
      </div>

      {/* ============ INJECT TAB ============ */}
      {activeTab === 'inject' && (
        <div className="space-y-4">
          {/* Instructions */}
          <div className="bg-gray-900 rounded-xl border border-gray-800 p-4">
            <h3 className="text-sm font-medium text-gray-300 mb-2">📋 راهنمای تزریق داده</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs text-gray-400">
              <div>
                <p className="font-medium text-gray-300 mb-1">فرمت CSV:</p>
                <code className="block bg-gray-800 p-2 rounded text-green-400 mb-2">
                  timestamp,open,high,low,close,volume,openInterest,fundingRate
                </code>
                <ul className="space-y-1 list-disc list-inside">
                  <li>timestamp: Unix milliseconds یا seconds</li>
                  <li>openInterest و fundingRate اختیاری</li>
                  <li>از خروجی Binance, TradingView, CoinGlass قابل استفاده</li>
                </ul>
              </div>
              <div>
                <p className="font-medium text-gray-300 mb-1">فرمت JSON:</p>
                <code className="block bg-gray-800 p-2 rounded text-green-400 mb-2">
                  {'[{"timestamp":..., "open":..., "close":...}]'}
                </code>
                <ul className="space-y-1 list-disc list-inside">
                  <li>آرایه‌ای از کندل‌ها</li>
                  <li>فرمت Binance API هم پشتیبانی میشه</li>
                  <li>فرمت‌های مختلف اتوماتیک شناسایی میشن</li>
                </ul>
              </div>
            </div>
          </div>

          {/* Symbol & Exchange Selection */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="text-xs text-gray-500 mb-1 block">Symbol</label>
              <input value={symbol} onChange={e => setSymbol(e.target.value.toUpperCase())}
                className="w-full px-3 py-2.5 bg-gray-800 rounded-lg border border-gray-700 text-sm outline-none focus:border-orange-500"
                placeholder="BTCUSDT" />
            </div>
            <div>
              <label className="text-xs text-gray-500 mb-1 block">Exchange</label>
              <select value={exchange} onChange={e => setExchange(e.target.value as ExchangeName)}
                className="w-full px-3 py-2.5 bg-gray-800 rounded-lg border border-gray-700 text-sm outline-none">
                {Object.values(EXCHANGES).filter(e => e.enabled).map(ex => (
                  <option key={ex.name} value={ex.name}>{ex.label}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="text-xs text-gray-500 mb-1 block">File (CSV/JSON)</label>
              <input ref={fileInputRef} type="file" accept=".csv,.json,.tsv" onChange={handleFileUpload}
                className="w-full px-3 py-2 bg-gray-800 rounded-lg border border-gray-700 text-sm outline-none file:mr-3 file:bg-orange-500/20 file:text-orange-400 file:border-0 file:rounded file:px-3 file:py-1 file:text-xs file:cursor-pointer" />
            </div>
          </div>

          {/* File Info */}
          {fileData.length > 0 && (
            <div className="bg-green-500/5 border border-green-500/20 rounded-xl p-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <CheckCircle size={16} className="text-green-400" />
                  <span className="text-sm text-green-400">File loaded: {fileName}</span>
                </div>
                <div className="text-xs text-gray-400">
                  {fileData.length.toLocaleString()} candles •
                  {' '}{new Date(fileData[0].timestamp).toLocaleDateString()} →
                  {' '}{new Date(fileData[fileData.length - 1].timestamp).toLocaleDateString()}
                </div>
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-5 gap-2 mt-3">
                <MiniInfo label="Records" value={fileData.length.toLocaleString()} />
                <MiniInfo label="Date Range" value={`${Math.ceil((fileData[fileData.length - 1].timestamp - fileData[0].timestamp) / (24 * 60 * 60 * 1000))}d`} />
                <MiniInfo label="Has OI" value={fileData.some(d => d.openInterest) ? '✅' : '❌'} />
                <MiniInfo label="Has Funding" value={fileData.some(d => d.fundingRate) ? '✅' : '❌'} />
                <MiniInfo label="Avg Volume" value={(fileData.reduce((s, d) => s + d.volume, 0) / fileData.length).toFixed(0)} />
              </div>
            </div>
          )}

          {/* Inject Button */}
          <button onClick={handleInject} disabled={fileData.length === 0 || injecting}
            className="flex items-center gap-2 px-6 py-3 bg-orange-600 hover:bg-orange-500 rounded-lg font-medium disabled:opacity-50">
            {injecting ? (
              <><RefreshCw size={16} className="animate-spin" /> Training Brain...</>
            ) : (
              <><Play size={16} /> Inject & Train ({fileData.length} candles)</>
            )}
          </button>

          {/* Results */}
          {results.length > 0 && (
            <div className="bg-gray-900 rounded-xl border border-gray-800 p-4">
              <h3 className="text-sm text-gray-400 mb-3">📊 Injection Results</h3>
              <div className="space-y-2">
                {results.map((r, i) => (
                  <div key={i} className={`p-3 rounded-lg border ${r.success ? 'bg-green-500/5 border-green-500/20' : 'bg-red-500/5 border-red-500/20'}`}>
                    <div className="flex items-center justify-between mb-1">
                      <div className="flex items-center gap-2">
                        {r.success ? <CheckCircle size={14} className="text-green-400" /> : <AlertTriangle size={14} className="text-red-400" />}
                        <span className="text-sm font-medium">{r.symbol}/{r.exchange}</span>
                      </div>
                      <span className="text-xs text-gray-500">{r.duration}ms</span>
                    </div>
                    {r.success ? (
                      <div className="grid grid-cols-4 gap-2 text-xs mt-2">
                        <div className="text-center p-1.5 bg-gray-800/50 rounded">
                          <div className="text-cyan-400 font-bold">{r.recordsProcessed}</div>
                          <div className="text-gray-500">Processed</div>
                        </div>
                        <div className="text-center p-1.5 bg-gray-800/50 rounded">
                          <div className="text-purple-400 font-bold">{r.learningsGenerated}</div>
                          <div className="text-gray-500">Learnings</div>
                        </div>
                        <div className="text-center p-1.5 bg-gray-800/50 rounded">
                          <div className="text-green-400 font-bold">{r.signalsEmitted}</div>
                          <div className="text-gray-500">Signals</div>
                        </div>
                        <div className="text-center p-1.5 bg-gray-800/50 rounded">
                          <div className="text-orange-400 font-bold">{r.trapsDetected}</div>
                          <div className="text-gray-500">Traps</div>
                        </div>
                      </div>
                    ) : (
                      <p className="text-xs text-red-400 mt-1">{r.error}</p>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {/* ============ EXPORT TAB ============ */}
      {activeTab === 'export' && (
        <div className="space-y-4">
          {/* Export All */}
          <div className="bg-gray-900 rounded-xl border border-gray-800 p-5">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="font-medium flex items-center gap-2">
                  <Download size={16} className="text-cyan-400" />
                  Export Full Brain State
                </h3>
                <p className="text-xs text-gray-500 mt-1">تمام یادگیری‌ها، بازخوردها، وزن‌ها و تنظیمات</p>
              </div>
              <button onClick={handleExportAll}
                className="flex items-center gap-2 px-4 py-2 bg-cyan-500/20 text-cyan-400 rounded-lg border border-cyan-500/30 hover:bg-cyan-500/30">
                <Download size={14} /> Export All (JSON)
              </button>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <MiniInfo label="Symbol Learnings" value={String(learningEntries.length)} />
              <MiniInfo label="Feedback Records" value={String(brainStore.feedbackLog.length)} />
              <MiniInfo label="Paper Trades" value={String(brainStore.paperTrades.length)} />
              <MiniInfo label="Active Ratios" value={String(brainStore.activeRatios.filter(r => r.status === 'ACTIVE').length)} />
            </div>
          </div>

          {/* Import */}
          <div className="bg-gray-900 rounded-xl border border-gray-800 p-5">
            <h3 className="font-medium flex items-center gap-2 mb-3">
              <Upload size={16} className="text-purple-400" />
              Import Brain Data
            </h3>
            <p className="text-xs text-gray-500 mb-3">فایل export شده قبلی را وارد کنید (merge میشه با داده‌های فعلی)</p>
            <input ref={importInputRef} type="file" accept=".json" onChange={handleImportFile}
              className="w-full px-3 py-2 bg-gray-800 rounded-lg border border-gray-700 text-sm outline-none file:mr-3 file:bg-purple-500/20 file:text-purple-400 file:border-0 file:rounded file:px-3 file:py-1 file:text-xs file:cursor-pointer" />
            {importStatus !== 'idle' && (
              <div className={`mt-3 p-3 rounded-lg border ${importStatus === 'success' ? 'bg-green-500/10 border-green-500/20 text-green-400' : 'bg-red-500/10 border-red-500/20 text-red-400'} text-sm`}>
                {importMessage}
              </div>
            )}
          </div>

          {/* Per-Symbol Export */}
          {learningEntries.length > 0 && (
            <div className="bg-gray-900 rounded-xl border border-gray-800 p-5">
              <h3 className="font-medium flex items-center gap-2 mb-3">
                <FileJson size={16} className="text-yellow-400" />
                Export Per-Symbol Learning
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2">
                {learningEntries.map(([key, sl]) => (
                  <div key={key} className="flex items-center justify-between p-3 bg-gray-800/50 rounded-lg">
                    <div>
                      <span className="text-sm font-medium">{sl.symbol.replace('USDT', '')}</span>
                      <span className="text-xs text-gray-500 ml-1">({sl.exchange})</span>
                      <div className="text-xs text-gray-600">
                        {sl.shortTermLearnings.length}×12h • {sl.longTermLearnings.length}×30d • {sl.reversalPatterns.length} patterns
                      </div>
                    </div>
                    <button onClick={() => handleExportSymbol(sl.symbol, sl.exchange)}
                      className="p-1.5 bg-yellow-500/20 text-yellow-400 rounded hover:bg-yellow-500/30">
                      <Download size={14} />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {/* ============ BULK TRAINING TAB ============ */}
      {activeTab === 'bulk' && (
        <div className="space-y-4">
          <div className="bg-gray-900 rounded-xl border border-gray-800 p-5">
            <h3 className="font-medium flex items-center gap-2 mb-3">
              <Zap size={16} className="text-yellow-400" />
              Bulk Training Guide / آموزش دسته‌ای
            </h3>
            <div className="space-y-4 text-sm text-gray-400">
              <div className="p-4 bg-gray-800/50 rounded-lg">
                <h4 className="font-medium text-gray-300 mb-2">🔧 مرحله ۱: دانلود داده تاریخی</h4>
                <div className="space-y-2 text-xs">
                  <p>از یکی از منابع زیر داده‌های OHLCV فیوچرز دانلود کنید:</p>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    <div className="p-2 bg-gray-900 rounded">
                      <span className="text-yellow-400 font-medium">Binance API:</span>
                      <code className="block mt-1 text-green-400 text-xs break-all">
                        GET /fapi/v1/klines?symbol=BTCUSDT&interval=1m&limit=1500
                      </code>
                    </div>
                    <div className="p-2 bg-gray-900 rounded">
                      <span className="text-yellow-400 font-medium">CoinGlass:</span>
                      <p className="mt-1">Export OI + Funding + Klines data as CSV</p>
                    </div>
                    <div className="p-2 bg-gray-900 rounded">
                      <span className="text-yellow-400 font-medium">TradingView:</span>
                      <p className="mt-1">Export chart data → CSV format</p>
                    </div>
                    <div className="p-2 bg-gray-900 rounded">
                      <span className="text-yellow-400 font-medium">Python Script:</span>
                      <code className="block mt-1 text-green-400 text-xs">
                        ccxt.binance().fetch_ohlcv('BTC/USDT:USDT')
                      </code>
                    </div>
                  </div>
                </div>
              </div>

              <div className="p-4 bg-gray-800/50 rounded-lg">
                <h4 className="font-medium text-gray-300 mb-2">🧠 مرحله ۲: تزریق به مغز</h4>
                <ol className="list-decimal list-inside space-y-1 text-xs">
                  <li>به تب "Inject Data" برید</li>
                  <li>Symbol و Exchange را انتخاب کنید</li>
                  <li>فایل CSV یا JSON را آپلود کنید</li>
                  <li>دکمه "Inject & Train" رو بزنید</li>
                  <li>مغز اتوماتیک نسبت‌ها را محاسبه و یادگیری‌ها را ذخیره می‌کنه</li>
                </ol>
              </div>

              <div className="p-4 bg-gray-800/50 rounded-lg">
                <h4 className="font-medium text-gray-300 mb-2">💡 مرحله ۳: چرخه یادگیری</h4>
                <div className="text-xs space-y-1">
                  <p>• هر ۱۲ ساعت داده → ۱ رکورد یادگیری کوتاه‌مدت ذخیره میشه</p>
                  <p>• هر ۶۰ رکورد کوتاه‌مدت → ۱ متا-یادگیری ۳۰ روزه تولید میشه</p>
                  <p>• هر Paper Trade → الگوی تغییر روند per symbol ذخیره میشه</p>
                  <p>• نسبت‌های مفید ✅ active میمونن، بقیه ❌ archived میشن</p>
                  <p>• <span className="text-yellow-400">فقط یادگیری‌ها نگه داشته میشن، نه کل دیتا</span></p>
                </div>
              </div>

              <div className="p-4 bg-orange-500/10 border border-orange-500/20 rounded-lg">
                <div className="flex items-center gap-2 mb-2">
                  <AlertTriangle size={14} className="text-orange-400" />
                  <span className="font-medium text-orange-400">نکته مهم</span>
                </div>
                <p className="text-xs">
                  اگه داده OI و Funding Rate نداشته باشید، مغز از تغییرات قیمت تخمین می‌زنه.
                  برای بهترین نتیجه، از CoinGlass یا Binance API داده با OI و Funding بگیرید.
                </p>
              </div>
            </div>
          </div>

          {/* Python Script Helper */}
          <div className="bg-gray-900 rounded-xl border border-gray-800 p-5">
            <h3 className="font-medium flex items-center gap-2 mb-3">
              <FileSpreadsheet size={16} className="text-green-400" />
              Python Script for Data Download
            </h3>
            <pre className="bg-gray-950 rounded-lg p-4 text-xs text-green-400 overflow-x-auto">
{`# pip install ccxt pandas
import ccxt
import pandas as pd

exchange = ccxt.binance({'options': {'defaultType': 'future'}})

# Download 1-minute klines
ohlcv = exchange.fetch_ohlcv('BTC/USDT:USDT', '1m', limit=1500)

df = pd.DataFrame(ohlcv, columns=[
    'timestamp', 'open', 'high', 'low', 'close', 'volume'
])

# Add Open Interest (optional)
# oi = exchange.fetch_open_interest('BTC/USDT:USDT')
# df['openInterest'] = oi['openInterestAmount']

# Add Funding Rate (optional)
# fr = exchange.fetch_funding_rate('BTC/USDT:USDT')
# df['fundingRate'] = fr['fundingRate']

df.to_csv('btcusdt_1m.csv', index=False)
print(f"Saved {len(df)} candles")`}
            </pre>
          </div>
        </div>
      )}

      {/* ============ PREVIEW TAB ============ */}
      {activeTab === 'preview' && (
        <div className="space-y-4">
          {previewData.length > 0 ? (
            <div className="bg-gray-900 rounded-xl border border-gray-800 p-4">
              <h3 className="text-sm text-gray-400 mb-3 flex items-center gap-2">
                <Eye size={16} /> Data Preview (first 20 rows of {fileData.length})
              </h3>
              <div className="overflow-x-auto">
                <table className="w-full text-xs">
                  <thead>
                    <tr className="text-gray-500 border-b border-gray-800">
                      <th className="text-left py-2">#</th>
                      <th className="text-left py-2">Date</th>
                      <th className="text-right py-2">Open</th>
                      <th className="text-right py-2">High</th>
                      <th className="text-right py-2">Low</th>
                      <th className="text-right py-2">Close</th>
                      <th className="text-right py-2">Volume</th>
                      <th className="text-right py-2">OI</th>
                      <th className="text-right py-2">FR</th>
                    </tr>
                  </thead>
                  <tbody>
                    {previewData.map((row, i) => (
                      <tr key={i} className="border-b border-gray-800/50">
                        <td className="py-1.5 text-gray-600">{i + 1}</td>
                        <td className="py-1.5 text-gray-400">{new Date(row.timestamp).toLocaleString()}</td>
                        <td className="py-1.5 text-right">{row.open.toLocaleString()}</td>
                        <td className="py-1.5 text-right text-green-400">{row.high.toLocaleString()}</td>
                        <td className="py-1.5 text-right text-red-400">{row.low.toLocaleString()}</td>
                        <td className="py-1.5 text-right font-medium">{row.close.toLocaleString()}</td>
                        <td className="py-1.5 text-right text-gray-400">{row.volume.toFixed(2)}</td>
                        <td className="py-1.5 text-right text-cyan-400">{row.openInterest?.toLocaleString() || '-'}</td>
                        <td className="py-1.5 text-right text-yellow-400">{row.fundingRate?.toFixed(6) || '-'}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          ) : (
            <div className="text-center py-12 bg-gray-900 rounded-xl border border-gray-800">
              <FileSpreadsheet size={40} className="mx-auto text-gray-600 mb-4" />
              <p className="text-gray-400">No file loaded yet</p>
              <p className="text-gray-500 text-sm mt-1">Upload a CSV or JSON file in the "Inject Data" tab</p>
            </div>
          )}

          {/* Current Brain Memory Stats */}
          <div className="bg-gray-900 rounded-xl border border-gray-800 p-4">
            <h3 className="text-sm text-gray-400 mb-3 flex items-center gap-2">
              <Brain size={16} className="text-purple-400" /> Current Brain Memory
            </h3>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <MiniInfo label="Symbol Learnings" value={String(learningEntries.length)} />
              <MiniInfo label="Total 12h Records" value={String(learningEntries.reduce((s, [_, sl]) => s + sl.shortTermLearnings.length, 0))} />
              <MiniInfo label="Total 30d Records" value={String(learningEntries.reduce((s, [_, sl]) => s + sl.longTermLearnings.length, 0))} />
              <MiniInfo label="Reversal Patterns" value={String(learningEntries.reduce((s, [_, sl]) => s + sl.reversalPatterns.length, 0))} />
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function MiniInfo({ label, value }: { label: string; value: string }) {
  return (
    <div className="text-center p-2 bg-gray-800/50 rounded-lg">
      <div className="text-sm font-bold text-gray-200">{value}</div>
      <div className="text-xs text-gray-500">{label}</div>
    </div>
  );
}
