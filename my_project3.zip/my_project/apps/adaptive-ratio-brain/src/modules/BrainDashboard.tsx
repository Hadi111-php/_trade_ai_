import { useEffect, useState, useCallback } from 'react';
import { useBrainStore } from '../brain/brainStore';
import { useAppStore } from '../store/appStore';
import { EXCHANGES, type ExchangeName } from '../lib/exchangeApi';
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, Cell, LineChart, Line, CartesianGrid, PieChart, Pie } from 'recharts';
import {
  Brain, Play, Square, RefreshCw, AlertTriangle, TrendingUp, TrendingDown,
  Activity, Target, Zap, Shield, Eye, Settings2, Trash2, ChevronDown, ChevronUp,
  Globe, BookOpen
} from 'lucide-react';

const BRAIN_SYMBOLS = [
  'BTCUSDT', 'ETHUSDT', 'BNBUSDT', 'SOLUSDT', 'XRPUSDT',
  'DOGEUSDT', 'ADAUSDT', 'AVAXUSDT', 'LINKUSDT', 'APTUSDT',
];

export function BrainDashboard() {
  const brainStore = useBrainStore();
  const { setSelectedSymbol, setPage } = useAppStore();
  const [activeTab, setActiveTab] = useState<'overview' | 'signals' | 'trades' | 'learning' | 'feedback' | 'config'>('overview');
  const [showTradeForm, setShowTradeForm] = useState(false);
  const [tradeSymbol, setTradeSymbol] = useState('BTCUSDT');
  const [tradeExchange, setTradeExchange] = useState<ExchangeName>('binance');
  const [tradeSide, setTradeSide] = useState<'LONG' | 'SHORT'>('LONG');
  const [tradeQty, setTradeQty] = useState('0.01');
  const [tradeLeverage, setTradeLeverage] = useState('10');
  const [tradeSL, setTradeSL] = useState('2');
  const [tradeTP, setTradeTP] = useState('4');
  const [expandedSignal, setExpandedSignal] = useState<string | null>(null);

  useEffect(() => {
    const interval = setInterval(() => { brainStore.updatePrices(); }, 10000);
    return () => clearInterval(interval);
  }, [brainStore]);

  useEffect(() => { brainStore.checkExchanges(); }, []);

  const handleStartScan = useCallback(() => {
    brainStore.startAutoScan(BRAIN_SYMBOLS, 60000);
  }, [brainStore]);

  const handleStopScan = useCallback(() => {
    brainStore.stopAutoScan();
  }, [brainStore]);

  const handleManualScan = useCallback(() => {
    brainStore.runScan(BRAIN_SYMBOLS);
  }, [brainStore]);

  const handleOpenTrade = async () => {
    await brainStore.openTrade({
      symbol: tradeSymbol,
      exchange: tradeExchange,
      side: tradeSide,
      quantity: parseFloat(tradeQty),
      leverage: parseFloat(tradeLeverage),
      stopLossPercent: parseFloat(tradeSL),
      takeProfitPercent: parseFloat(tradeTP),
    });
    setShowTradeForm(false);
  };

  const outputs = Array.from(brainStore.outputs.values());
  const stats = brainStore.tradeStats;
  const openTrades = brainStore.paperTrades.filter(t => t.status === 'OPEN');
  const closedTrades = brainStore.paperTrades.filter(t => t.status !== 'OPEN');

  const signalDistribution = [
    { name: 'BUY', value: outputs.filter(o => o.currentSignal === 'BUY').length, color: '#4ade80' },
    { name: 'SELL', value: outputs.filter(o => o.currentSignal === 'SELL').length, color: '#f87171' },
    { name: 'HOLD', value: outputs.filter(o => o.currentSignal === 'HOLD').length, color: '#6b7280' },
  ];

  const confidenceData = outputs
    .sort((a, b) => b.confidenceScore - a.confidenceScore)
    .map(o => ({
      symbol: o.symbol.replace('USDT', ''),
      confidence: Math.round(o.confidenceScore * 100),
      signal: o.currentSignal,
    }));

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex flex-wrap gap-3 items-center">
        <div className="flex items-center gap-2">
          <Brain size={24} className="text-purple-400" />
          <div>
            <h2 className="text-lg font-bold bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">
              Adaptive Ratio Brain
            </h2>
            <p className="text-xs text-gray-500">Multi-Exchange Futures Trap Detection</p>
          </div>
        </div>

        {/* Exchange Status Dots */}
        <div className="flex items-center gap-2 ml-2">
          {brainStore.exchangeStatus.map(es => (
            <div key={es.exchange} className="flex items-center gap-1" title={`${es.exchange}: ${es.status} (${es.latency}ms)`}>
              <div className={`w-2 h-2 rounded-full ${es.status === 'OK' ? 'bg-green-400' : es.status === 'SLOW' ? 'bg-yellow-400' : 'bg-red-400'}`} />
              <span className="text-xs text-gray-500">{EXCHANGES[es.exchange]?.label}</span>
            </div>
          ))}
        </div>

        <div className="flex gap-2 ml-auto">
          {!brainStore.scanInterval ? (
            <button onClick={handleStartScan}
              className="flex items-center gap-2 px-4 py-2 bg-green-500/20 text-green-400 rounded-lg border border-green-500/30 hover:bg-green-500/30">
              <Play size={14} /> Start Auto
            </button>
          ) : (
            <button onClick={handleStopScan}
              className="flex items-center gap-2 px-4 py-2 bg-red-500/20 text-red-400 rounded-lg border border-red-500/30 hover:bg-red-500/30">
              <Square size={14} /> Stop
            </button>
          )}
          <button onClick={handleManualScan} disabled={brainStore.isRunning}
            className="flex items-center gap-2 px-4 py-2 bg-purple-500/20 text-purple-400 rounded-lg border border-purple-500/30 hover:bg-purple-500/30 disabled:opacity-50">
            <RefreshCw size={14} className={brainStore.isRunning ? 'animate-spin' : ''} />
            {brainStore.isRunning ? `${brainStore.scanningSymbol}/${brainStore.scanningExchange}` : 'Scan'}
          </button>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-6 gap-3">
        <MiniStat icon={<Activity size={16} className="text-cyan-400" />} label="Status" value={brainStore.scanInterval ? 'Active' : 'Idle'} color={brainStore.scanInterval ? 'text-green-400' : 'text-gray-400'} />
        <MiniStat icon={<Globe size={16} className="text-blue-400" />} label="Exchanges" value={`${brainStore.exchangeStatus.filter(e => e.status === 'OK').length}/${brainStore.exchangeStatus.length}`} />
        <MiniStat icon={<Target size={16} className="text-yellow-400" />} label="Signals" value={`${outputs.filter(o => o.currentSignal !== 'HOLD').length} active`} />
        <MiniStat icon={<TrendingUp size={16} className="text-green-400" />} label="Win Rate" value={`${stats.winRate.toFixed(0)}%`} color={stats.winRate >= 50 ? 'text-green-400' : 'text-red-400'} />
        <MiniStat icon={<Zap size={16} className="text-orange-400" />} label="Open Trades" value={String(stats.openTrades)} />
        <MiniStat icon={<Shield size={16} className={stats.totalPnl >= 0 ? 'text-green-400' : 'text-red-400'} />} label="Total P&L" value={`${stats.totalPnl >= 0 ? '+' : ''}$${stats.totalPnl.toFixed(2)}`} color={stats.totalPnl >= 0 ? 'text-green-400' : 'text-red-400'} />
      </div>

      {/* Tabs */}
      <div className="flex gap-1 border-b border-gray-800 pb-1 overflow-x-auto">
        {(['overview', 'signals', 'trades', 'learning', 'feedback', 'config'] as const).map(tab => (
          <button key={tab} onClick={() => setActiveTab(tab)}
            className={`px-4 py-2 rounded-t-lg text-sm capitalize whitespace-nowrap ${activeTab === tab ? 'bg-gray-800 text-purple-400 border border-gray-700 border-b-0' : 'text-gray-500 hover:text-gray-300'}`}>
            {tab === 'learning' ? '🧠 Learning' : tab}
          </button>
        ))}
      </div>

      {/* Tab Content */}
      {activeTab === 'overview' && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
            <div className="lg:col-span-2 bg-gray-900 rounded-xl border border-gray-800 p-4">
              <h3 className="text-sm text-gray-400 mb-3">🎯 Signal Confidence</h3>
              {confidenceData.length > 0 ? (
                <ResponsiveContainer width="100%" height={250}>
                  <BarChart data={confidenceData}>
                    <CartesianGrid stroke="#1f2937" />
                    <XAxis dataKey="symbol" tick={{ fill: '#9ca3af', fontSize: 11 }} />
                    <YAxis domain={[0, 100]} tick={{ fill: '#6b7280', fontSize: 10 }} />
                    <Tooltip contentStyle={{ background: '#1f2937', border: '1px solid #374151', borderRadius: '8px' }} />
                    <Bar dataKey="confidence" radius={[4, 4, 0, 0]}>
                      {confidenceData.map((e, i) => (
                        <Cell key={i} fill={e.signal === 'BUY' ? '#4ade80' : e.signal === 'SELL' ? '#f87171' : '#6b7280'} />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              ) : <div className="flex items-center justify-center h-[250px] text-gray-500">Run a scan</div>}
            </div>
            <div className="bg-gray-900 rounded-xl border border-gray-800 p-4">
              <h3 className="text-sm text-gray-400 mb-3">📊 Distribution</h3>
              {signalDistribution.some(s => s.value > 0) ? (
                <ResponsiveContainer width="100%" height={180}>
                  <PieChart>
                    <Pie data={signalDistribution.filter(s => s.value > 0)} cx="50%" cy="50%" innerRadius={50} outerRadius={75} dataKey="value"
                      label={({ name, value }) => `${name}:${value}`}>
                      {signalDistribution.filter(s => s.value > 0).map((e, i) => <Cell key={i} fill={e.color} />)}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              ) : <div className="flex items-center justify-center h-[180px] text-gray-500 text-sm">No data</div>}
              <div className="mt-4 pt-4 border-t border-gray-800 space-y-2 text-xs">
                <div className="flex justify-between"><span className="text-gray-500">Total Trades</span><span>{stats.totalTrades}</span></div>
                <div className="flex justify-between"><span className="text-gray-500">Win/Loss</span><span><span className="text-green-400">{stats.wins}</span>/<span className="text-red-400">{stats.losses}</span></span></div>
                <div className="flex justify-between"><span className="text-gray-500">Best</span><span className="text-green-400">{stats.bestTrade.toFixed(2)}%</span></div>
                <div className="flex justify-between"><span className="text-gray-500">Worst</span><span className="text-red-400">{stats.worstTrade.toFixed(2)}%</span></div>
              </div>
            </div>
          </div>

          {/* Active Signals Grid */}
          <div className="bg-gray-900 rounded-xl border border-gray-800 p-4">
            <h3 className="text-sm text-gray-400 mb-3">🧠 Brain Signals</h3>
            {outputs.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                {outputs.map(o => (
                  <button key={o.symbol} onClick={() => { setSelectedSymbol(o.symbol); setPage('market'); }}
                    className={`p-3 rounded-lg border text-left transition hover:opacity-80 ${
                      o.currentSignal === 'BUY' ? 'bg-green-500/5 border-green-500/20' :
                      o.currentSignal === 'SELL' ? 'bg-red-500/5 border-red-500/20' : 'bg-gray-800/50 border-gray-700'
                    }`}>
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <span className="font-medium text-sm">{o.symbol.replace('USDT', '')}</span>
                        <span className="text-xs text-gray-500" style={{ color: EXCHANGES[o.exchange]?.color }}>{o.exchange}</span>
                      </div>
                      <span className={`text-xs px-2 py-0.5 rounded font-medium ${
                        o.currentSignal === 'BUY' ? 'bg-green-500/20 text-green-400' :
                        o.currentSignal === 'SELL' ? 'bg-red-500/20 text-red-400' : 'bg-gray-700 text-gray-400'
                      }`}>{o.currentSignal}</span>
                    </div>
                    <div className="grid grid-cols-2 gap-1 text-xs">
                      <div className="text-gray-500">Conf: <span className={o.confidenceScore > 0.6 ? 'text-green-400' : 'text-gray-400'}>{(o.confidenceScore * 100).toFixed(0)}%</span></div>
                      <div className="text-gray-500">Trap: <span className={o.divergenceTrap.type !== 'NONE' ? 'text-orange-400' : 'text-gray-400'}>{o.divergenceTrap.type === 'NONE' ? '-' : o.divergenceTrap.type}</span></div>
                      {o.crossExchangeData && (
                        <>
                          <div className="text-gray-500">PDiv: <span className="text-cyan-400">{o.crossExchangeData.priceDivergence.toFixed(3)}%</span></div>
                          <div className="text-gray-500">Lead: <span className="text-yellow-400">{o.crossExchangeData.leadExchange || '-'}</span></div>
                        </>
                      )}
                    </div>
                  </button>
                ))}
              </div>
            ) : (
              <div className="text-center py-8 text-gray-500"><Brain size={32} className="mx-auto mb-2 opacity-50" /><p>Start a scan</p></div>
            )}
          </div>
        </div>
      )}

      {activeTab === 'signals' && (
        <div className="space-y-4">
          {outputs.filter(o => o.currentSignal !== 'HOLD').map(o => (
            <div key={o.symbol} className={`rounded-xl border ${o.currentSignal === 'BUY' ? 'bg-green-500/5 border-green-500/20' : 'bg-red-500/5 border-red-500/20'}`}>
              <button className="w-full p-4 flex items-center justify-between" onClick={() => setExpandedSignal(expandedSignal === o.symbol ? null : o.symbol)}>
                <div className="flex items-center gap-3">
                  {o.currentSignal === 'BUY' ? <TrendingUp className="text-green-400" size={20} /> : <TrendingDown className="text-red-400" size={20} />}
                  <div className="text-left">
                    <div className="font-medium">{o.symbol.replace('USDT', '')}/USDT</div>
                    <div className="text-xs text-gray-500">{o.exchange} • {o.marketState}</div>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <div className="text-right">
                    <div className={`font-bold ${o.currentSignal === 'BUY' ? 'text-green-400' : 'text-red-400'}`}>{o.currentSignal}</div>
                    <div className="text-xs text-gray-500">{(o.confidenceScore * 100).toFixed(0)}%</div>
                  </div>
                  {expandedSignal === o.symbol ? <ChevronUp size={16} /> : <ChevronDown size={16} />}
                </div>
              </button>
              {expandedSignal === o.symbol && (
                <div className="px-4 pb-4 border-t border-gray-800">
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mt-3">
                    <DetailBox label="OI Ratio" value={`${(o.ratios.oiRatio * 100).toFixed(3)}%`} />
                    <DetailBox label="Vol Ratio" value={`${o.ratios.volRatio.toFixed(2)}x`} />
                    <DetailBox label="Price Mom" value={`${(o.ratios.priceRatio * 100).toFixed(3)}%`} />
                    <DetailBox label="Funding" value={`${(o.ratios.fundingRate * 100).toFixed(4)}%`} />
                  </div>
                  {o.divergenceTrap.type !== 'NONE' && (
                    <div className="mt-3 p-3 bg-orange-500/10 rounded-lg border border-orange-500/20">
                      <div className="flex items-center gap-2 mb-1">
                        <AlertTriangle size={14} className="text-orange-400" />
                        <span className="text-sm font-medium text-orange-400">{o.divergenceTrap.type}</span>
                        <span className="text-xs text-gray-500">({(o.divergenceTrap.confidence * 100).toFixed(0)}%)</span>
                      </div>
                      <p className="text-xs text-gray-400">{o.divergenceTrap.description}</p>
                    </div>
                  )}
                  {o.crossExchangeData && (
                    <div className="mt-3 p-3 bg-blue-500/10 rounded-lg border border-blue-500/20">
                      <div className="flex items-center gap-2 mb-1">
                        <Globe size={14} className="text-blue-400" />
                        <span className="text-sm font-medium text-blue-400">Cross-Exchange</span>
                      </div>
                      <div className="flex gap-3 text-xs">
                        <span>Price Div: <span className="text-cyan-400">{o.crossExchangeData.priceDivergence.toFixed(4)}%</span></span>
                        <span>OI Div: <span className="text-purple-400">{o.crossExchangeData.oiDivergence.toFixed(2)}%</span></span>
                        <span>Lead: <span className="text-yellow-400">{o.crossExchangeData.leadExchange}</span></span>
                      </div>
                    </div>
                  )}
                </div>
              )}
            </div>
          ))}
          {outputs.filter(o => o.currentSignal === 'HOLD').length > 0 && (
            <div>
              <h3 className="text-sm text-gray-400 mb-2">⏸ Hold</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-2">
                {outputs.filter(o => o.currentSignal === 'HOLD').map(o => (
                  <div key={o.symbol} className="p-3 bg-gray-900 rounded-lg border border-gray-800 text-sm">
                    <div className="flex justify-between">
                      <span>{o.symbol.replace('USDT', '')} <span className="text-xs text-gray-600">({o.exchange})</span></span>
                      <span className="text-xs text-gray-500">{(o.confidenceScore * 100).toFixed(0)}%</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
          {outputs.length === 0 && <div className="text-center py-12 text-gray-500"><Brain size={40} className="mx-auto mb-3 opacity-40" /><p>Run a scan first</p></div>}
        </div>
      )}

      {activeTab === 'trades' && (
        <div className="space-y-4">
          <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-6 gap-3">
            <MiniStat icon={<Target size={14} className="text-cyan-400" />} label="Total" value={String(stats.totalTrades)} />
            <MiniStat icon={<TrendingUp size={14} className="text-green-400" />} label="Wins" value={String(stats.wins)} color="text-green-400" />
            <MiniStat icon={<TrendingDown size={14} className="text-red-400" />} label="Losses" value={String(stats.losses)} color="text-red-400" />
            <MiniStat icon={<Activity size={14} className="text-yellow-400" />} label="Win Rate" value={`${stats.winRate.toFixed(1)}%`} color={stats.winRate >= 50 ? 'text-green-400' : 'text-red-400'} />
            <MiniStat icon={<Zap size={14} className="text-green-400" />} label="Avg Win" value={`${stats.avgWin.toFixed(2)}%`} color="text-green-400" />
            <MiniStat icon={<Zap size={14} className="text-red-400" />} label="Avg Loss" value={`${stats.avgLoss.toFixed(2)}%`} color="text-red-400" />
          </div>

          {closedTrades.length > 1 && (
            <div className="bg-gray-900 rounded-xl border border-gray-800 p-4">
              <h3 className="text-sm text-gray-400 mb-3">📈 Equity Curve</h3>
              <ResponsiveContainer width="100%" height={200}>
                <LineChart data={closedTrades.reduce<{ trade: number; equity: number }[]>((acc, t, i) => {
                  const prev = acc.length > 0 ? acc[acc.length - 1].equity : 0;
                  acc.push({ trade: i + 1, equity: prev + t.pnl });
                  return acc;
                }, [])}>
                  <CartesianGrid stroke="#1f2937" />
                  <XAxis dataKey="trade" tick={{ fill: '#6b7280', fontSize: 10 }} />
                  <YAxis tick={{ fill: '#6b7280', fontSize: 10 }} />
                  <Tooltip contentStyle={{ background: '#1f2937', border: '1px solid #374151', borderRadius: '8px' }} />
                  <Line type="monotone" dataKey="equity" stroke="#a855f7" strokeWidth={2} dot={false} />
                </LineChart>
              </ResponsiveContainer>
            </div>
          )}

          <button onClick={() => setShowTradeForm(!showTradeForm)}
            className="flex items-center gap-2 px-4 py-2 bg-purple-500/20 text-purple-400 rounded-lg border border-purple-500/30 hover:bg-purple-500/30">
            {showTradeForm ? '✕ Cancel' : '+ Paper Trade'}
          </button>

          {showTradeForm && (
            <div className="bg-gray-900 rounded-xl border border-gray-800 p-4 space-y-3">
              <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
                <div>
                  <label className="text-xs text-gray-500">Symbol</label>
                  <input value={tradeSymbol} onChange={e => setTradeSymbol(e.target.value.toUpperCase())}
                    className="w-full mt-1 px-3 py-2 bg-gray-800 rounded-lg border border-gray-700 text-sm outline-none" />
                </div>
                <div>
                  <label className="text-xs text-gray-500">Exchange</label>
                  <select value={tradeExchange} onChange={e => setTradeExchange(e.target.value as ExchangeName)}
                    className="w-full mt-1 px-3 py-2 bg-gray-800 rounded-lg border border-gray-700 text-sm outline-none">
                    {Object.values(EXCHANGES).filter(e => e.enabled).map(e => (
                      <option key={e.name} value={e.name}>{e.label}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="text-xs text-gray-500">Side</label>
                  <div className="flex gap-2 mt-1">
                    <button onClick={() => setTradeSide('LONG')} className={`flex-1 py-2 rounded text-xs font-medium ${tradeSide === 'LONG' ? 'bg-green-500/20 text-green-400' : 'bg-gray-800 text-gray-400'}`}>LONG</button>
                    <button onClick={() => setTradeSide('SHORT')} className={`flex-1 py-2 rounded text-xs font-medium ${tradeSide === 'SHORT' ? 'bg-red-500/20 text-red-400' : 'bg-gray-800 text-gray-400'}`}>SHORT</button>
                  </div>
                </div>
                <div>
                  <label className="text-xs text-gray-500">Quantity</label>
                  <input value={tradeQty} onChange={e => setTradeQty(e.target.value)} type="number" step="0.001"
                    className="w-full mt-1 px-3 py-2 bg-gray-800 rounded-lg border border-gray-700 text-sm outline-none" />
                </div>
                <div>
                  <label className="text-xs text-gray-500">Leverage</label>
                  <input value={tradeLeverage} onChange={e => setTradeLeverage(e.target.value)} type="number" min="1" max="125"
                    className="w-full mt-1 px-3 py-2 bg-gray-800 rounded-lg border border-gray-700 text-sm outline-none" />
                </div>
                <div>
                  <label className="text-xs text-gray-500">SL %</label>
                  <input value={tradeSL} onChange={e => setTradeSL(e.target.value)} type="number" step="0.5"
                    className="w-full mt-1 px-3 py-2 bg-gray-800 rounded-lg border border-gray-700 text-sm outline-none" />
                </div>
                <div>
                  <label className="text-xs text-gray-500">TP %</label>
                  <input value={tradeTP} onChange={e => setTradeTP(e.target.value)} type="number" step="0.5"
                    className="w-full mt-1 px-3 py-2 bg-gray-800 rounded-lg border border-gray-700 text-sm outline-none" />
                </div>
              </div>
              <button onClick={handleOpenTrade}
                className={`w-full py-2 rounded-lg text-sm font-medium ${tradeSide === 'LONG' ? 'bg-green-600 hover:bg-green-500' : 'bg-red-600 hover:bg-red-500'}`}>
                Open {tradeSide} on {EXCHANGES[tradeExchange]?.label}
              </button>
            </div>
          )}

          {openTrades.length > 0 && (
            <div className="bg-gray-900 rounded-xl border border-gray-800 p-4">
              <h3 className="text-sm text-gray-400 mb-3">🟢 Open ({openTrades.length})</h3>
              <div className="space-y-2">
                {openTrades.map(t => (
                  <div key={t.id} className="flex flex-wrap items-center justify-between p-3 bg-gray-800/50 rounded-lg gap-2">
                    <div className="flex items-center gap-2">
                      {t.side === 'LONG' ? <TrendingUp size={14} className="text-green-400" /> : <TrendingDown size={14} className="text-red-400" />}
                      <span className="text-sm font-medium">{t.symbol.replace('USDT', '')}</span>
                      <span className="text-xs text-gray-500">{t.exchange}</span>
                      <span className={`text-xs px-1.5 py-0.5 rounded ${t.side === 'LONG' ? 'bg-green-500/20 text-green-400' : 'bg-red-500/20 text-red-400'}`}>
                        {t.side} {t.leverage}x
                      </span>
                    </div>
                    <div className="flex items-center gap-3 text-xs text-gray-400">
                      <span>${t.entryPrice.toLocaleString()}</span>
                      <span>→ ${t.currentPrice.toLocaleString()}</span>
                      <span className={t.pnl >= 0 ? 'text-green-400 font-medium' : 'text-red-400 font-medium'}>
                        {t.pnl >= 0 ? '+' : ''}${t.pnl.toFixed(2)}
                      </span>
                      <button onClick={() => brainStore.closeTrade(t.id)} className="px-2 py-1 bg-yellow-500/20 text-yellow-400 rounded hover:bg-yellow-500/30">Close</button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {closedTrades.length > 0 && (
            <div className="bg-gray-900 rounded-xl border border-gray-800 p-4">
              <h3 className="text-sm text-gray-400 mb-3">📜 History ({closedTrades.length})</h3>
              <div className="overflow-x-auto">
                <table className="w-full text-xs">
                  <thead><tr className="text-gray-500 border-b border-gray-800">
                    <th className="text-left py-2">Symbol</th><th className="text-left py-2">Ex</th><th className="text-left py-2">Side</th>
                    <th className="text-right py-2">Entry</th><th className="text-right py-2">Exit</th><th className="text-right py-2">P&L</th><th className="text-right py-2">Status</th>
                  </tr></thead>
                  <tbody>
                    {closedTrades.slice(-20).reverse().map(t => (
                      <tr key={t.id} className="border-b border-gray-800/50">
                        <td className="py-2">{t.symbol.replace('USDT', '')}</td>
                        <td className="py-2 text-gray-500">{t.exchange}</td>
                        <td className={`py-2 ${t.side === 'LONG' ? 'text-green-400' : 'text-red-400'}`}>{t.side} {t.leverage}x</td>
                        <td className="py-2 text-right">${t.entryPrice.toLocaleString()}</td>
                        <td className="py-2 text-right">${t.currentPrice.toLocaleString()}</td>
                        <td className={`py-2 text-right font-medium ${t.pnl >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                          {t.pnl >= 0 ? '+' : ''}${t.pnl.toFixed(2)} ({t.pnlPercent.toFixed(2)}%)
                        </td>
                        <td className="py-2 text-right">
                          <span className={`px-1.5 py-0.5 rounded ${t.status === 'CLOSED_TP' ? 'bg-green-500/20 text-green-400' : t.status === 'CLOSED_SL' ? 'bg-red-500/20 text-red-400' : 'bg-gray-700 text-gray-400'}`}>
                            {t.status.replace('CLOSED_', '')}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      )}

      {activeTab === 'learning' && (
        <LearningTab symbolLearnings={brainStore.symbolLearnings} />
      )}

      {activeTab === 'feedback' && (
        <div className="space-y-4">
          <div className="bg-gray-900 rounded-xl border border-gray-800 p-4">
            <h3 className="text-sm text-gray-400 mb-3">🔢 Global Ratio Weights</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
              {brainStore.activeRatios.map(r => {
                const total = r.successCount + r.failCount;
                const winRate = total > 0 ? (r.successCount / total) * 100 : 0;
                return (
                  <div key={r.id} className={`p-3 rounded-lg border ${r.status === 'ACTIVE' ? 'bg-gray-800/50 border-gray-700' : 'bg-red-500/5 border-red-500/10 opacity-60'}`}>
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-sm font-medium">{r.name}</span>
                      <span className={`text-xs px-1.5 py-0.5 rounded ${r.status === 'ACTIVE' ? 'bg-green-500/20 text-green-400' : 'bg-red-500/20 text-red-400'}`}>{r.status}</span>
                    </div>
                    <div className="space-y-1 text-xs">
                      <div className="flex justify-between"><span className="text-gray-500">Weight:</span><span className="text-yellow-400">{r.weight.toFixed(2)}</span></div>
                      <div className="flex justify-between"><span className="text-gray-500">Win/Loss:</span><span><span className="text-green-400">{r.successCount}</span>/<span className="text-red-400">{r.failCount}</span></span></div>
                      <div className="flex justify-between"><span className="text-gray-500">Win Rate:</span><span className={winRate >= 50 ? 'text-green-400' : 'text-red-400'}>{winRate.toFixed(0)}%</span></div>
                      <div className="bg-gray-700 rounded-full h-1.5 mt-1">
                        <div className="bg-yellow-400 rounded-full h-1.5" style={{ width: `${Math.min(100, r.weight / 3 * 100)}%` }} />
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {brainStore.feedbackLog.filter(f => f.result !== 'PENDING').length > 0 && (
            <div className="bg-gray-900 rounded-xl border border-gray-800 p-4">
              <h3 className="text-sm text-gray-400 mb-3">📊 Feedback Log</h3>
              <div className="overflow-x-auto">
                <table className="w-full text-xs">
                  <thead><tr className="text-gray-500 border-b border-gray-800">
                    <th className="text-left py-2">Symbol</th><th className="text-left py-2">Ex</th><th className="text-left py-2">Type</th>
                    <th className="text-right py-2">P&L%</th><th className="text-right py-2">MFE</th><th className="text-right py-2">MAE</th>
                    <th className="text-center py-2">Result</th>
                  </tr></thead>
                  <tbody>
                    {brainStore.feedbackLog.filter(f => f.result !== 'PENDING').slice(-20).reverse().map(f => (
                      <tr key={f.id} className="border-b border-gray-800/50">
                        <td className="py-2">{f.symbol.replace('USDT', '')}</td>
                        <td className="py-2 text-gray-500">{f.exchange}</td>
                        <td className={`py-2 ${f.signalType === 'BUY' ? 'text-green-400' : 'text-red-400'}`}>{f.signalType}</td>
                        <td className={`py-2 text-right ${(f.pnlPercent || 0) >= 0 ? 'text-green-400' : 'text-red-400'}`}>{f.pnlPercent?.toFixed(3) || '-'}%</td>
                        <td className="py-2 text-right text-green-400">${f.maxFavorableExcursion.toLocaleString()}</td>
                        <td className="py-2 text-right text-red-400">${f.maxAdverseExcursion.toLocaleString()}</td>
                        <td className="py-2 text-center">
                          <span className={`px-1.5 py-0.5 rounded ${f.result === 'SUCCESS' ? 'bg-green-500/20 text-green-400' : 'bg-red-500/20 text-red-400'}`}>{f.result}</span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      )}

      {activeTab === 'config' && (
        <ConfigTab config={brainStore.brainConfig} onUpdateConfig={brainStore.updateConfig} onReset={brainStore.resetBrain} />
      )}
    </div>
  );
}

// ========== SUB COMPONENTS ==========

function MiniStat({ icon, label, value, color = 'text-white' }: { icon: React.ReactNode; label: string; value: string; color?: string }) {
  return (
    <div className="bg-gray-900 rounded-lg border border-gray-800 p-3 flex items-center gap-2">
      {icon}<div><p className="text-xs text-gray-500">{label}</p><p className={`text-sm font-semibold ${color}`}>{value}</p></div>
    </div>
  );
}

function DetailBox({ label, value }: { label: string; value: string }) {
  return (
    <div className="p-2 bg-gray-800/50 rounded text-center">
      <div className="text-xs text-gray-500">{label}</div>
      <div className="text-sm font-medium">{value}</div>
    </div>
  );
}

function LearningTab({ symbolLearnings }: { symbolLearnings: Map<string, import('../brain/types').SymbolLearning> }) {
  const entries = Array.from(symbolLearnings.entries());

  return (
    <div className="space-y-4">
      <div className="bg-gray-900 rounded-xl border border-gray-800 p-4">
        <div className="flex items-center gap-2 mb-3">
          <BookOpen size={18} className="text-purple-400" />
          <h3 className="text-sm text-gray-400">🧠 Per-Symbol Learning Records</h3>
          <span className="text-xs text-gray-600 ml-auto">{entries.length} symbols</span>
        </div>

        {entries.length === 0 ? (
          <div className="text-center py-8 text-gray-500">
            <Brain size={32} className="mx-auto mb-2 opacity-40" />
            <p>No learning data yet. Brain learns every 12 hours of scanning.</p>
            <p className="text-xs text-gray-600 mt-1">Every 60 records → meta-learning (30d)</p>
          </div>
        ) : (
          <div className="space-y-3">
            {entries.map(([key, sl]) => {
              const usefulPatterns = sl.reversalPatterns.filter(p => p.useful).length;
              const totalPatterns = sl.reversalPatterns.length;
              return (
                <div key={key} className="p-4 bg-gray-800/50 rounded-lg border border-gray-700">
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-2">
                      <span className="font-medium">{sl.symbol.replace('USDT', '')}/USDT</span>
                      <span className="text-xs px-1.5 py-0.5 rounded bg-gray-700" style={{ color: EXCHANGES[sl.exchange]?.color }}>
                        {sl.exchange}
                      </span>
                    </div>
                    <span className="text-xs text-gray-500">Updated: {new Date(sl.lastUpdated).toLocaleString()}</span>
                  </div>

                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-3">
                    <div className="text-center p-2 bg-gray-900/50 rounded">
                      <div className="text-lg font-bold text-cyan-400">{sl.shortTermLearnings.length}</div>
                      <div className="text-xs text-gray-500">12h Records</div>
                    </div>
                    <div className="text-center p-2 bg-gray-900/50 rounded">
                      <div className="text-lg font-bold text-purple-400">{sl.longTermLearnings.length}</div>
                      <div className="text-xs text-gray-500">30d Meta</div>
                    </div>
                    <div className="text-center p-2 bg-gray-900/50 rounded">
                      <div className="text-lg font-bold text-green-400">{usefulPatterns}/{totalPatterns}</div>
                      <div className="text-xs text-gray-500">Useful Patterns</div>
                    </div>
                    <div className="text-center p-2 bg-gray-900/50 rounded">
                      <div className="text-lg font-bold text-yellow-400">{Object.keys(sl.ratioWeights).length}</div>
                      <div className="text-xs text-gray-500">Custom Weights</div>
                    </div>
                  </div>

                  {/* Per-symbol ratio weights */}
                  {Object.keys(sl.ratioWeights).length > 0 && (
                    <div className="mb-3">
                      <div className="text-xs text-gray-500 mb-1">Per-Symbol Ratio Weights:</div>
                      <div className="flex flex-wrap gap-2">
                        {Object.entries(sl.ratioWeights).map(([ratioId, rw]) => (
                          <span key={ratioId} className={`text-xs px-2 py-1 rounded border ${rw.active ? 'border-green-500/20 bg-green-500/5 text-green-400' : 'border-red-500/20 bg-red-500/5 text-red-400'}`}>
                            {ratioId}: {rw.weight.toFixed(2)} ({rw.success}✓/{rw.fail}✗) {rw.active ? '✅' : '❌'}
                          </span>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Recent 12h learnings */}
                  {sl.shortTermLearnings.length > 0 && (
                    <div>
                      <div className="text-xs text-gray-500 mb-1">Recent 12h Learnings:</div>
                      <div className="overflow-x-auto">
                        <div className="flex gap-2">
                          {sl.shortTermLearnings.slice(-5).map((lr, i) => (
                            <div key={i} className="min-w-[120px] p-2 bg-gray-900/50 rounded text-xs">
                              <div className="text-gray-500">{new Date(lr.timestamp).toLocaleDateString()}</div>
                              <div className={lr.dominantSignal === 'BUY' ? 'text-green-400' : lr.dominantSignal === 'SELL' ? 'text-red-400' : 'text-gray-400'}>
                                {lr.dominantSignal} ({(lr.confidence * 100).toFixed(0)}%)
                              </div>
                              <div className="text-gray-600">{lr.sampleCount} samples</div>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Philosophy */}
      <div className="bg-gray-900 rounded-xl border border-gray-800 p-5">
        <h3 className="font-medium text-gray-300 mb-3">🧬 Brain Learning Architecture</h3>
        <ul className="space-y-2 text-sm text-gray-400">
          <li>• هر ۱۲ ساعت → یادگیری نسبت‌ها و ذخیره (Short-Term Learning)</li>
          <li>• هر ۶۰ رکورد ۱۲ ساعته → متا-یادگیری ۳۰ روزه (Long-Term Meta-Learning)</li>
          <li>• هر Paper Trade → ذخیره الگوی تغییر روند per symbol per exchange</li>
          <li>• نسبت‌های مفید → active=true ✅ | نسبت‌های ناکارآمد → active=false ❌</li>
          <li>• وزن‌ها per symbol تنظیم می‌شن → هر ارز رفتار خودش رو داره</li>
          <li>• فقط یادگیری‌ها ذخیره میشن، نه کل دیتا → فضای بهینه</li>
        </ul>
      </div>
    </div>
  );
}

function ConfigTab({ config, onUpdateConfig, onReset }: {
  config: import('../brain/types').BrainConfig;
  onUpdateConfig: (c: Partial<import('../brain/types').BrainConfig>) => void;
  onReset: () => void;
}) {
  const [local, setLocal] = useState({ ...config });
  const handleSave = () => onUpdateConfig(local);

  return (
    <div className="space-y-4 max-w-2xl">
      <div className="bg-gray-900 rounded-xl border border-gray-800 p-5">
        <div className="flex items-center gap-2 mb-4">
          <Settings2 size={18} className="text-purple-400" />
          <h3 className="font-medium">Brain Configuration</h3>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <CInput label="Tracking Candles" value={local.trackingCandles} onChange={v => setLocal({ ...local, trackingCandles: v })} />
          <CInput label="Short-Term Window (hours)" value={local.shortTermWindowHours} onChange={v => setLocal({ ...local, shortTermWindowHours: v })} />
          <CInput label="Max 12h Records" value={local.maxLearningRecords12h} onChange={v => setLocal({ ...local, maxLearningRecords12h: v })} />
          <CInput label="Max 30d Records" value={local.maxLearningRecords30d} onChange={v => setLocal({ ...local, maxLearningRecords30d: v })} />
          <CInput label="Weight Increment" value={local.weightIncrement} onChange={v => setLocal({ ...local, weightIncrement: v })} step={0.05} />
          <CInput label="Weight Decrement" value={local.weightDecrement} onChange={v => setLocal({ ...local, weightDecrement: v })} step={0.05} />
          <CInput label="Min Confidence" value={local.minConfidence} onChange={v => setLocal({ ...local, minConfidence: v })} step={0.05} />
          <CInput label="OI Threshold" value={local.trapThresholdOI} onChange={v => setLocal({ ...local, trapThresholdOI: v })} step={0.005} />
          <CInput label="Vol Threshold" value={local.trapThresholdVol} onChange={v => setLocal({ ...local, trapThresholdVol: v })} step={0.1} />
          <CInput label="Price Threshold" value={local.trapThresholdPrice} onChange={v => setLocal({ ...local, trapThresholdPrice: v })} step={0.001} />
        </div>

        {/* Enabled Exchanges */}
        <div className="mt-4">
          <label className="text-xs text-gray-500 mb-2 block">Enabled Exchanges</label>
          <div className="flex flex-wrap gap-2">
            {Object.values(EXCHANGES).map(ex => {
              const enabled = local.enabledExchanges.includes(ex.name);
              return (
                <button key={ex.name} onClick={() => {
                  setLocal({
                    ...local,
                    enabledExchanges: enabled
                      ? local.enabledExchanges.filter(e => e !== ex.name)
                      : [...local.enabledExchanges, ex.name],
                  });
                }}
                  className={`px-3 py-1.5 rounded text-xs border ${enabled ? 'border-green-500/30 bg-green-500/10 text-green-400' : 'border-gray-700 bg-gray-800 text-gray-500'}`}>
                  {ex.label} {enabled ? '✓' : '✗'}
                </button>
              );
            })}
          </div>
        </div>

        <div className="flex gap-3 mt-5">
          <button onClick={handleSave} className="flex items-center gap-2 px-5 py-2 bg-purple-600 hover:bg-purple-500 rounded-lg text-sm font-medium">
            <Settings2 size={14} /> Save
          </button>
          <button onClick={onReset} className="flex items-center gap-2 px-4 py-2 bg-red-500/20 text-red-400 rounded-lg text-sm hover:bg-red-500/30">
            <Trash2 size={14} /> Reset Brain
          </button>
        </div>
      </div>
    </div>
  );
}

function CInput({ label, value, onChange, step = 1 }: { label: string; value: number; onChange: (v: number) => void; step?: number }) {
  return (
    <div>
      <label className="text-xs text-gray-500">{label}</label>
      <input value={value} onChange={e => onChange(parseFloat(e.target.value) || 0)} type="number" step={step}
        className="w-full mt-1 px-3 py-2 bg-gray-800 rounded-lg border border-gray-700 text-sm outline-none focus:border-purple-500" />
    </div>
  );
}
