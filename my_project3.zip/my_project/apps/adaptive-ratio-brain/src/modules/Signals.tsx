import { useEffect, useState, useCallback } from 'react';
import { getKlines, getFuturesTicker } from '../lib/binanceApi';
import { generateSignal, type SignalStrength } from '../lib/indicators';
import { useAppStore } from '../store/appStore';
import { Radio, RefreshCw, ArrowUp, ArrowDown, Minus } from 'lucide-react';

interface SymbolSignal {
  symbol: string;
  price: number;
  change: number;
  signal: SignalStrength;
  score: number;
  reasons: string[];
  loading: boolean;
}

const SCAN_SYMBOLS = [
  'BTCUSDT', 'ETHUSDT', 'BNBUSDT', 'SOLUSDT', 'XRPUSDT',
  'DOGEUSDT', 'ADAUSDT', 'AVAXUSDT', 'DOTUSDT', 'LINKUSDT',
  'MATICUSDT', 'UNIUSDT', 'LTCUSDT', 'ATOMUSDT', 'APTUSDT',
  'ARBUSDT', 'OPUSDT', 'NEARUSDT', 'FILUSDT', 'RUNEUSDT',
];

function signalColor(signal: SignalStrength): string {
  switch (signal) {
    case 'STRONG_BUY': return 'text-green-400';
    case 'BUY': return 'text-green-300';
    case 'NEUTRAL': return 'text-gray-400';
    case 'SELL': return 'text-red-300';
    case 'STRONG_SELL': return 'text-red-400';
  }
}

function signalBg(signal: SignalStrength): string {
  switch (signal) {
    case 'STRONG_BUY': return 'bg-green-500/10 border-green-500/20';
    case 'BUY': return 'bg-green-500/5 border-green-500/10';
    case 'NEUTRAL': return 'bg-gray-500/5 border-gray-500/10';
    case 'SELL': return 'bg-red-500/5 border-red-500/10';
    case 'STRONG_SELL': return 'bg-red-500/10 border-red-500/20';
  }
}

function SignalIcon({ signal }: { signal: SignalStrength }) {
  if (signal === 'STRONG_BUY' || signal === 'BUY') return <ArrowUp className="text-green-400" size={18} />;
  if (signal === 'STRONG_SELL' || signal === 'SELL') return <ArrowDown className="text-red-400" size={18} />;
  return <Minus className="text-gray-400" size={18} />;
}

export function Signals() {
  const { setSelectedSymbol, setPage, addSignal } = useAppStore();
  const [signals, setSignals] = useState<SymbolSignal[]>([]);
  const [scanning, setScanning] = useState(false);
  const [timeframe, setTimeframe] = useState('1h');
  const [filter, setFilter] = useState<'ALL' | 'BUY' | 'SELL'>('ALL');
  const [lastScan, setLastScan] = useState<string>('');

  const scanMarket = useCallback(async () => {
    setScanning(true);
    const results: SymbolSignal[] = [];

    for (const symbol of SCAN_SYMBOLS) {
      try {
        const [ticker, klines] = await Promise.all([
          getFuturesTicker(symbol),
          getKlines(symbol, timeframe, 100),
        ]);

        const closes = klines.map(k => parseFloat(k.close));
        const highs = klines.map(k => parseFloat(k.high));
        const lows = klines.map(k => parseFloat(k.low));
        const volumes = klines.map(k => parseFloat(k.volume));

        const sig = generateSignal(closes, highs, lows, volumes);

        results.push({
          symbol,
          price: parseFloat(ticker.lastPrice),
          change: parseFloat(ticker.priceChangePercent),
          signal: sig.signal,
          score: sig.score,
          reasons: sig.reasons,
          loading: false,
        });

        // Save strong signals
        if (sig.signal === 'STRONG_BUY' || sig.signal === 'STRONG_SELL') {
          addSignal({
            id: `${symbol}-${Date.now()}`,
            symbol,
            signal: sig.signal,
            score: sig.score,
            reasons: sig.reasons,
            price: parseFloat(ticker.lastPrice),
            timestamp: Date.now(),
          });
        }
      } catch {
        results.push({
          symbol,
          price: 0,
          change: 0,
          signal: 'NEUTRAL',
          score: 0,
          reasons: ['Error fetching data'],
          loading: false,
        });
      }
    }

    results.sort((a, b) => b.score - a.score);
    setSignals(results);
    setScanning(false);
    setLastScan(new Date().toLocaleTimeString('fa-IR'));
  }, [timeframe, addSignal]);

  useEffect(() => {
    scanMarket();
  }, [scanMarket]);

  const filtered = signals.filter(s => {
    if (filter === 'BUY') return s.signal === 'STRONG_BUY' || s.signal === 'BUY';
    if (filter === 'SELL') return s.signal === 'STRONG_SELL' || s.signal === 'SELL';
    return true;
  });

  return (
    <div className="space-y-4">
      {/* Controls */}
      <div className="flex flex-wrap gap-3 items-center">
        <button
          onClick={scanMarket}
          disabled={scanning}
          className="flex items-center gap-2 px-4 py-2 bg-cyan-500/20 text-cyan-400 rounded-lg border border-cyan-500/30 hover:bg-cyan-500/30 disabled:opacity-50"
        >
          <RefreshCw size={16} className={scanning ? 'animate-spin' : ''} />
          {scanning ? 'Scanning...' : 'Scan Market'}
        </button>

        <div className="flex gap-1">
          {['1h', '4h', '1d'].map(tf => (
            <button
              key={tf}
              onClick={() => setTimeframe(tf)}
              className={`px-3 py-1.5 rounded text-xs ${timeframe === tf ? 'bg-cyan-500/20 text-cyan-400' : 'bg-gray-800 text-gray-400'}`}
            >
              {tf}
            </button>
          ))}
        </div>

        <div className="flex gap-1">
          {(['ALL', 'BUY', 'SELL'] as const).map(f => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={`px-3 py-1.5 rounded text-xs ${filter === f ? 'bg-cyan-500/20 text-cyan-400' : 'bg-gray-800 text-gray-400'}`}
            >
              {f}
            </button>
          ))}
        </div>

        {lastScan && <span className="text-xs text-gray-500">Last scan: {lastScan}</span>}
      </div>

      {/* Signal Summary */}
      <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
        <SummaryCard label="Strong Buy" count={signals.filter(s => s.signal === 'STRONG_BUY').length} color="text-green-400" />
        <SummaryCard label="Buy" count={signals.filter(s => s.signal === 'BUY').length} color="text-green-300" />
        <SummaryCard label="Neutral" count={signals.filter(s => s.signal === 'NEUTRAL').length} color="text-gray-400" />
        <SummaryCard label="Sell" count={signals.filter(s => s.signal === 'SELL').length} color="text-red-300" />
        <SummaryCard label="Strong Sell" count={signals.filter(s => s.signal === 'STRONG_SELL').length} color="text-red-400" />
      </div>

      {/* Signal List */}
      {scanning ? (
        <div className="text-center py-12">
          <Radio size={40} className="mx-auto text-cyan-400 animate-pulse mb-4" />
          <p className="text-gray-400">Scanning {SCAN_SYMBOLS.length} futures pairs...</p>
          <p className="text-gray-500 text-sm">Analyzing indicators on {timeframe} timeframe</p>
        </div>
      ) : (
        <div className="space-y-2">
          {filtered.map(s => (
            <div
              key={s.symbol}
              className={`p-4 rounded-xl border ${signalBg(s.signal)} cursor-pointer hover:opacity-90 transition`}
              onClick={() => { setSelectedSymbol(s.symbol); setPage('market'); }}
            >
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-3">
                  <SignalIcon signal={s.signal} />
                  <div>
                    <span className="font-medium">{s.symbol.replace('USDT', '')}/USDT</span>
                    <span className={`ml-2 text-sm ${s.change >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                      {s.change >= 0 ? '+' : ''}{s.change.toFixed(2)}%
                    </span>
                  </div>
                </div>
                <div className="text-right">
                  <div className={`font-bold ${signalColor(s.signal)}`}>{s.signal.replace('_', ' ')}</div>
                  <div className="text-xs text-gray-500">Score: {s.score}</div>
                </div>
              </div>
              <div className="flex items-center justify-between">
                <div className="text-sm text-gray-400">${s.price.toLocaleString()}</div>
                <div className="flex flex-wrap gap-1 justify-end">
                  {s.reasons.slice(0, 3).map((r, i) => (
                    <span key={i} className="text-xs px-2 py-0.5 bg-gray-800 rounded text-gray-400">{r}</span>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function SummaryCard({ label, count, color }: { label: string; count: number; color: string }) {
  return (
    <div className="bg-gray-900 rounded-lg border border-gray-800 p-3 text-center">
      <div className={`text-2xl font-bold ${color}`}>{count}</div>
      <div className="text-xs text-gray-500">{label}</div>
    </div>
  );
}
