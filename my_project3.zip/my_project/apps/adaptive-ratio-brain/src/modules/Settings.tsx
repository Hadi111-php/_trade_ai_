import { useState, useEffect } from 'react';
import { useAppStore } from '../store/appStore';
import { Settings as SettingsIcon, Save, RotateCcw, Plus, X, Server, Zap, Shield, Globe, Wifi, WifiOff } from 'lucide-react';
import { cache } from '../lib/cache';
import { setBackendUrl, getBackendConfig, isBackendAvailable } from '../lib/backendApi';

export function SettingsModule() {
  const { settings, updateSettings, watchlist, addToWatchlist, removeFromWatchlist } = useAppStore();
  const [leverage, setLeverage] = useState(String(settings.defaultLeverage));
  const [riskPercent, setRiskPercent] = useState(String(settings.riskPercent));
  const [virtualBalance, setVirtualBalance] = useState(String(settings.virtualBalance));
  const [signalThreshold, setSignalThreshold] = useState(String(settings.signalThreshold));
  const [refreshInterval, setRefreshInterval] = useState(String(settings.refreshInterval));
  const [newSymbol, setNewSymbol] = useState('');
  const [saved, setSaved] = useState(false);

  const handleSave = () => {
    updateSettings({
      defaultLeverage: parseInt(leverage) || 10,
      riskPercent: parseFloat(riskPercent) || 2,
      virtualBalance: parseFloat(virtualBalance) || 10000,
      signalThreshold: parseInt(signalThreshold) || 3,
      refreshInterval: parseInt(refreshInterval) || 10,
    });
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  const handleAddSymbol = () => {
    const sym = newSymbol.trim().toUpperCase();
    if (sym) {
      addToWatchlist(sym.endsWith('USDT') ? sym : sym + 'USDT');
      setNewSymbol('');
    }
  };

  const handleClearCache = () => {
    cache.clear();
    alert('Cache cleared successfully!');
  };

  return (
    <div className="space-y-6 max-w-3xl">
      {/* Trading Parameters */}
      <div className="bg-gray-900 rounded-xl border border-gray-800 p-5">
        <div className="flex items-center gap-2 mb-4">
          <Zap size={18} className="text-yellow-400" />
          <h3 className="font-medium">Trading Parameters / پارامترهای معاملاتی</h3>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <SettingInput label="Default Leverage (اهرم پیش‌فرض)" value={leverage} onChange={setLeverage} type="number" min="1" max="125" hint="1-125x" />
          <SettingInput label="Risk Per Trade % (ریسک هر معامله)" value={riskPercent} onChange={setRiskPercent} type="number" min="0.5" max="10" step="0.5" hint="0.5-10%" />
          <SettingInput label="Virtual Balance ($) (موجودی مجازی)" value={virtualBalance} onChange={setVirtualBalance} type="number" min="100" hint="Starting paper balance" />
          <SettingInput label="Signal Threshold (آستانه سیگنال)" value={signalThreshold} onChange={setSignalThreshold} type="number" min="1" max="6" hint="Minimum score to trigger" />
        </div>
      </div>

      {/* System Settings */}
      <div className="bg-gray-900 rounded-xl border border-gray-800 p-5">
        <div className="flex items-center gap-2 mb-4">
          <Server size={18} className="text-cyan-400" />
          <h3 className="font-medium">System Settings / تنظیمات سیستم</h3>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <SettingInput label="Refresh Interval (sec)" value={refreshInterval} onChange={setRefreshInterval} type="number" min="5" max="60" hint="Data refresh rate" />
          <div>
            <label className="text-xs text-gray-500">Auto Trade (اتوترید)</label>
            <div className="flex items-center gap-3 mt-2">
              <button
                onClick={() => updateSettings({ autoTradeEnabled: !settings.autoTradeEnabled })}
                className={`relative w-12 h-6 rounded-full transition ${settings.autoTradeEnabled ? 'bg-cyan-500' : 'bg-gray-700'}`}
              >
                <div className={`absolute top-0.5 w-5 h-5 rounded-full bg-white shadow transition-transform ${settings.autoTradeEnabled ? 'translate-x-6' : 'translate-x-0.5'}`} />
              </button>
              <span className={`text-sm ${settings.autoTradeEnabled ? 'text-cyan-400' : 'text-gray-500'}`}>
                {settings.autoTradeEnabled ? 'Enabled (فعال)' : 'Disabled (غیرفعال)'}
              </span>
            </div>
            <p className="text-xs text-gray-600 mt-1">Virtual trades only - Paper trading mode</p>
          </div>
        </div>
      </div>

      {/* Watchlist Management */}
      <div className="bg-gray-900 rounded-xl border border-gray-800 p-5">
        <div className="flex items-center gap-2 mb-4">
          <Shield size={18} className="text-purple-400" />
          <h3 className="font-medium">Watchlist / لیست دیده‌بان</h3>
        </div>
        <div className="flex gap-2 mb-3">
          <input
            value={newSymbol}
            onChange={e => setNewSymbol(e.target.value.toUpperCase())}
            onKeyDown={e => e.key === 'Enter' && handleAddSymbol()}
            placeholder="Add symbol (e.g. BTC, SOL)"
            className="flex-1 px-3 py-2 bg-gray-800 rounded-lg border border-gray-700 text-sm outline-none focus:border-cyan-500"
          />
          <button
            onClick={handleAddSymbol}
            className="px-3 py-2 bg-cyan-500/20 text-cyan-400 rounded-lg hover:bg-cyan-500/30"
          >
            <Plus size={16} />
          </button>
        </div>
        <div className="flex flex-wrap gap-2">
          {watchlist.map(s => (
            <div key={s} className="flex items-center gap-1 px-3 py-1.5 bg-gray-800 rounded-lg text-sm">
              <span>{s.replace('USDT', '')}</span>
              <button onClick={() => removeFromWatchlist(s)} className="text-gray-500 hover:text-red-400">
                <X size={14} />
              </button>
            </div>
          ))}
        </div>
      </div>

      {/* Actions */}
      <div className="flex gap-3">
        <button
          onClick={handleSave}
          className="flex items-center gap-2 px-6 py-2.5 bg-cyan-600 hover:bg-cyan-500 rounded-lg font-medium"
        >
          <Save size={16} />
          {saved ? '✓ Saved!' : 'Save Settings'}
        </button>
        <button
          onClick={handleClearCache}
          className="flex items-center gap-2 px-4 py-2.5 bg-gray-800 hover:bg-gray-700 rounded-lg text-gray-400"
        >
          <RotateCcw size={16} />
          Clear Cache
        </button>
      </div>

      {/* Backend Connection */}
      <div className="bg-gray-900 rounded-xl border border-gray-800 p-5">
        <div className="flex items-center gap-2 mb-4">
          <Globe size={18} className="text-blue-400" />
          <h3 className="font-medium">Backend Server / سرور بک‌اند</h3>
        </div>
        <BackendSettings />
      </div>

      {/* System Info */}
      <div className="bg-gray-900 rounded-xl border border-gray-800 p-5">
        <div className="flex items-center gap-2 mb-3">
          <SettingsIcon size={18} className="text-gray-400" />
          <h3 className="font-medium text-gray-400">System Info</h3>
        </div>
        <div className="grid grid-cols-2 gap-2 text-xs text-gray-500">
          <div>Version: <span className="text-gray-300">2027.2.0</span></div>
          <div>API: <span className="text-green-400">Multi-Exchange Futures</span></div>
          <div>Exchanges: <span className="text-green-400">Binance, Bybit, OKX, Bitget, Kraken</span></div>
          <div>Cache: <span className="text-gray-300">In-Memory TTL</span></div>
          <div>Framework: <span className="text-gray-300">React 19 + Zustand</span></div>
          <div>Charts: <span className="text-gray-300">Recharts</span></div>
          <div>Brain: <span className="text-purple-400">Adaptive Ratio Engine</span></div>
          <div>Learning: <span className="text-purple-400">12h + 30d + Per-Symbol</span></div>
          <div>Indicators: <span className="text-gray-300">RSI, MACD, BB, EMA, ATR, Stoch</span></div>
          <div>Auth: <span className="text-yellow-400">Local (→ JWT)</span></div>
        </div>
      </div>
    </div>
  );
}

function BackendSettings() {
  const backendConfig = getBackendConfig();
  const [url, setUrl] = useState(backendConfig.url || '');
  const [checking, setChecking] = useState(false);
  const [backendStatus, setBackendStatus] = useState<'unknown' | 'ok' | 'error'>('unknown');

  useEffect(() => {
    if (backendConfig.url) {
      checkConnection();
    }
  }, []);

  const checkConnection = async () => {
    setChecking(true);
    const available = await isBackendAvailable();
    setBackendStatus(available ? 'ok' : 'error');
    setChecking(false);
  };

  const handleSave = () => {
    setBackendUrl(url);
    checkConnection();
  };

  return (
    <div className="space-y-3">
      <div className="flex gap-2">
        <input
          value={url}
          onChange={e => setUrl(e.target.value)}
          placeholder="http://your-server:8000"
          className="flex-1 px-3 py-2 bg-gray-800 rounded-lg border border-gray-700 text-sm outline-none focus:border-blue-500"
        />
        <button onClick={handleSave} className="px-4 py-2 bg-blue-500/20 text-blue-400 rounded-lg hover:bg-blue-500/30 text-sm">
          Save
        </button>
        <button onClick={checkConnection} disabled={checking} className="px-3 py-2 bg-gray-800 rounded-lg hover:bg-gray-700">
          {checking ? (
            <div className="w-4 h-4 border-2 border-blue-400 border-t-transparent rounded-full animate-spin" />
          ) : backendStatus === 'ok' ? (
            <Wifi size={16} className="text-green-400" />
          ) : backendStatus === 'error' ? (
            <WifiOff size={16} className="text-red-400" />
          ) : (
            <Wifi size={16} className="text-gray-500" />
          )}
        </button>
      </div>
      <div className="flex items-center gap-2">
        <div className={`w-2 h-2 rounded-full ${backendStatus === 'ok' ? 'bg-green-400' : backendStatus === 'error' ? 'bg-red-400' : 'bg-gray-600'}`} />
        <span className={`text-xs ${backendStatus === 'ok' ? 'text-green-400' : backendStatus === 'error' ? 'text-red-400' : 'text-gray-500'}`}>
          {backendStatus === 'ok' ? 'Backend Connected' : backendStatus === 'error' ? 'Backend Offline - Using Direct API' : 'Not Configured - Using Direct API'}
        </span>
      </div>
      <p className="text-xs text-gray-600">
        When backend (FastAPI/Go) is deployed, enter its URL here. Data will be stored in PostgreSQL + Redis instead of localStorage.
      </p>
    </div>
  );
}

function SettingInput({ label, value, onChange, type = 'text', min, max, step, hint }: {
  label: string; value: string; onChange: (v: string) => void;
  type?: string; min?: string; max?: string; step?: string; hint?: string;
}) {
  return (
    <div>
      <label className="text-xs text-gray-500">{label}</label>
      <input
        value={value}
        onChange={e => onChange(e.target.value)}
        type={type}
        min={min}
        max={max}
        step={step}
        className="w-full mt-1 px-3 py-2 bg-gray-800 rounded-lg border border-gray-700 text-sm outline-none focus:border-cyan-500"
      />
      {hint && <p className="text-xs text-gray-600 mt-1">{hint}</p>}
    </div>
  );
}
