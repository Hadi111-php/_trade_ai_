import { useEffect, useState, useCallback } from 'react';
import { getKlines, getFuturesTicker, getFundingRate, getOpenInterest, getLongShortRatio } from '../lib/binanceApi';
import { calcRSI, calcMACD, calcBollingerBands, calcEMA, calcATR, calcStochastic } from '../lib/indicators';
import { useAppStore } from '../store/appStore';
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, Cell } from 'recharts';
import { ShieldCheck, CheckCircle, XCircle, AlertTriangle } from 'lucide-react';

interface ValidationResult {
  name: string;
  nameFA: string;
  status: 'PASS' | 'FAIL' | 'WARN';
  value: string;
  detail: string;
  weight: number;
}

export function Validation() {
  const { selectedSymbol, setSelectedSymbol } = useAppStore();
  const [results, setResults] = useState<ValidationResult[]>([]);
  const [loading, setLoading] = useState(false);
  const [overallScore, setOverallScore] = useState(0);
  const [overallVerdict, setOverallVerdict] = useState<'VALID' | 'RISKY' | 'INVALID'>('RISKY');
  const [lsrData, setLsrData] = useState<{ time: string; ratio: number }[]>([]);
  const [symbol, setSymbol] = useState(selectedSymbol);

  const runValidation = useCallback(async () => {
    setLoading(true);
    const validations: ValidationResult[] = [];

    try {
      const [ticker, klines1h, klines4h, fr, oi, lsr] = await Promise.all([
        getFuturesTicker(symbol),
        getKlines(symbol, '1h', 100),
        getKlines(symbol, '4h', 100),
        getFundingRate(symbol),
        getOpenInterest(symbol),
        getLongShortRatio(symbol, '1h', 24).catch(() => []),
      ]);

      // Process kline data
      const closes1h = klines1h.map(k => parseFloat(k.close));
      const highs1h = klines1h.map(k => parseFloat(k.high));
      const lows1h = klines1h.map(k => parseFloat(k.low));
      const closes4h = klines4h.map(k => parseFloat(k.close));
      // highs4h/lows4h available for future multi-TF analysis
      void klines4h.map(k => parseFloat(k.high));
      void klines4h.map(k => parseFloat(k.low));

      // 1. RSI Multi-timeframe
      const rsi1h = calcRSI(closes1h);
      const rsi4h = calcRSI(closes4h);
      const lastRSI1h = rsi1h[rsi1h.length - 1];
      const lastRSI4h = rsi4h[rsi4h.length - 1];

      validations.push({
        name: 'RSI Confluence',
        nameFA: 'تطابق RSI',
        status: (lastRSI1h > 30 && lastRSI1h < 70 && lastRSI4h > 30 && lastRSI4h < 70) ? 'PASS' :
          (lastRSI1h < 20 || lastRSI1h > 80) ? 'FAIL' : 'WARN',
        value: `1H: ${lastRSI1h.toFixed(1)} | 4H: ${lastRSI4h.toFixed(1)}`,
        detail: lastRSI1h > 70 ? 'Overbought on 1H' : lastRSI1h < 30 ? 'Oversold on 1H' : 'RSI in normal range',
        weight: 15,
      });

      // 2. MACD Alignment
      const macd1h = calcMACD(closes1h);
      const macd4h = calcMACD(closes4h);
      const macd1hBullish = macd1h.histogram[macd1h.histogram.length - 1] > 0;
      const macd4hBullish = macd4h.histogram[macd4h.histogram.length - 1] > 0;
      const macdAligned = macd1hBullish === macd4hBullish;

      validations.push({
        name: 'MACD Alignment',
        nameFA: 'هم‌راستایی MACD',
        status: macdAligned ? 'PASS' : 'WARN',
        value: `1H: ${macd1hBullish ? 'Bullish' : 'Bearish'} | 4H: ${macd4hBullish ? 'Bullish' : 'Bearish'}`,
        detail: macdAligned ? 'Multi-TF MACD aligned' : 'MACD divergence between timeframes',
        weight: 15,
      });

      // 3. EMA Trend
      const ema9 = calcEMA(closes1h, 9);
      const ema21 = calcEMA(closes1h, 21);
      const ema50 = calcEMA(closes1h, 50);
      const trendUp = ema9[ema9.length - 1] > ema21[ema21.length - 1] && ema21[ema21.length - 1] > ema50[ema50.length - 1];
      const trendDown = ema9[ema9.length - 1] < ema21[ema21.length - 1] && ema21[ema21.length - 1] < ema50[ema50.length - 1];

      validations.push({
        name: 'EMA Trend Structure',
        nameFA: 'ساختار روند EMA',
        status: (trendUp || trendDown) ? 'PASS' : 'WARN',
        value: trendUp ? 'Uptrend ▲' : trendDown ? 'Downtrend ▼' : 'Ranging',
        detail: trendUp ? 'EMA9 > EMA21 > EMA50' : trendDown ? 'EMA9 < EMA21 < EMA50' : 'No clear trend structure',
        weight: 15,
      });

      // 4. Bollinger Band Position
      const bb = calcBollingerBands(closes1h);
      const lastClose = closes1h[closes1h.length - 1];
      const bbWidth = (bb.upper[bb.upper.length - 1] - bb.lower[bb.lower.length - 1]) / bb.middle[bb.middle.length - 1] * 100;
      const bbPosition = (lastClose - bb.lower[bb.lower.length - 1]) / (bb.upper[bb.upper.length - 1] - bb.lower[bb.lower.length - 1]) * 100;

      validations.push({
        name: 'BB Position & Width',
        nameFA: 'موقعیت بولینگر',
        status: (bbPosition > 20 && bbPosition < 80) ? 'PASS' : 'WARN',
        value: `Position: ${bbPosition.toFixed(0)}% | Width: ${bbWidth.toFixed(2)}%`,
        detail: bbPosition > 80 ? 'Near upper band - potential reversal' : bbPosition < 20 ? 'Near lower band - potential bounce' : 'Mid-range',
        weight: 10,
      });

      // 5. ATR Volatility
      const atr = calcATR(highs1h, lows1h, closes1h);
      const lastATR = atr[atr.length - 1];
      const atrPercent = (lastATR / lastClose) * 100;

      validations.push({
        name: 'Volatility (ATR)',
        nameFA: 'نوسانات ATR',
        status: atrPercent < 5 ? 'PASS' : atrPercent < 8 ? 'WARN' : 'FAIL',
        value: `ATR: ${lastATR.toFixed(2)} (${atrPercent.toFixed(2)}%)`,
        detail: atrPercent > 8 ? 'Extremely volatile - high risk' : atrPercent > 5 ? 'Moderate volatility' : 'Low volatility - safe',
        weight: 10,
      });

      // 6. Stochastic
      const stoch = calcStochastic(highs1h, lows1h, closes1h);
      const lastK = stoch.k[stoch.k.length - 1];

      validations.push({
        name: 'Stochastic Oscillator',
        nameFA: 'اسیلاتور استوکاستیک',
        status: (lastK > 20 && lastK < 80) ? 'PASS' : 'WARN',
        value: `%K: ${lastK?.toFixed(1) || 'N/A'}`,
        detail: lastK > 80 ? 'Overbought zone' : lastK < 20 ? 'Oversold zone' : 'Normal range',
        weight: 10,
      });

      // 7. Funding Rate
      const fundingVal = parseFloat(fr.fundingRate);
      validations.push({
        name: 'Funding Rate',
        nameFA: 'نرخ فاندینگ',
        status: Math.abs(fundingVal) < 0.001 ? 'PASS' : Math.abs(fundingVal) < 0.005 ? 'WARN' : 'FAIL',
        value: `${(fundingVal * 100).toFixed(4)}%`,
        detail: fundingVal > 0.005 ? 'Very high positive - longs paying heavily' : fundingVal < -0.005 ? 'Very negative - shorts paying' : 'Normal range',
        weight: 10,
      });

      // 8. Volume Analysis
      const vols = klines1h.map(k => parseFloat(k.volume));
      const avgVol = vols.slice(-20).reduce((a, b) => a + b, 0) / 20;
      const lastVol = vols[vols.length - 1];
      const volRatio = lastVol / avgVol;

      validations.push({
        name: 'Volume Confirmation',
        nameFA: 'تایید حجم',
        status: volRatio > 0.5 ? 'PASS' : 'WARN',
        value: `Current/Avg: ${volRatio.toFixed(2)}x`,
        detail: volRatio > 2 ? 'Very high volume - strong move' : volRatio > 1 ? 'Above average volume' : 'Below average - weak conviction',
        weight: 5,
      });

      // 9. Open Interest check
      const oiVal = parseFloat(oi.openInterest);
      const quoteVol = parseFloat(ticker.quoteVolume);
      
      validations.push({
        name: 'Open Interest',
        nameFA: 'قراردادهای باز',
        status: 'PASS',
        value: `OI: ${oiVal.toLocaleString()} | Vol: $${(quoteVol / 1e6).toFixed(0)}M`,
        detail: 'Open interest data available',
        weight: 5,
      });

      // 10. Price vs MA check (4H)
      const ema50_4h = calcEMA(closes4h, 50);
      const priceVsMA = ((closes4h[closes4h.length - 1] - ema50_4h[ema50_4h.length - 1]) / ema50_4h[ema50_4h.length - 1]) * 100;

      validations.push({
        name: 'Price vs 4H EMA50',
        nameFA: 'قیمت در مقابل EMA50',
        status: Math.abs(priceVsMA) < 10 ? 'PASS' : 'WARN',
        value: `${priceVsMA > 0 ? '+' : ''}${priceVsMA.toFixed(2)}% from EMA50`,
        detail: priceVsMA > 10 ? 'Far above MA - potential pullback' : priceVsMA < -10 ? 'Far below MA - potential bounce' : 'Close to moving average',
        weight: 5,
      });

      // Long/Short Ratio data
      if (lsr.length > 0) {
        setLsrData(lsr.map(l => ({
          time: new Date(l.timestamp).toLocaleTimeString('en', { hour: '2-digit' }),
          ratio: parseFloat(l.longShortRatio),
        })));
      }

      // Calculate overall score
      let totalWeight = 0;
      let earnedWeight = 0;
      for (const v of validations) {
        totalWeight += v.weight;
        if (v.status === 'PASS') earnedWeight += v.weight;
        else if (v.status === 'WARN') earnedWeight += v.weight * 0.5;
      }
      const score = Math.round((earnedWeight / totalWeight) * 100);
      setOverallScore(score);
      setOverallVerdict(score >= 70 ? 'VALID' : score >= 40 ? 'RISKY' : 'INVALID');

      setResults(validations);
    } catch (err) {
      console.error('Validation error:', err);
    }
    setLoading(false);
  }, [symbol]);

  useEffect(() => {
    setSymbol(selectedSymbol);
  }, [selectedSymbol]);

  useEffect(() => {
    runValidation();
  }, [runValidation]);

  const statusIcon = (status: string) => {
    if (status === 'PASS') return <CheckCircle size={16} className="text-green-400" />;
    if (status === 'FAIL') return <XCircle size={16} className="text-red-400" />;
    return <AlertTriangle size={16} className="text-yellow-400" />;
  };

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex flex-wrap gap-3 items-center">
        <div className="flex items-center gap-2 bg-gray-900 border border-gray-700 rounded-lg px-3 py-2">
          <input
            value={symbol}
            onChange={e => setSymbol(e.target.value.toUpperCase())}
            onKeyDown={e => { if (e.key === 'Enter') { setSelectedSymbol(symbol); runValidation(); } }}
            className="bg-transparent text-sm outline-none w-28"
            placeholder="BTCUSDT"
          />
        </div>
        <button
          onClick={runValidation}
          disabled={loading}
          className="flex items-center gap-2 px-4 py-2 bg-purple-500/20 text-purple-400 rounded-lg border border-purple-500/30 hover:bg-purple-500/30"
        >
          <ShieldCheck size={16} />
          {loading ? 'Validating...' : 'Run Validation'}
        </button>
        <div className="flex gap-1">
          {['BTCUSDT', 'ETHUSDT', 'SOLUSDT', 'BNBUSDT'].map(s => (
            <button
              key={s}
              onClick={() => { setSymbol(s); setSelectedSymbol(s); }}
              className={`px-3 py-1 rounded text-xs ${symbol === s ? 'bg-purple-500/20 text-purple-400' : 'bg-gray-800 text-gray-400'}`}
            >
              {s.replace('USDT', '')}
            </button>
          ))}
        </div>
      </div>

      {loading ? (
        <div className="text-center py-12">
          <ShieldCheck size={40} className="mx-auto text-purple-400 animate-pulse mb-4" />
          <p className="text-gray-400">Running comprehensive validation for {symbol}...</p>
        </div>
      ) : (
        <>
          {/* Overall Score */}
          <div className={`p-6 rounded-xl border ${overallVerdict === 'VALID' ? 'bg-green-500/5 border-green-500/20' : overallVerdict === 'RISKY' ? 'bg-yellow-500/5 border-yellow-500/20' : 'bg-red-500/5 border-red-500/20'}`}>
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-lg font-bold">{symbol} Validation Result</h3>
                <p className="text-sm text-gray-400 mt-1">Multi-indicator & multi-timeframe analysis</p>
              </div>
              <div className="text-right">
                <div className={`text-4xl font-bold ${overallVerdict === 'VALID' ? 'text-green-400' : overallVerdict === 'RISKY' ? 'text-yellow-400' : 'text-red-400'}`}>
                  {overallScore}%
                </div>
                <div className={`text-sm font-medium ${overallVerdict === 'VALID' ? 'text-green-400' : overallVerdict === 'RISKY' ? 'text-yellow-400' : 'text-red-400'}`}>
                  {overallVerdict}
                </div>
              </div>
            </div>
            {/* Progress bar */}
            <div className="mt-4 bg-gray-800 rounded-full h-3">
              <div
                className={`h-3 rounded-full transition-all duration-500 ${overallVerdict === 'VALID' ? 'bg-green-500' : overallVerdict === 'RISKY' ? 'bg-yellow-500' : 'bg-red-500'}`}
                style={{ width: `${overallScore}%` }}
              />
            </div>
          </div>

          {/* Validation Results Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {results.map((r, i) => (
              <div key={i} className={`p-4 rounded-xl border ${r.status === 'PASS' ? 'bg-green-500/5 border-green-500/10' : r.status === 'FAIL' ? 'bg-red-500/5 border-red-500/10' : 'bg-yellow-500/5 border-yellow-500/10'}`}>
                <div className="flex items-center justify-between mb-1">
                  <div className="flex items-center gap-2">
                    {statusIcon(r.status)}
                    <span className="text-sm font-medium">{r.name}</span>
                  </div>
                  <span className="text-xs text-gray-500">{r.nameFA}</span>
                </div>
                <div className="text-sm text-gray-300 mt-1">{r.value}</div>
                <div className="text-xs text-gray-500 mt-1">{r.detail}</div>
                <div className="text-xs text-gray-600 mt-1">Weight: {r.weight}%</div>
              </div>
            ))}
          </div>

          {/* Long/Short Ratio Chart */}
          {lsrData.length > 0 && (
            <div className="bg-gray-900 rounded-xl border border-gray-800 p-4">
              <h3 className="text-sm text-gray-400 mb-3">Long/Short Account Ratio (24h)</h3>
              <ResponsiveContainer width="100%" height={200}>
                <BarChart data={lsrData}>
                  <XAxis dataKey="time" tick={{ fill: '#6b7280', fontSize: 10 }} />
                  <YAxis tick={{ fill: '#6b7280', fontSize: 10 }} domain={[0, 'auto']} />
                  <Tooltip contentStyle={{ background: '#1f2937', border: '1px solid #374151', borderRadius: '8px' }} />
                  <Bar dataKey="ratio">
                    {lsrData.map((entry, index) => (
                      <Cell key={index} fill={entry.ratio > 1 ? '#4ade80' : '#f87171'} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          )}
        </>
      )}
    </div>
  );
}
