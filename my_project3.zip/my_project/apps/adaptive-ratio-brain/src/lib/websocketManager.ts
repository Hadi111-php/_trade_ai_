// WebSocket Manager for Real-Time Data
// Connects to Binance & Bybit WebSocket streams
// Ready for backend WebSocket proxy

import { cache } from './cache';

export interface WSTickerUpdate {
  symbol: string;
  exchange: string;
  price: number;
  volume: number;
  timestamp: number;
}

type WSCallback = (data: WSTickerUpdate) => void;

class WebSocketManager {
  private connections: Map<string, WebSocket> = new Map();
  private subscribers: Map<string, Set<WSCallback>> = new Map();
  private reconnectTimers: Map<string, ReturnType<typeof setTimeout>> = new Map();
  private enabled = false;

  // Subscribe to real-time ticker updates
  subscribe(symbol: string, callback: WSCallback): () => void {
    const key = symbol.toUpperCase();
    if (!this.subscribers.has(key)) {
      this.subscribers.set(key, new Set());
    }
    this.subscribers.get(key)!.add(callback);

    // Auto-connect if enabled
    if (this.enabled && !this.connections.has(key)) {
      this.connectBinanceStream(key);
    }

    return () => {
      this.subscribers.get(key)?.delete(callback);
      if (this.subscribers.get(key)?.size === 0) {
        this.subscribers.delete(key);
        this.disconnectStream(key);
      }
    };
  }

  // Connect to Binance mini ticker stream
  private connectBinanceStream(symbol: string) {
    const wsSymbol = symbol.toLowerCase();
    const url = `wss://fstream.binance.com/ws/${wsSymbol}@miniTicker`;

    try {
      const ws = new WebSocket(url);

      ws.onopen = () => {
        console.log(`[WS] Connected: ${symbol}`);
      };

      ws.onmessage = (event) => {
        try {
          const data = JSON.parse(event.data);
          const update: WSTickerUpdate = {
            symbol: data.s,
            exchange: 'binance',
            price: parseFloat(data.c),
            volume: parseFloat(data.v),
            timestamp: data.E,
          };

          // Update cache
          cache.set(`ws_price_${symbol}`, update.price, 5000);

          // Notify subscribers
          this.subscribers.get(symbol)?.forEach(cb => cb(update));
        } catch { /* ignore parse errors */ }
      };

      ws.onclose = () => {
        console.log(`[WS] Disconnected: ${symbol}`);
        this.connections.delete(symbol);

        // Auto-reconnect if still subscribed
        if (this.subscribers.has(symbol) && this.enabled) {
          const timer = setTimeout(() => {
            this.connectBinanceStream(symbol);
          }, 3000);
          this.reconnectTimers.set(symbol, timer);
        }
      };

      ws.onerror = () => {
        ws.close();
      };

      this.connections.set(symbol, ws);
    } catch (err) {
      console.error(`[WS] Failed to connect: ${symbol}`, err);
    }
  }

  private disconnectStream(symbol: string) {
    const ws = this.connections.get(symbol);
    if (ws) {
      ws.close();
      this.connections.delete(symbol);
    }

    const timer = this.reconnectTimers.get(symbol);
    if (timer) {
      clearTimeout(timer);
      this.reconnectTimers.delete(symbol);
    }
  }

  // Connect to combined stream for multiple symbols
  connectCombinedStream(symbols: string[]) {
    const streams = symbols.map(s => `${s.toLowerCase()}@miniTicker`).join('/');
    const url = `wss://fstream.binance.com/stream?streams=${streams}`;

    const key = '_combined_';

    try {
      const ws = new WebSocket(url);

      ws.onopen = () => {
        console.log(`[WS] Combined stream connected: ${symbols.length} symbols`);
      };

      ws.onmessage = (event) => {
        try {
          const wrapper = JSON.parse(event.data);
          const data = wrapper.data;
          if (!data) return;

          const update: WSTickerUpdate = {
            symbol: data.s,
            exchange: 'binance',
            price: parseFloat(data.c),
            volume: parseFloat(data.v),
            timestamp: data.E,
          };

          cache.set(`ws_price_${data.s}`, update.price, 5000);
          this.subscribers.get(data.s)?.forEach(cb => cb(update));
        } catch { /* ignore */ }
      };

      ws.onclose = () => {
        this.connections.delete(key);
        if (this.enabled) {
          setTimeout(() => this.connectCombinedStream(symbols), 5000);
        }
      };

      ws.onerror = () => ws.close();

      this.connections.set(key, ws);
    } catch (err) {
      console.error('[WS] Combined stream error:', err);
    }
  }

  // Enable/disable WebSocket connections
  setEnabled(enabled: boolean) {
    this.enabled = enabled;
    if (!enabled) {
      this.disconnectAll();
    }
  }

  disconnectAll() {
    for (const [key, ws] of this.connections) {
      ws.close();
      this.connections.delete(key);
    }
    for (const timer of this.reconnectTimers.values()) {
      clearTimeout(timer);
    }
    this.reconnectTimers.clear();
  }

  // Get cached WebSocket price
  getRealtimePrice(symbol: string): number | null {
    return cache.get<number>(`ws_price_${symbol}`);
  }

  get connectionCount() {
    return this.connections.size;
  }

  get isEnabled() {
    return this.enabled;
  }
}

export const wsManager = new WebSocketManager();
