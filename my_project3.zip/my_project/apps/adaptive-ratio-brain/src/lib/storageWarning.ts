// Storage Health Check & Warning System
// This module monitors localStorage usage and warns the user

export interface StorageStats {
  totalUsedBytes: number;
  totalUsedKB: number;
  totalUsedMB: number;
  estimatedLimitMB: number;
  usagePercent: number;
  brainStateBytes: number;
  breakdown: Record<string, number>;
  warnings: string[];
  isCritical: boolean;
}

export function getStorageStats(): StorageStats {
  const breakdown: Record<string, number> = {};
  let total = 0;

  try {
    for (let i = 0; i < localStorage.length; i++) {
      const key = localStorage.key(i);
      if (key) {
        const size = (localStorage.getItem(key) || '').length * 2; // UTF-16
        breakdown[key] = size;
        total += size;
      }
    }
  } catch { /* ignore */ }

  const brainStateBytes = breakdown['brain_state'] || 0;
  const estimatedLimitMB = 5; // Most browsers
  const usagePercent = (total / (estimatedLimitMB * 1024 * 1024)) * 100;

  const warnings: string[] = [];
  if (usagePercent > 80) warnings.push('⚠️ localStorage is over 80% full! Risk of data loss.');
  if (usagePercent > 50) warnings.push('⚡ Consider deploying backend for persistent storage.');
  if (brainStateBytes > 2 * 1024 * 1024) warnings.push('🧠 Brain state is very large. Old data may be pruned.');
  
  return {
    totalUsedBytes: total,
    totalUsedKB: total / 1024,
    totalUsedMB: total / (1024 * 1024),
    estimatedLimitMB,
    usagePercent,
    brainStateBytes,
    breakdown,
    warnings,
    isCritical: usagePercent > 80,
  };
}

// Export brain state for backup
export function exportBrainBackup(): string {
  const data: Record<string, any> = {};
  try {
    for (let i = 0; i < localStorage.length; i++) {
      const key = localStorage.key(i);
      if (key) {
        try {
          data[key] = JSON.parse(localStorage.getItem(key) || '');
        } catch {
          data[key] = localStorage.getItem(key);
        }
      }
    }
  } catch { /* ignore */ }

  return JSON.stringify({
    exportDate: new Date().toISOString(),
    version: '2027.2.0',
    storageType: 'localStorage',
    data,
  }, null, 2);
}

// Download backup as file
export function downloadBackup() {
  const backup = exportBrainBackup();
  const blob = new Blob([backup], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `whale_hunter_full_backup_${new Date().toISOString().slice(0, 10)}.json`;
  a.click();
  URL.revokeObjectURL(url);
}

// Restore from backup
export function restoreFromBackup(jsonString: string): { success: boolean; error?: string; restoredKeys: number } {
  try {
    const backup = JSON.parse(jsonString);
    const data = backup.data || backup;
    let count = 0;

    for (const [key, value] of Object.entries(data)) {
      try {
        localStorage.setItem(key, typeof value === 'string' ? value : JSON.stringify(value));
        count++;
      } catch (e) {
        return { success: false, error: `Failed to restore key "${key}": ${e}`, restoredKeys: count };
      }
    }

    return { success: true, restoredKeys: count };
  } catch (e) {
    return { success: false, error: `Invalid backup file: ${e}`, restoredKeys: 0 };
  }
}
