// Brain Store - Multi-Exchange Zustand store
import { create } from 'zustand';
import { brain } from './engine';
import type { BrainOutput, PaperTrade, SignalFeedback, ActiveRatio, BrainConfig, SymbolLearning } from './types';
import type { ExchangeName } from '../lib/exchangeApi';
import {
  getExchangeKlines, getExchangeTicker, getExchangeOI, getExchangeFunding,
  getCrossExchangeData, checkAllExchangeStatus
} from '../lib/exchangeApi';

interface BrainState {
  outputs: Map<string, BrainOutput>;
  paperTrades: PaperTrade[];
  feedbackLog: SignalFeedback[];
  activeRatios: ActiveRatio[];
  symbolLearnings: Map<string, SymbolLearning>;
  isRunning: boolean;
  scanInterval: number | null;
  lastScanTime: number;
  scanningSymbol: string;
  scanningExchange: string;
  error: string | null;
  brainConfig: BrainConfig;
  tradeStats: ReturnType<typeof brain.getPaperTradeStats>;
  exchangeStatus: { exchange: ExchangeName; status: 'OK' | 'SLOW' | 'DOWN'; latency: number }[];

  runScan: (symbols: string[], exchanges?: ExchangeName[]) => Promise<void>;
  startAutoScan: (symbols: string[], intervalMs: number) => void;
  stopAutoScan: () => void;
  openTrade: (params: {
    symbol: string;
    exchange?: ExchangeName;
    side: 'LONG' | 'SHORT';
    quantity: number;
    leverage: number;
    stopLossPercent: number;
    takeProfitPercent: number;
  }) => Promise<PaperTrade | null>;
  closeTrade: (tradeId: string) => Promise<void>;
  updatePrices: () => Promise<void>;
  updateConfig: (config: Partial<BrainConfig>) => void;
  resetBrain: () => void;
  refreshState: () => void;
  checkExchanges: () => Promise<void>;
}

export const useBrainStore = create<BrainState>((set, get) => ({
  outputs: new Map(),
  paperTrades: brain.getPaperTrades(),
  feedbackLog: brain.getFeedbackLog(),
  activeRatios: brain.getAllRatios(),
  symbolLearnings: brain.getSymbolLearnings(),
  isRunning: false,
  scanInterval: null,
  lastScanTime: 0,
  scanningSymbol: '',
  scanningExchange: '',
  error: null,
  brainConfig: brain.getConfig(),
  tradeStats: brain.getPaperTradeStats(),
  exchangeStatus: [],

  refreshState: () => {
    set({
      outputs: new Map(brain.getAllOutputs().map(o => [o.symbol, o])),
      paperTrades: brain.getPaperTrades(),
      feedbackLog: brain.getFeedbackLog(),
      activeRatios: brain.getAllRatios(),
      symbolLearnings: brain.getSymbolLearnings(),
      tradeStats: brain.getPaperTradeStats(),
      brainConfig: brain.getConfig(),
    });
  },

  checkExchanges: async () => {
    const status = await checkAllExchangeStatus();
    set({ exchangeStatus: status });
  },

  runScan: async (symbols: string[], exchanges?: ExchangeName[]) => {
    set({ isRunning: true, error: null });
    const enabledExchanges = exchanges || brain.getConfig().enabledExchanges;

    try {
      for (const symbol of symbols) {
        for (const exchange of enabledExchanges) {
          set({ scanningSymbol: symbol, scanningExchange: exchange });

          try {
            const [klines1m, , oi, fr] = await Promise.all([
              getExchangeKlines(symbol, '1m', 30, exchange).catch(() => []),
              getExchangeTicker(symbol, exchange),
              getExchangeOI(symbol, exchange).catch(() => null),
              getExchangeFunding(symbol, exchange).catch(() => null),
            ]);

            if (klines1m.length < 5) continue;

            const closes = klines1m.map(k => k.close);
            const volumes = klines1m.map(k => k.volume);

            const currentClose = closes[closes.length - 1];
            const prevClose = closes[closes.length - 2] || currentClose;
            const currentVol = volumes[volumes.length - 1];
            const currentOI = oi?.openInterest || 0;
            const fundingRate = fr?.fundingRate || 0;

            const estimatedPrevOI = currentOI > 0
              ? currentOI / (1 + (currentClose - prevClose) / prevClose * 0.5)
              : 0;

            const oiRatio = brain.calcOIRatio(currentOI, estimatedPrevOI);
            const volRatio = brain.calcVolRatio(currentVol, volumes.slice(0, -1));
            const priceRatio = brain.calcPriceRatio(currentClose, prevClose);

            const ratioData = {
              timestamp: Date.now(),
              symbol,
              exchange: exchange as ExchangeName,
              oiRatio, volRatio, priceRatio, fundingRate,
              close: currentClose,
              volume: currentVol,
              openInterest: currentOI,
            };

            brain.generateBrainSignal(symbol, ratioData);

            const candleIdx = Math.floor((Date.now() - (get().lastScanTime || Date.now())) / 60000);
            brain.updateFeedback(symbol, currentClose, candleIdx);

          } catch (err) {
            console.warn(`Brain scan error ${symbol}/${exchange}:`, err);
          }

          await new Promise(r => setTimeout(r, 150));
        }

        // Cross-exchange analysis for this symbol
        if (enabledExchanges.length > 1) {
          try {
            const crossData = await getCrossExchangeData(symbol, enabledExchanges);
            const output = brain.getOutput(symbol);
            if (output) {
              output.crossExchangeData = {
                priceDivergence: crossData.priceDivergence,
                oiDivergence: crossData.oiDivergence,
                fundingDivergence: crossData.fundingDivergence,
                leadExchange: crossData.leadExchange,
              };
            }
          } catch {
            // skip cross-exchange
          }
        }
      }

      set({ lastScanTime: Date.now(), scanningSymbol: '', scanningExchange: '' });
      get().refreshState();
    } catch (err) {
      set({ error: String(err) });
    }

    set({ isRunning: false });
  },

  startAutoScan: (symbols: string[], intervalMs: number) => {
    const existing = get().scanInterval;
    if (existing) clearInterval(existing);

    get().runScan(symbols);

    const id = window.setInterval(() => {
      if (!get().isRunning) {
        get().runScan(symbols);
      }
    }, intervalMs);

    set({ scanInterval: id });
  },

  stopAutoScan: () => {
    const id = get().scanInterval;
    if (id) clearInterval(id);
    set({ scanInterval: null, isRunning: false });
  },

  openTrade: async (params) => {
    const exchange: ExchangeName = params.exchange || 'binance';
    try {
      const ticker = await getExchangeTicker(params.symbol, exchange);
      if (!ticker) throw new Error('Failed to get ticker');

      const trade = brain.openPaperTrade({
        ...params,
        exchange,
        entryPrice: ticker.lastPrice,
        source: 'MANUAL',
      });

      get().refreshState();
      return trade;
    } catch (err) {
      console.error('Failed to open paper trade:', err);
      set({ error: String(err) });
      return null;
    }
  },

  closeTrade: async (tradeId: string) => {
    const trade = brain.getPaperTrades().find(t => t.id === tradeId);
    if (!trade) return;

    try {
      const ticker = await getExchangeTicker(trade.symbol, trade.exchange);
      if (ticker) {
        brain.closePaperTrade(tradeId, ticker.lastPrice);
        get().refreshState();
      }
    } catch (err) {
      console.error('Failed to close trade:', err);
    }
  },

  updatePrices: async () => {
    const openTrades = brain.getOpenPaperTrades();
    if (openTrades.length === 0) return;

    const prices = new Map<string, number>();
    const seen = new Set<string>();

    for (const trade of openTrades) {
      const key = `${trade.symbol}:${trade.exchange}`;
      if (seen.has(key)) continue;
      seen.add(key);

      try {
        const ticker = await getExchangeTicker(trade.symbol, trade.exchange);
        if (ticker) prices.set(trade.symbol, ticker.lastPrice);
      } catch { /* skip */ }
    }

    brain.updatePaperTrades(prices);
    get().refreshState();
  },

  updateConfig: (config: Partial<BrainConfig>) => {
    brain.updateConfig(config);
    get().refreshState();
  },

  resetBrain: () => {
    const id = get().scanInterval;
    if (id) clearInterval(id);
    brain.resetBrain();
    set({
      outputs: new Map(),
      paperTrades: [],
      feedbackLog: [],
      scanInterval: null,
      isRunning: false,
      lastScanTime: 0,
    });
    get().refreshState();
  },
}));
