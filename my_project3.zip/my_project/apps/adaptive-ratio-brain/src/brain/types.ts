// Adaptive Ratio Brain - Type Definitions
// Multi-Exchange, Per-Symbol Learning

import type { ExchangeName } from '../lib/exchangeApi';

export interface RatioData {
  timestamp: number;
  symbol: string;
  exchange: ExchangeName;
  oiRatio: number;
  volRatio: number;
  priceRatio: number;
  fundingRate: number;
  close: number;
  volume: number;
  openInterest: number;
}

export interface DivergenceTrap {
  type: 'LONG_TRAP' | 'SHORT_TRAP' | 'NONE';
  confidence: number;
  description: string;
  oiDirection: 'UP' | 'DOWN' | 'FLAT';
  volDirection: 'UP' | 'DOWN' | 'FLAT';
  priceDirection: 'UP' | 'DOWN' | 'FLAT';
}

export interface SignalFeedback {
  id: string;
  symbol: string;
  exchange: ExchangeName;
  signalType: 'BUY' | 'SELL';
  entryPrice: number;
  entryTime: number;
  trackingCandles: number;
  maxFavorableExcursion: number;
  maxAdverseExcursion: number;
  candlesToConfirm: number;
  result: 'SUCCESS' | 'FAIL' | 'PENDING';
  exitPrice?: number;
  exitTime?: number;
  pnlPercent?: number;
  ratiosAtEntry?: {
    oiRatio: number;
    volRatio: number;
    priceRatio: number;
    fundingRate: number;
  };
}

export interface ActiveRatio {
  id: string;
  name: string;
  successCount: number;
  failCount: number;
  weight: number;
  lastUsed: number;
  status: 'ACTIVE' | 'ARCHIVED';
  avgConfirmationCandles: number;
}

// Per-Symbol Learning Record
export interface SymbolLearning {
  symbol: string;
  exchange: ExchangeName;
  // 12-hour learnings
  shortTermLearnings: LearningRecord[];
  // 30-day learnings
  longTermLearnings: LearningRecord[];
  // Per-symbol ratio effectiveness
  ratioWeights: Record<string, { weight: number; success: number; fail: number; active: boolean }>;
  // Trend reversal ratios learned from paper trades
  reversalPatterns: ReversalPattern[];
  lastUpdated: number;
}

export interface LearningRecord {
  timestamp: number;
  avgOiRatio: number;
  avgVolRatio: number;
  avgPriceRatio: number;
  stdOiRatio: number;
  stdVolRatio: number;
  stdPriceRatio: number;
  avgFundingRate: number;
  marketState: MarketState;
  dominantSignal: 'BUY' | 'SELL' | 'HOLD';
  confidence: number;
  sampleCount: number;
}

export interface ReversalPattern {
  id: string;
  symbol: string;
  exchange: ExchangeName;
  timestamp: number;
  ratiosAtReversal: {
    oiRatio: number;
    volRatio: number;
    priceRatio: number;
    fundingRate: number;
  };
  directionBefore: 'UP' | 'DOWN' | 'FLAT';
  directionAfter: 'UP' | 'DOWN' | 'FLAT';
  pnlPercent: number;
  candlesToConfirm: number;
  useful: boolean; // true = effective, false = archived
}

export interface MemoryShortTerm {
  records: RatioData[];
  avgOiRatio: number;
  avgVolRatio: number;
  avgPriceRatio: number;
  stdOiRatio: number;
  stdVolRatio: number;
  stdPriceRatio: number;
}

export interface MemoryLongTerm {
  records: RatioData[];
  avgOiRatio: number;
  avgVolRatio: number;
  avgPriceRatio: number;
  stdOiRatio: number;
  stdVolRatio: number;
  stdPriceRatio: number;
}

export type MarketState = 'Short-Term Dominant' | 'Long-Term Dominant' | 'Transitioning' | 'Unknown';

export interface BrainOutput {
  symbol: string;
  exchange: ExchangeName;
  marketState: MarketState;
  activeRatios: ActiveRatio[];
  archivedRatios: ActiveRatio[];
  currentSignal: 'BUY' | 'SELL' | 'HOLD';
  confidenceScore: number;
  divergenceTrap: DivergenceTrap;
  feedbackStats: {
    successRate30d: number;
    avgConfirmationCandles: number;
    totalSignals: number;
    activeSignals: number;
  };
  shortTermMemory: {
    avgOiRatio: number;
    avgVolRatio: number;
    avgPriceRatio: number;
  };
  longTermMemory: {
    avgOiRatio: number;
    avgVolRatio: number;
    avgPriceRatio: number;
  };
  lastUpdate: number;
  ratios: {
    oiRatio: number;
    volRatio: number;
    priceRatio: number;
    fundingRate: number;
  };
  crossExchangeData?: {
    priceDivergence: number;
    oiDivergence: number;
    fundingDivergence: number;
    leadExchange: string | null;
  };
}

export interface BrainConfig {
  trackingCandles: number;
  shortTermWindowHours: number;
  shortTermMaxRecords: number;
  longTermWindowDays: number;
  weightIncrement: number;
  weightDecrement: number;
  volumeAvgPeriod: number;
  minConfidence: number;
  trapThresholdOI: number;
  trapThresholdVol: number;
  trapThresholdPrice: number;
  enabledExchanges: ExchangeName[];
  learningInterval12h: number; // ms between 12h learnings
  learningInterval30d: number; // ms between 30d meta-learnings
  maxLearningRecords12h: number;
  maxLearningRecords30d: number;
}

export const DEFAULT_BRAIN_CONFIG: BrainConfig = {
  trackingCandles: 10,
  shortTermWindowHours: 12,
  shortTermMaxRecords: 30,
  longTermWindowDays: 30,
  weightIncrement: 0.1,
  weightDecrement: 0.15,
  volumeAvgPeriod: 20,
  minConfidence: 0.5,
  trapThresholdOI: 0.02,
  trapThresholdVol: 1.5,
  trapThresholdPrice: 0.005,
  enabledExchanges: ['binance', 'bybit', 'okx', 'bitget'],
  learningInterval12h: 12 * 60 * 60 * 1000,
  learningInterval30d: 30 * 24 * 60 * 60 * 1000,
  maxLearningRecords12h: 60,
  maxLearningRecords30d: 12,
};

export interface PaperTrade {
  id: string;
  symbol: string;
  exchange: ExchangeName;
  side: 'LONG' | 'SHORT';
  entryPrice: number;
  currentPrice: number;
  quantity: number;
  leverage: number;
  stopLoss: number;
  takeProfit: number;
  status: 'OPEN' | 'CLOSED_TP' | 'CLOSED_SL' | 'CLOSED_MANUAL';
  openTime: number;
  closeTime?: number;
  pnl: number;
  pnlPercent: number;
  source: 'BRAIN_AUTO' | 'MANUAL';
  signalId?: string;
  brainConfidence?: number;
  ratiosAtEntry?: {
    oiRatio: number;
    volRatio: number;
    priceRatio: number;
    fundingRate: number;
  };
}
