import { useState, useEffect } from 'react';
import { Layout } from './components/Layout';
import { useAppStore } from './store/appStore';
import { Dashboard } from './modules/Dashboard';
import { Market } from './modules/Market';
import { Signals } from './modules/Signals';
import { Validation } from './modules/Validation';
import { AutoTrade } from './modules/AutoTrade';
import { SettingsModule } from './modules/Settings';
import { BrainDashboard } from './modules/BrainDashboard';
import { SystemHealth } from './modules/SystemHealth';
import { AuthPage } from './modules/AuthPage';
import { ApiKeys } from './modules/ApiKeys';
import { DataInjection } from './modules/DataInjection';
import { authService } from './lib/auth';

function PageRouter() {
  const { currentPage } = useAppStore();

  switch (currentPage) {
    case 'dashboard': return <Dashboard />;
    case 'market': return <Market />;
    case 'signals': return <Signals />;
    case 'validation': return <Validation />;
    case 'autotrade': return <AutoTrade />;
    case 'settings': return <SettingsModule />;
    case 'brain': return <BrainDashboard />;
    case 'health': return <SystemHealth />;
    case 'apikeys': return <ApiKeys />;
    case 'datainject': return <DataInjection />;
    default: return <Dashboard />;
  }
}

export function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Check existing session
    const state = authService.getState();
    setIsAuthenticated(state.isAuthenticated);
    setLoading(false);

    // Listen for auth changes
    const unsub = authService.subscribe((state) => {
      setIsAuthenticated(state.isAuthenticated);
    });

    return () => { unsub(); };
  }, []);

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-950 flex items-center justify-center">
        <div className="text-center">
          <div className="text-5xl mb-4">🐋</div>
          <div className="w-10 h-10 border-3 border-cyan-500 border-t-transparent rounded-full animate-spin mx-auto mb-3"></div>
          <p className="text-gray-400 text-sm">Loading Whale Hunter...</p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return <AuthPage onAuth={() => setIsAuthenticated(true)} />;
  }

  return (
    <Layout>
      <PageRouter />
    </Layout>
  );
}
