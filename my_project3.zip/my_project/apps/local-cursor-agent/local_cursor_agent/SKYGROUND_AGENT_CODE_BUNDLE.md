# SkyGround Local Agent - Code Bundle
این فایل برای انتقال کل کدهای ایجنت به یک چت/محیط دیگر ساخته شده است.
> شامل چشم/دست، داشبورد، مغز Ollama/API، Reflex/Skills، حافظه برداری، تزریق، scaffold و مستندات راه‌اندازی.

## File Manifest

- `agent.py` (129055 bytes)
- `dashboard.py` (111519 bytes)
- `security.py` (6095 bytes)
- `text_intelligence.py` (5802 bytes)
- `vector_memory.py` (6928 bytes)
- `desktop_io.py` (16309 bytes)
- `event_journal.py` (2385 bytes)
- `intent_registry.py` (8087 bytes)
- `skill_registry.py` (8538 bytes)
- `reflex_engine.py` (5094 bytes)
- `daily_distiller.py` (6838 bytes)
- `project_scaffolds.py` (9567 bytes)
- `config.example.json` (3136 bytes)
- `README.md` (27766 bytes)
- `QUICKSTART_FA.md` (5618 bytes)
- `INJECTION_GUIDE_FA.md` (5640 bytes)
- `ARCHITECTURE_NEXT.md` (3658 bytes)

---


## `agent.py`

```python
#!/usr/bin/env python3
"""
SkyGround Local Cursor-like Coding Agent v3

- Offline/local LLM via Ollama
- Project file read/write tools
- Terminal command tool with approval
- SQLite long-term memory
- Project index/search with symbol extraction
- Git status/diff tools
- Safer atomic edits with backups and diff preview
- No external Python dependencies

Run:
  python agent.py --config config.json --root "C:\\path\\to\\project"
"""

from __future__ import annotations

import argparse
import dataclasses
import datetime as dt
import difflib
import fnmatch
import hashlib
import json
import os
import queue
import re
import sqlite3
import subprocess
import sys
import textwrap
import threading
import time
import traceback
import uuid
import urllib.error
import urllib.request
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

try:
    from dashboard import AdminControlCenter, DashboardServer
except ImportError:  # pragma: no cover - dashboard.py should exist in normal use
    AdminControlCenter = None  # type: ignore
    DashboardServer = None  # type: ignore

from security import find_secrets, looks_sensitive_path, mask_secrets, sanitize_for_display
from text_intelligence import detect_text_profile
from vector_memory import VectorMemoryStore
from desktop_io import DesktopIORegistry, ShortcutAction
from event_journal import EventJournal
from intent_registry import IntentRegistry
from skill_registry import SkillDefinition, SkillRegistry
from reflex_engine import ReflexEngine
from daily_distiller import DailyDistiller
from project_scaffolds import create_scaffold, list_templates


# -----------------------------
# Config
# -----------------------------


@dataclasses.dataclass(frozen=True)
class AgentConfig:
    # Brain / LLM
    # llm_provider: "ollama" for local offline brain, or "openai_compatible" for APIs like GapGPT.
    llm_provider: str = "ollama"
    ollama_url: str = "http://localhost:11434"
    openai_base_url: str = "https://api.gapgpt.app/v1"
    openai_api_key_env: str = "GAPGPT_API_KEY"
    openai_api_key: str = ""  # Prefer env var; direct key is supported but not recommended.
    openai_timeout_sec: int = 600
    openai_max_tokens: int = 0  # 0 means provider default.

    # Smart brain routing. If llm_provider="auto" or this is true, the agent can route
    # each task between local Ollama and OpenAI-compatible API.
    brain_routing_enabled: bool = False
    brain_routing_simple_provider: str = "ollama"
    brain_routing_complex_provider: str = "openai_compatible"
    brain_routing_sensitive_provider: str = "ollama"
    brain_routing_allow_api_for_sensitive: bool = False

    model: str = "qwen2.5-coder:7b-instruct"
    temperature: float = 0.2
    num_ctx: int = 8192
    max_steps: int = 8
    workspace_root: str = "."
    memory_dir: str = ".sg_agent"

    # Context / reading limits
    max_file_read_chars: int = 20_000
    max_tree_entries: int = 250

    # Project index
    auto_index_on_start: bool = False
    max_index_files: int = 5_000
    max_index_file_bytes: int = 250_000
    index_preview_chars: int = 1_500

    # Safety
    command_timeout_sec: int = 60
    require_approval_for_writes: bool = True
    require_approval_for_commands: bool = True
    create_backups: bool = True
    backup_dir: str = ".sg_agent/backups"
    enable_shortcut_execution: bool = False
    require_approval_for_shortcuts: bool = True
    shortcut_execution_dry_run: bool = False
    shortcut_execution_method: str = "powershell_sendkeys"
    shortcut_execution_delay_ms: int = 120
    min_desktop_confidence_for_shortcut: float = 0.0
    allow_shortcut_without_desktop_state: bool = True
    mask_secrets: bool = True
    mask_secrets_in_memory: bool = True
    block_sensitive_file_reads: bool = False
    sensitive_file_globs: Tuple[str, ...] = (
        ".env",
        ".env.*",
        "**/.env",
        "**/.env.*",
        "*.pem",
        "*.key",
        "id_rsa",
        "id_ed25519",
        "**/secrets/**",
        "**/credentials/**",
        "**/.ssh/**",
    )

    # Admin dashboard / supervision
    enable_dashboard: bool = False
    dashboard_host: str = "127.0.0.1"
    dashboard_port: int = 8765
    dashboard_token: str = ""  # if non-empty, dashboard requires this token
    approval_timeout_sec: int = 0  # 0 means wait forever
    policy_file: str = ".sg_agent/policy.json"
    auto_load_policy: bool = True

    # Learning / vector memory / desktop log eye
    vector_memory_file: str = ".sg_agent/vector_memory.sqlite"
    vector_dimensions: int = 384
    desktop_state_file: str = ".sg_agent/desktop_state.json"

    # Reflex / skill learning layer
    reflex_enabled: bool = True
    reflex_auto_execute_trusted: bool = True
    reflex_trust_threshold: float = 0.85
    reflex_require_approval_for_confirm: bool = True
    skills_file: str = ".sg_agent/skills.json"
    intents_file: str = ".sg_agent/intents.json"
    event_journal_dir: str = ".sg_agent/events"
    distillation_dir: str = ".sg_agent/distillations"

    ignored_dirs: Tuple[str, ...] = (
        ".git",
        ".sg_agent",
        "node_modules",
        ".venv",
        "venv",
        "__pycache__",
        "dist",
        "build",
        ".next",
        ".nuxt",
        ".svelte-kit",
        "target",
        "out",
        "coverage",
        ".pytest_cache",
        ".mypy_cache",
        ".ruff_cache",
    )
    ignored_file_globs: Tuple[str, ...] = (
        "*.pyc",
        "*.pyo",
        "*.exe",
        "*.dll",
        "*.so",
        "*.dylib",
        "*.bin",
        "*.png",
        "*.jpg",
        "*.jpeg",
        "*.gif",
        "*.ico",
        "*.pdf",
        "*.zip",
        "*.tar",
        "*.gz",
        "*.7z",
        "*.rar",
        "*.mp4",
        "*.mp3",
        "*.wav",
        "*.lock",
    )
    blocked_command_fragments: Tuple[str, ...] = (
        "rm -rf /",
        "sudo rm",
        "mkfs",
        "format ",
        "del /s",
        "rmdir /s",
        "shutdown",
        "reboot",
        "reg delete",
        "Remove-Item -Recurse -Force C:\\",
        "Remove-Item -Recurse -Force /",
    )

    @staticmethod
    def load(path: str, root_override: Optional[str] = None) -> "AgentConfig":
        raw: Dict[str, Any] = {}
        p = Path(path)
        if p.exists():
            raw = json.loads(p.read_text(encoding="utf-8"))
        if root_override:
            raw["workspace_root"] = root_override

        tuple_keys = (
            "blocked_command_fragments",
            "ignored_dirs",
            "ignored_file_globs",
            "sensitive_file_globs",
        )
        for key in tuple_keys:
            if key in raw and isinstance(raw[key], list):
                raw[key] = tuple(raw[key])

        cfg = AgentConfig(**raw)
        allowed_providers = {"ollama", "openai_compatible", "auto"}
        if cfg.llm_provider not in allowed_providers:
            raise ValueError("llm_provider must be 'ollama', 'openai_compatible', or 'auto'")
        for provider_field in (cfg.brain_routing_simple_provider, cfg.brain_routing_complex_provider, cfg.brain_routing_sensitive_provider):
            if provider_field not in {"ollama", "openai_compatible"}:
                raise ValueError("brain routing providers must be 'ollama' or 'openai_compatible'")
        if not (0 <= cfg.temperature <= 2):
            raise ValueError("temperature must be between 0 and 2")
        if cfg.max_steps <= 0:
            raise ValueError("max_steps must be positive")
        if cfg.command_timeout_sec <= 0:
            raise ValueError("command_timeout_sec must be positive")
        if cfg.shortcut_execution_delay_ms < 0:
            raise ValueError("shortcut_execution_delay_ms cannot be negative")
        if not (0 <= cfg.min_desktop_confidence_for_shortcut <= 1):
            raise ValueError("min_desktop_confidence_for_shortcut must be between 0 and 1")
        if cfg.openai_timeout_sec <= 0:
            raise ValueError("openai_timeout_sec must be positive")
        if cfg.openai_max_tokens < 0:
            raise ValueError("openai_max_tokens cannot be negative")
        if cfg.dashboard_port <= 0 or cfg.dashboard_port > 65535:
            raise ValueError("dashboard_port must be between 1 and 65535")
        if cfg.approval_timeout_sec < 0:
            raise ValueError("approval_timeout_sec cannot be negative")
        if cfg.max_file_read_chars <= 100:
            raise ValueError("max_file_read_chars is too small")
        if cfg.max_index_files <= 0:
            raise ValueError("max_index_files must be positive")
        if cfg.max_index_file_bytes <= 1024:
            raise ValueError("max_index_file_bytes must be greater than 1024")
        if cfg.vector_dimensions <= 0:
            raise ValueError("vector_dimensions must be positive")
        if not (0 <= cfg.reflex_trust_threshold <= 1):
            raise ValueError("reflex_trust_threshold must be between 0 and 1")
        return cfg


# -----------------------------
# Memory
# -----------------------------


class MemoryStore:
    def __init__(self, db_path: Path, mask_secrets_enabled: bool = True):
        self.db_path = db_path
        self.mask_secrets_enabled = mask_secrets_enabled
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self.lock = threading.RLock()
        self.conn = sqlite3.connect(str(self.db_path), check_same_thread=False)
        self.conn.execute(
            """
            CREATE TABLE IF NOT EXISTS memories (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                created_at TEXT NOT NULL,
                kind TEXT NOT NULL,
                text TEXT NOT NULL,
                metadata_json TEXT NOT NULL DEFAULT '{}'
            )
            """
        )
        self.conn.commit()

    def add(self, kind: str, text: str, metadata: Optional[Dict[str, Any]] = None) -> int:
        created_at = dt.datetime.now(dt.timezone.utc).isoformat()
        safe_text = mask_secrets(text) if self.mask_secrets_enabled else text
        safe_metadata = sanitize_for_display(metadata or {}) if self.mask_secrets_enabled else (metadata or {})
        with self.lock:
            cur = self.conn.execute(
                "INSERT INTO memories(created_at, kind, text, metadata_json) VALUES (?, ?, ?, ?)",
                (created_at, kind, safe_text, json.dumps(safe_metadata, ensure_ascii=False)),
            )
            self.conn.commit()
            return int(cur.lastrowid)

    def search(self, query: str, limit: int = 8) -> List[Dict[str, Any]]:
        q = f"%{query}%"
        with self.lock:
            rows = self.conn.execute(
                """
                SELECT id, created_at, kind, text, metadata_json
                FROM memories
                WHERE text LIKE ? OR kind LIKE ?
                ORDER BY id DESC
                LIMIT ?
                """,
                (q, q, limit),
            ).fetchall()
        return [self._row_to_memory(r) for r in rows]

    def recent(self, limit: int = 8) -> List[Dict[str, Any]]:
        with self.lock:
            rows = self.conn.execute(
                """
                SELECT id, created_at, kind, text, metadata_json
                FROM memories
                ORDER BY id DESC
                LIMIT ?
                """,
                (limit,),
            ).fetchall()
        return [self._row_to_memory(r) for r in rows]

    def export_rows(self, limit: int = 5000) -> List[Dict[str, Any]]:
        with self.lock:
            rows = self.conn.execute(
                """
                SELECT id, created_at, kind, text, metadata_json
                FROM memories
                ORDER BY id DESC
                LIMIT ?
                """,
                (limit,),
            ).fetchall()
        return [self._row_to_memory(r) for r in rows]

    @staticmethod
    def _row_to_memory(r: Tuple[Any, ...]) -> Dict[str, Any]:
        return {
            "id": r[0],
            "created_at": r[1],
            "kind": r[2],
            "text": r[3],
            "metadata": json.loads(r[4] or "{}"),
        }


# -----------------------------
# Project Index
# -----------------------------


LANG_BY_EXT = {
    ".py": "python",
    ".js": "javascript",
    ".jsx": "javascript-react",
    ".ts": "typescript",
    ".tsx": "typescript-react",
    ".mjs": "javascript",
    ".cjs": "javascript",
    ".html": "html",
    ".css": "css",
    ".scss": "scss",
    ".json": "json",
    ".md": "markdown",
    ".yml": "yaml",
    ".yaml": "yaml",
    ".toml": "toml",
    ".ini": "ini",
    ".go": "go",
    ".rs": "rust",
    ".java": "java",
    ".kt": "kotlin",
    ".php": "php",
    ".rb": "ruby",
    ".cs": "csharp",
    ".cpp": "cpp",
    ".cc": "cpp",
    ".c": "c",
    ".h": "c-header",
    ".hpp": "cpp-header",
    ".sh": "shell",
    ".ps1": "powershell",
    ".sql": "sql",
}


class ProjectIndex:
    """SQLite-backed lightweight project index for paths, previews, and symbols."""

    def __init__(self, root: Path, cfg: AgentConfig, conn: sqlite3.Connection, db_lock: Optional[threading.RLock] = None):
        self.root = root.resolve()
        self.cfg = cfg
        self.conn = conn
        self.db_lock = db_lock or threading.RLock()
        self.conn.execute(
            """
            CREATE TABLE IF NOT EXISTS file_index (
                path TEXT PRIMARY KEY,
                size INTEGER NOT NULL,
                mtime REAL NOT NULL,
                sha256 TEXT NOT NULL,
                ext TEXT NOT NULL,
                language TEXT NOT NULL,
                symbols_json TEXT NOT NULL,
                preview TEXT NOT NULL,
                indexed_at TEXT NOT NULL
            )
            """
        )
        self.conn.commit()

    def count(self) -> int:
        with self.db_lock:
            row = self.conn.execute("SELECT COUNT(*) FROM file_index").fetchone()
        return int(row[0] or 0)

    def should_ignore_rel(self, rel: Path) -> bool:
        parts = set(rel.parts)
        if any(part in parts for part in self.cfg.ignored_dirs):
            return True
        rel_posix = rel.as_posix()
        name = rel.name
        return any(fnmatch.fnmatch(rel_posix, pat) or fnmatch.fnmatch(name, pat) for pat in self.cfg.ignored_file_globs)

    def iter_candidate_files(self) -> List[Path]:
        files: List[Path] = []
        for dirpath, dirnames, filenames in os.walk(self.root):
            current = Path(dirpath).resolve()
            rel_dir = current.relative_to(self.root)
            dirnames[:] = [d for d in dirnames if not self.should_ignore_rel(rel_dir / d)]
            for filename in filenames:
                p = current / filename
                rel = p.relative_to(self.root)
                if self.should_ignore_rel(rel):
                    continue
                files.append(p)
                if len(files) >= self.cfg.max_index_files:
                    return files
        return files

    def rebuild(self) -> Dict[str, Any]:
        started = time.time()
        files = self.iter_candidate_files()
        rows = []
        skipped = 0
        for p in files:
            row = self._make_row(p)
            if row is None:
                skipped += 1
                continue
            rows.append(row)

        with self.db_lock:
            self.conn.execute("DELETE FROM file_index")
            self.conn.executemany(
                """
                INSERT OR REPLACE INTO file_index
                (path, size, mtime, sha256, ext, language, symbols_json, preview, indexed_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                rows,
            )
            self.conn.commit()
        elapsed = round(time.time() - started, 3)
        return {
            "ok": True,
            "indexed_files": len(rows),
            "skipped_files": skipped,
            "elapsed_sec": elapsed,
            "summary": self.summary(),
        }

    def upsert_path(self, path: Path) -> None:
        try:
            rel = path.resolve().relative_to(self.root)
        except ValueError:
            return
        rel_posix = rel.as_posix()
        if not path.exists() or not path.is_file() or self.should_ignore_rel(rel):
            with self.db_lock:
                self.conn.execute("DELETE FROM file_index WHERE path = ?", (rel_posix,))
                self.conn.commit()
            return
        row = self._make_row(path)
        if row is None:
            return
        with self.db_lock:
            self.conn.execute(
                """
                INSERT OR REPLACE INTO file_index
                (path, size, mtime, sha256, ext, language, symbols_json, preview, indexed_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                row,
            )
            self.conn.commit()

    def _make_row(self, p: Path) -> Optional[Tuple[Any, ...]]:
        try:
            stat = p.stat()
            rel = p.resolve().relative_to(self.root)
            rel_posix = rel.as_posix()
            ext = p.suffix.lower()
            language = LANG_BY_EXT.get(ext, "text" if ext else "unknown")

            preview = ""
            symbols: List[Dict[str, Any]] = []
            sha = ""

            if stat.st_size <= self.cfg.max_index_file_bytes:
                data = p.read_bytes()
                sha = hashlib.sha256(data).hexdigest()
                if b"\x00" not in data:
                    text = data.decode("utf-8", errors="replace")
                    preview_text = mask_secrets(text) if self.cfg.mask_secrets else text
                    preview = truncate(preview_text, self.cfg.index_preview_chars)
                    symbols = self.extract_symbols(text, ext)
            else:
                sha = f"size:{stat.st_size}:mtime:{stat.st_mtime}"

            indexed_at = dt.datetime.now(dt.timezone.utc).isoformat()
            return (
                rel_posix,
                int(stat.st_size),
                float(stat.st_mtime),
                sha,
                ext,
                language,
                json.dumps(symbols, ensure_ascii=False),
                preview,
                indexed_at,
            )
        except OSError:
            return None

    def extract_symbols(self, text: str, ext: str) -> List[Dict[str, Any]]:
        symbols: List[Dict[str, Any]] = []
        lines = text.splitlines()

        def add(kind: str, name: str, line_no: int) -> None:
            if len(symbols) < 80:
                symbols.append({"kind": kind, "name": name, "line": line_no})

        for i, line in enumerate(lines, start=1):
            if ext == ".py":
                m = re.match(r"^\s*class\s+([A-Za-z_]\w*)", line)
                if m:
                    add("class", m.group(1), i)
                    continue
                m = re.match(r"^\s*(?:async\s+)?def\s+([A-Za-z_]\w*)\s*\(", line)
                if m:
                    add("function", m.group(1), i)
                    continue
            elif ext in {".js", ".jsx", ".ts", ".tsx", ".mjs", ".cjs"}:
                patterns = [
                    ("class", r"^\s*(?:export\s+)?class\s+([A-Za-z_$][\w$]*)"),
                    ("function", r"^\s*(?:export\s+)?(?:async\s+)?function\s+([A-Za-z_$][\w$]*)"),
                    ("function", r"^\s*(?:export\s+)?(?:const|let|var)\s+([A-Za-z_$][\w$]*)\s*=\s*(?:async\s*)?\(?"),
                ]
                for kind, pat in patterns:
                    m = re.match(pat, line)
                    if m:
                        add(kind, m.group(1), i)
                        break
            elif ext in {".go"}:
                m = re.match(r"^func\s+(?:\([^)]*\)\s*)?([A-Za-z_]\w*)\s*\(", line)
                if m:
                    add("function", m.group(1), i)
            elif ext in {".rs"}:
                m = re.match(r"^\s*(?:pub\s+)?(?:async\s+)?fn\s+([A-Za-z_]\w*)\s*\(", line)
                if m:
                    add("function", m.group(1), i)
                m = re.match(r"^\s*(?:pub\s+)?(?:struct|enum|trait)\s+([A-Za-z_]\w*)", line)
                if m:
                    add("type", m.group(1), i)
        return symbols

    def summary(self) -> Dict[str, Any]:
        total = self.count()
        with self.db_lock:
            rows = self.conn.execute(
                "SELECT ext, COUNT(*) FROM file_index GROUP BY ext ORDER BY COUNT(*) DESC LIMIT 10"
            ).fetchall()
            last = self.conn.execute("SELECT MAX(indexed_at) FROM file_index").fetchone()[0]
        return {
            "total_files": total,
            "top_extensions": [{"ext": r[0] or "[none]", "count": r[1]} for r in rows],
            "last_indexed_at": last,
        }

    def search(self, query: str, limit: int = 12) -> Dict[str, Any]:
        query = query.strip()
        if not query:
            return {"ok": False, "error": "query cannot be empty"}
        if self.count() == 0:
            # Search should work out of the box; build the index on first use.
            self.rebuild()

        like = f"%{query.lower()}%"
        with self.db_lock:
            rows = self.conn.execute(
                """
                SELECT path, size, ext, language, symbols_json, preview
                FROM file_index
                WHERE lower(path) LIKE ? OR lower(preview) LIKE ? OR lower(symbols_json) LIKE ?
                ORDER BY path ASC
                LIMIT ?
                """,
                (like, like, like, max(limit * 4, limit)),
            ).fetchall()

        results: List[Dict[str, Any]] = []
        q_lower = query.lower()
        for row in rows:
            rel_path, size, ext, language, symbols_json, preview = row
            snippets = self._line_snippets(rel_path, q_lower, max_snippets=3)
            symbols = json.loads(symbols_json or "[]")
            matching_symbols = [s for s in symbols if q_lower in str(s.get("name", "")).lower()][:5]
            results.append(
                {
                    "path": rel_path,
                    "size": size,
                    "ext": ext,
                    "language": language,
                    "symbols": matching_symbols,
                    "snippets": snippets,
                    "preview": "" if snippets else truncate(preview, 500),
                }
            )
            if len(results) >= limit:
                break
        return {"ok": True, "query": query, "results": results, "index_summary": self.summary()}

    def _line_snippets(self, rel_path: str, q_lower: str, max_snippets: int = 3) -> List[Dict[str, Any]]:
        p = (self.root / rel_path).resolve()
        try:
            if not p.exists() or p.stat().st_size > self.cfg.max_index_file_bytes:
                return []
            data = p.read_bytes()
            if b"\x00" in data:
                return []
            text = data.decode("utf-8", errors="replace")
        except OSError:
            return []
        snippets: List[Dict[str, Any]] = []
        for i, line in enumerate(text.splitlines(), start=1):
            if q_lower in line.lower():
                safe_line = mask_secrets(line.strip()) if self.cfg.mask_secrets else line.strip()
                snippets.append({"line": i, "text": truncate(safe_line, 300)})
                if len(snippets) >= max_snippets:
                    break
        return snippets


# -----------------------------
# Ollama Client
# -----------------------------


class OllamaClient:
    def __init__(self, base_url: str, model: str, temperature: float, num_ctx: int):
        self.base_url = base_url.rstrip("/")
        self.model = model
        self.temperature = temperature
        self.num_ctx = num_ctx

    def chat(self, messages: List[Dict[str, str]]) -> str:
        url = f"{self.base_url}/api/chat"
        payload = {
            "model": self.model,
            "messages": messages,
            "stream": False,
            "options": {
                "temperature": self.temperature,
                "num_ctx": self.num_ctx,
            },
        }
        data = json.dumps(payload).encode("utf-8")
        req = urllib.request.Request(url, data=data, headers={"Content-Type": "application/json"})
        try:
            with urllib.request.urlopen(req, timeout=600) as resp:
                obj = json.loads(resp.read().decode("utf-8"))
                return obj.get("message", {}).get("content", "")
        except urllib.error.URLError as e:
            raise RuntimeError(
                "Could not connect to Ollama. Make sure Ollama is running and the model is pulled. "
                f"URL={url}. Error={e}"
            ) from e


class OpenAICompatibleClient:
    """Minimal OpenAI-compatible chat/completions client without external dependencies.

    Works with providers exposing:
      POST {base_url}/chat/completions
    such as GapGPT base URL: https://api.gapgpt.app/v1
    """

    def __init__(
        self,
        base_url: str,
        api_key: str,
        model: str,
        temperature: float,
        timeout_sec: int = 600,
        max_tokens: int = 0,
    ):
        self.base_url = base_url.rstrip("/")
        self.api_key = api_key
        self.model = model
        self.temperature = temperature
        self.timeout_sec = timeout_sec
        self.max_tokens = max_tokens

    def _chat_url(self) -> str:
        if self.base_url.endswith("/chat/completions"):
            return self.base_url
        return self.base_url + "/chat/completions"

    def chat(self, messages: List[Dict[str, str]]) -> str:
        if not self.api_key:
            raise RuntimeError(
                "OpenAI-compatible provider selected, but API key is missing. "
                "Set openai_api_key_env in config and define that environment variable, "
                "or set openai_api_key directly (not recommended)."
            )
        url = self._chat_url()
        payload: Dict[str, Any] = {
            "model": self.model,
            "messages": messages,
            "temperature": self.temperature,
        }
        if self.max_tokens > 0:
            payload["max_tokens"] = self.max_tokens
        data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        req = urllib.request.Request(
            url,
            data=data,
            headers={
                "Content-Type": "application/json",
                "Authorization": f"Bearer {self.api_key}",
            },
            method="POST",
        )
        try:
            with urllib.request.urlopen(req, timeout=self.timeout_sec) as resp:
                raw = resp.read().decode("utf-8", errors="replace")
                obj = json.loads(raw)
                choices = obj.get("choices") or []
                if not choices:
                    raise RuntimeError(f"OpenAI-compatible API returned no choices. Response={truncate(mask_secrets(raw), 2000)}")
                message = choices[0].get("message") or {}
                content = message.get("content")
                if content is None:
                    # Some compatible APIs may return text.
                    content = choices[0].get("text", "")
                return str(content or "")
        except urllib.error.HTTPError as e:
            body = e.read().decode("utf-8", errors="replace") if e.fp else ""
            raise RuntimeError(f"OpenAI-compatible API HTTP {e.code}: {e.reason}. Body={truncate(mask_secrets(body), 2000)}") from e
        except urllib.error.URLError as e:
            raise RuntimeError(f"Could not connect to OpenAI-compatible API. URL={url}. Error={e}") from e


# -----------------------------
# Utilities
# -----------------------------


def now_local() -> str:
    return dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def truncate(s: str, max_chars: int) -> str:
    if len(s) <= max_chars:
        return s
    return s[:max_chars] + f"\n\n... [truncated: {len(s) - max_chars} chars omitted]"


def yes_no(prompt: str, default: bool = False) -> bool:
    suffix = "[Y/n]" if default else "[y/N]"
    ans = input(f"{prompt} {suffix} ").strip().lower()
    if not ans:
        return default
    return ans in {"y", "yes", "بله", "آره", "اره"}


def extract_json_object(text: str) -> Dict[str, Any]:
    """Try to extract one JSON object from model output."""
    text = text.strip()
    if text.startswith("```"):
        text = re.sub(r"^```(?:json)?", "", text.strip(), flags=re.IGNORECASE).strip()
        text = re.sub(r"```$", "", text.strip()).strip()
    try:
        obj = json.loads(text)
        if isinstance(obj, dict):
            return obj
    except Exception:
        pass

    start = text.find("{")
    end = text.rfind("}")
    if start >= 0 and end > start:
        candidate = text[start : end + 1]
        return json.loads(candidate)
    raise ValueError("Model did not return valid JSON object")


def render_diff(old: str, new: str, fromfile: str = "old", tofile: str = "new") -> str:
    return "".join(
        difflib.unified_diff(
            old.splitlines(keepends=True),
            new.splitlines(keepends=True),
            fromfile=fromfile,
            tofile=tofile,
        )
    )


def atomic_write_text(path: Path, content: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(f".{path.name}.tmp-{os.getpid()}-{int(time.time() * 1000)}")
    tmp.write_text(content, encoding="utf-8")
    os.replace(str(tmp), str(path))


# -----------------------------
# Tools
# -----------------------------


class ToolExecutor:
    def __init__(
        self,
        root: Path,
        cfg: AgentConfig,
        memory: MemoryStore,
        indexer: ProjectIndex,
        admin: Optional[Any] = None,
        vector_store: Optional[VectorMemoryStore] = None,
        desktop_io: Optional[DesktopIORegistry] = None,
    ):
        self.root = root.resolve()
        self.cfg = cfg
        self.memory = memory
        self.indexer = indexer
        self.admin = admin
        self.vector_store = vector_store
        self.desktop_io = desktop_io

    def _safe_path(self, rel_path: str) -> Path:
        rel_path = rel_path or "."
        p = (self.root / rel_path).resolve()
        try:
            p.relative_to(self.root)
        except ValueError:
            raise ValueError(f"Path escapes workspace root: {rel_path}")
        return p

    def _rel(self, path: Path) -> str:
        return path.resolve().relative_to(self.root).as_posix()

    def _backup_file(self, path: Path) -> Optional[str]:
        if not self.cfg.create_backups or not path.exists() or not path.is_file():
            return None
        rel = path.resolve().relative_to(self.root)
        stamp = dt.datetime.now().strftime("%Y%m%d-%H%M%S")
        backup_path = self.root / self.cfg.backup_dir / stamp / rel
        backup_path.parent.mkdir(parents=True, exist_ok=True)
        backup_path.write_bytes(path.read_bytes())
        return backup_path.relative_to(self.root).as_posix()

    def _request_approval(self, kind: str, title: str, details: Dict[str, Any], console_prompt: str) -> bool:
        if self.admin is not None:
            return bool(
                self.admin.request_approval(
                    kind=kind,
                    title=title,
                    details=details,
                    console_fallback=lambda: yes_no(console_prompt),
                )
            )
        return yes_no(console_prompt)

    def _sanitize(self, value: Any, max_string: Optional[int] = None) -> Any:
        if not self.cfg.mask_secrets:
            return value
        return sanitize_for_display(value, max_string=max_string)

    def _mask_text(self, text: str) -> str:
        return mask_secrets(text) if self.cfg.mask_secrets else text

    def _emit(self, event_type: str, message: str, data: Optional[Dict[str, Any]] = None, level: str = "info") -> None:
        if self.admin is not None:
            self.admin.emit(event_type, self._mask_text(message), self._sanitize(data or {}, max_string=4000), level=level)

    def project_tree(self) -> str:
        entries: List[str] = []
        count = 0
        for dirpath, dirnames, filenames in os.walk(self.root):
            current = Path(dirpath).resolve()
            rel_dir = current.relative_to(self.root)
            dirnames[:] = [d for d in dirnames if not self.indexer.should_ignore_rel(rel_dir / d)]
            depth = 0 if str(rel_dir) == "." else len(rel_dir.parts)
            if depth > 3:
                dirnames[:] = []
                continue
            indent = "  " * depth
            if str(rel_dir) != ".":
                entries.append(f"{indent}{rel_dir.name}/")
                count += 1
            for f in sorted(filenames)[:40]:
                rel_file = rel_dir / f
                if self.indexer.should_ignore_rel(rel_file):
                    continue
                entries.append(f"{indent}  {f}")
                count += 1
                if count >= self.cfg.max_tree_entries:
                    entries.append("... [tree truncated]")
                    return "\n".join(entries)
        return "\n".join(entries) if entries else "[empty project]"

    def execute(self, action: Dict[str, Any]) -> Dict[str, Any]:
        tool = action.get("tool")
        args = action.get("args") or {}
        self._emit("tool.start", f"Tool started: {tool}", {"tool": tool, "args": args})
        try:
            if tool == "list_dir":
                result = self.list_dir(str(args.get("path", ".")))
            elif tool == "read_file":
                result = self.read_file(str(args.get("path", "")), int(args.get("max_chars") or self.cfg.max_file_read_chars))
            elif tool == "write_file":
                result = self.write_file(str(args.get("path", "")), str(args.get("content", "")))
            elif tool == "edit_file":
                result = self.edit_file(str(args.get("path", "")), str(args.get("old_text", "")), str(args.get("new_text", "")))
            elif tool == "edit_file_multi":
                result = self.edit_file_multi(str(args.get("path", "")), args.get("replacements") or [])
            elif tool == "apply_patch":
                result = self.apply_patch(str(args.get("patch", "")))
            elif tool == "run_command":
                result = self.run_command(str(args.get("command", "")), str(args.get("cwd", ".")), int(args.get("timeout_sec") or self.cfg.command_timeout_sec))
            elif tool == "index_project":
                result = self.index_project()
            elif tool == "list_project_templates":
                result = self.list_project_templates()
            elif tool == "create_project":
                result = self.create_project(
                    template=str(args.get("template", "")),
                    project_name=str(args.get("project_name", "")),
                    description=str(args.get("description", "")),
                    overwrite=bool(args.get("overwrite", False)),
                    dry_run=bool(args.get("dry_run", False)),
                )
            elif tool == "search_project":
                result = self.search_project(str(args.get("query", "")), int(args.get("limit") or 12))
            elif tool == "add_vector_memory":
                result = self.add_vector_memory(str(args.get("text", "")), str(args.get("namespace", "general")), str(args.get("source", "agent_tool")))
            elif tool == "search_vector_memory":
                result = self.search_vector_memory(str(args.get("query", "")), str(args.get("namespace", "") or ""), int(args.get("limit") or 8))
            elif tool == "register_desktop_log":
                result = self.register_desktop_log(str(args.get("path", "")))
            elif tool == "observe_desktop_logs":
                result = self.observe_desktop_logs()
            elif tool == "register_shortcut":
                result = self.register_shortcut(args)
            elif tool == "suggest_shortcut":
                result = self.suggest_shortcut(str(args.get("intent", "")), str(args.get("app", "") or ""))
            elif tool == "execute_shortcut":
                result = self.execute_shortcut(str(args.get("name", "")), bool(args.get("dry_run", self.cfg.shortcut_execution_dry_run)))
            elif tool == "git_status":
                result = self.git_status(int(args.get("max_chars") or 12_000))
            elif tool == "git_diff":
                result = self.git_diff(str(args.get("path", "")), bool(args.get("staged", False)), int(args.get("max_chars") or 20_000))
            elif tool == "git_log":
                result = self.git_log(int(args.get("limit") or 8))
            elif tool == "ask_admin":
                result = self.ask_admin(
                    str(args.get("question", "")),
                    args.get("options") or [],
                    int(args.get("timeout_sec") or 0),
                )
            elif tool == "remember":
                result = self.remember(str(args.get("text", "")), str(args.get("kind", "experience")))
            elif tool == "search_memory":
                result = self.search_memory(str(args.get("query", "")), int(args.get("limit") or 8))
            elif tool == "finish":
                result = {"ok": True, "finished": True, "final": str(args.get("answer", ""))}
            else:
                result = {"ok": False, "error": f"Unknown tool: {tool}"}
            self._emit("tool.finish", f"Tool finished: {tool}", {"tool": tool, "ok": result.get("ok"), "result": result}, level="info" if result.get("ok") else "warning")
            return result
        except Exception as e:
            result = {"ok": False, "error": str(e), "traceback": traceback.format_exc(limit=2)}
            self._emit("tool.error", f"Tool error: {tool}", result, level="error")
            return result

    def list_dir(self, path: str) -> Dict[str, Any]:
        p = self._safe_path(path)
        if not p.exists():
            return {"ok": False, "error": "path does not exist"}
        if not p.is_dir():
            return {"ok": False, "error": "path is not a directory"}
        items = []
        for child in sorted(p.iterdir(), key=lambda x: (not x.is_dir(), x.name.lower())):
            rel = child.resolve().relative_to(self.root)
            if self.indexer.should_ignore_rel(rel):
                continue
            try:
                stat = child.stat()
                items.append(
                    {
                        "name": child.name,
                        "type": "dir" if child.is_dir() else "file",
                        "size": stat.st_size,
                    }
                )
            except OSError:
                items.append({"name": child.name, "type": "unknown", "size": None})
        return {"ok": True, "path": self._rel(p), "items": items[:300]}

    def read_file(self, path: str, max_chars: int) -> Dict[str, Any]:
        p = self._safe_path(path)
        if not p.exists() or not p.is_file():
            return {"ok": False, "error": "file does not exist"}
        rel_path = self._rel(p)
        sensitive_path = looks_sensitive_path(rel_path, self.cfg.sensitive_file_globs)
        if sensitive_path and self.cfg.block_sensitive_file_reads:
            self._emit("security.sensitive_read_blocked", "Blocked sensitive file read", {"path": rel_path}, level="warning")
            return {"ok": False, "error": "sensitive file read is blocked by config", "path": rel_path, "sensitive_path": True}
        try:
            content = p.read_text(encoding="utf-8")
        except UnicodeDecodeError:
            content = p.read_text(encoding="utf-8", errors="replace")
        findings = find_secrets(content) if self.cfg.mask_secrets else []
        safe_content = mask_secrets(content) if self.cfg.mask_secrets else content
        if findings or sensitive_path:
            self._emit(
                "security.secrets_masked",
                "Secrets/sensitive content masked during read_file",
                {"path": rel_path, "sensitive_path": sensitive_path, "finding_count": len(findings), "findings": findings[:10]},
                level="warning",
            )
        limit = min(max_chars, self.cfg.max_file_read_chars)
        return {
            "ok": True,
            "path": rel_path,
            "content": truncate(safe_content, limit),
            "truncated": len(safe_content) > limit,
            "secrets_masked": bool(findings),
            "sensitive_path": sensitive_path,
            "secret_finding_count": len(findings),
        }

    def write_file(self, path: str, content: str) -> Dict[str, Any]:
        p = self._safe_path(path)
        old = ""
        existed = p.exists()
        if existed and p.is_file():
            old = p.read_text(encoding="utf-8", errors="replace")
        diff = render_diff(old, content, self._rel(p) + " (old)", self._rel(p) + " (new)")
        display_diff = self._mask_text(diff or "[new file/no textual diff]")
        findings = find_secrets(diff) if self.cfg.mask_secrets else []
        print("\n--- Proposed write diff ---")
        print(truncate(display_diff, 16_000))
        print("--- End diff ---\n")
        if (self.cfg.require_approval_for_writes or (self.admin is not None and self.admin.permissions.get("read_only_mode"))) and not self._request_approval(
            kind="write",
            title=f"write_file: {self._rel(p)}",
            details={
                "path": self._rel(p),
                "existed": existed,
                "bytes": len(content.encode("utf-8")),
                "diff": truncate(display_diff, 16_000),
                "secrets_masked": bool(findings),
                "secret_finding_count": len(findings),
            },
            console_prompt=f"Apply write_file to {self._rel(p)}?",
        ):
            return {"ok": False, "cancelled": True, "error": "User rejected write_file"}
        backup = self._backup_file(p)
        atomic_write_text(p, content)
        self.indexer.upsert_path(p)
        self.memory.add("file_changed", f"write_file {self._rel(p)}", {"backup": backup, "existed": existed})
        return {
            "ok": True,
            "path": self._rel(p),
            "bytes": len(content.encode("utf-8")),
            "existed": existed,
            "backup": backup,
        }

    def edit_file(self, path: str, old_text: str, new_text: str) -> Dict[str, Any]:
        return self.edit_file_multi(path, [{"old_text": old_text, "new_text": new_text}])

    def edit_file_multi(self, path: str, replacements: Any) -> Dict[str, Any]:
        if not isinstance(replacements, list) or not replacements:
            return {"ok": False, "error": "replacements must be a non-empty list"}
        p = self._safe_path(path)
        if not p.exists() or not p.is_file():
            return {"ok": False, "error": "file does not exist"}
        original = p.read_text(encoding="utf-8", errors="replace")
        updated = original
        applied: List[Dict[str, Any]] = []

        for idx, rep in enumerate(replacements, start=1):
            if not isinstance(rep, dict):
                return {"ok": False, "error": f"replacement #{idx} must be an object"}
            old_text = str(rep.get("old_text", rep.get("old", "")))
            new_text = str(rep.get("new_text", rep.get("new", "")))
            replace_all = bool(rep.get("replace_all", False))
            if not old_text:
                return {"ok": False, "error": f"replacement #{idx}: old_text cannot be empty"}
            occurrences = updated.count(old_text)
            if occurrences == 0:
                return {
                    "ok": False,
                    "error": f"replacement #{idx}: old_text not found exactly in file",
                    "path": self._rel(p),
                    "old_text_preview": truncate(self._mask_text(old_text), 500),
                }
            if replace_all:
                updated = updated.replace(old_text, new_text)
                count = occurrences
            else:
                updated = updated.replace(old_text, new_text, 1)
                count = 1
            applied.append({"index": idx, "occurrences_before": occurrences, "applied": count})

        if updated == original:
            return {"ok": True, "path": self._rel(p), "changed": False, "message": "No changes produced"}

        diff = render_diff(original, updated, self._rel(p) + " (old)", self._rel(p) + " (new)")
        display_diff = self._mask_text(diff)
        findings = find_secrets(diff) if self.cfg.mask_secrets else []
        print("\n--- Proposed edit diff ---")
        print(truncate(display_diff, 16_000))
        print("--- End diff ---\n")
        if (self.cfg.require_approval_for_writes or (self.admin is not None and self.admin.permissions.get("read_only_mode"))) and not self._request_approval(
            kind="edit",
            title=f"edit_file_multi: {self._rel(p)}",
            details={
                "path": self._rel(p),
                "applied_preview": applied,
                "diff": truncate(display_diff, 16_000),
                "secrets_masked": bool(findings),
                "secret_finding_count": len(findings),
            },
            console_prompt=f"Apply edit_file_multi to {self._rel(p)}?",
        ):
            return {"ok": False, "cancelled": True, "error": "User rejected edit_file_multi"}
        backup = self._backup_file(p)
        atomic_write_text(p, updated)
        self.indexer.upsert_path(p)
        self.memory.add("file_changed", f"edit_file_multi {self._rel(p)}", {"backup": backup, "applied": applied})
        return {"ok": True, "path": self._rel(p), "changed": True, "applied": applied, "backup": backup}

    def _paths_from_unified_patch(self, patch: str) -> List[str]:
        paths: List[str] = []
        for line in patch.splitlines():
            if not (line.startswith("--- ") or line.startswith("+++ ")):
                continue
            raw = line[4:].split("\t", 1)[0].strip()
            if raw == "/dev/null":
                continue
            if raw.startswith("a/") or raw.startswith("b/"):
                raw = raw[2:]
            if raw and raw not in paths:
                # Validate path is inside workspace.
                self._safe_path(raw)
                paths.append(raw)
        return paths

    def apply_patch(self, patch: str) -> Dict[str, Any]:
        """Apply a multi-file unified diff using git apply after approval.

        This is closer to a Cursor-style patch engine than old_text replacement.
        It requires git executable, but does not require committing/staging changes.
        """
        patch = patch.strip("\n") + "\n"
        if not patch.strip():
            return {"ok": False, "error": "patch cannot be empty"}
        paths = self._paths_from_unified_patch(patch)
        if not paths:
            return {"ok": False, "error": "could not detect file paths in unified patch"}

        try:
            check = subprocess.run(
                ["git", "apply", "--check", "--whitespace=nowarn", "-"],
                cwd=str(self.root),
                input=patch,
                capture_output=True,
                text=True,
                timeout=30,
            )
        except FileNotFoundError:
            return {"ok": False, "error": "git executable not found; apply_patch requires git"}
        except subprocess.TimeoutExpired:
            return {"ok": False, "error": "git apply --check timed out"}

        if check.returncode != 0:
            return {
                "ok": False,
                "error": "patch check failed",
                "stdout": truncate(self._mask_text(check.stdout), 4000),
                "stderr": truncate(self._mask_text(check.stderr), 4000),
                "paths": paths,
            }

        display_patch = self._mask_text(patch)
        findings = find_secrets(patch) if self.cfg.mask_secrets else []
        print("\n--- Proposed unified patch ---")
        print(truncate(display_patch, 20_000))
        print("--- End patch ---\n")
        if (self.cfg.require_approval_for_writes or (self.admin is not None and self.admin.permissions.get("read_only_mode"))) and not self._request_approval(
            kind="edit",
            title=f"apply_patch: {len(paths)} file(s)",
            details={"paths": paths, "patch": truncate(display_patch, 20_000), "secrets_masked": bool(findings), "secret_finding_count": len(findings)},
            console_prompt=f"Apply unified patch to {len(paths)} file(s)?",
        ):
            return {"ok": False, "cancelled": True, "error": "User rejected apply_patch"}

        backups: Dict[str, Optional[str]] = {}
        for rel_path in paths:
            p = self._safe_path(rel_path)
            backups[rel_path] = self._backup_file(p)

        apply = subprocess.run(
            ["git", "apply", "--whitespace=nowarn", "-"],
            cwd=str(self.root),
            input=patch,
            capture_output=True,
            text=True,
            timeout=30,
        )
        if apply.returncode != 0:
            return {
                "ok": False,
                "error": "patch apply failed after successful check",
                "stdout": truncate(self._mask_text(apply.stdout), 4000),
                "stderr": truncate(self._mask_text(apply.stderr), 4000),
                "paths": paths,
                "backups": backups,
            }

        for rel_path in paths:
            self.indexer.upsert_path(self._safe_path(rel_path))
        self.memory.add("file_changed", f"apply_patch {len(paths)} files", {"paths": paths, "backups": backups})
        return {"ok": True, "paths": paths, "backups": backups, "stdout": truncate(self._mask_text(apply.stdout), 4000), "stderr": truncate(self._mask_text(apply.stderr), 4000), "secrets_masked": bool(findings), "secret_finding_count": len(findings)}

    def run_command(self, command: str, cwd: str, timeout_sec: int) -> Dict[str, Any]:
        command = command.strip()
        if not command:
            return {"ok": False, "error": "command cannot be empty"}
        lowered = command.lower()
        for frag in self.cfg.blocked_command_fragments:
            if frag.lower() in lowered:
                return {"ok": False, "error": f"blocked dangerous command fragment: {frag}"}
        workdir = self._safe_path(cwd)
        if not workdir.exists() or not workdir.is_dir():
            return {"ok": False, "error": "cwd does not exist or is not directory"}
        display_command = self._mask_text(command)
        print("\n--- Proposed command ---")
        print(f"cwd: {workdir}")
        print(display_command)
        print("--- End command ---\n")
        if (self.cfg.require_approval_for_commands or (self.admin is not None and self.admin.permissions.get("read_only_mode"))) and not self._request_approval(
            kind="command",
            title=f"run_command: {display_command[:120]}",
            details={
                "command": display_command,
                "cwd": self._rel(workdir),
                "timeout_sec": min(timeout_sec, self.cfg.command_timeout_sec),
            },
            console_prompt="Run this command?",
        ):
            return {"ok": False, "cancelled": True, "error": "User rejected run_command"}
        started = time.time()
        proc = subprocess.run(
            command,
            cwd=str(workdir),
            shell=True,
            capture_output=True,
            text=True,
            timeout=min(timeout_sec, self.cfg.command_timeout_sec),
        )
        elapsed = time.time() - started
        return {
            "ok": proc.returncode == 0,
            "returncode": proc.returncode,
            "elapsed_sec": round(elapsed, 3),
            "stdout": truncate(self._mask_text(proc.stdout), 12_000),
            "stderr": truncate(self._mask_text(proc.stderr), 12_000),
        }

    def index_project(self) -> Dict[str, Any]:
        return self.indexer.rebuild()

    def list_project_templates(self) -> Dict[str, Any]:
        return {"ok": True, "templates": list_templates()}

    def create_project(
        self,
        template: str,
        project_name: str,
        description: str = "",
        overwrite: bool = False,
        dry_run: bool = False,
    ) -> Dict[str, Any]:
        try:
            scaffold = create_scaffold(template, project_name, description)
        except Exception as e:
            return {"ok": False, "error": str(e), "available_templates": list_templates()}

        base = self._safe_path(scaffold.project_name)
        if base.exists() and not base.is_dir():
            return {"ok": False, "error": "project path exists and is not a directory", "path": self._rel(base)}

        file_plan: List[Dict[str, Any]] = []
        conflicts: List[str] = []
        combined_diff_parts: List[str] = []
        for rel_file, content in scaffold.files.items():
            dest = (base / rel_file).resolve()
            try:
                dest.relative_to(base.resolve())
                dest.relative_to(self.root)
            except ValueError:
                return {"ok": False, "error": f"scaffold file escapes project/root: {rel_file}"}
            existed = dest.exists()
            if existed and not overwrite:
                conflicts.append(dest.relative_to(self.root).as_posix())
            old = dest.read_text(encoding="utf-8", errors="replace") if existed and dest.is_file() else ""
            diff = render_diff(old, content, dest.relative_to(self.root).as_posix() + " (old)", dest.relative_to(self.root).as_posix() + " (new)")
            combined_diff_parts.append(diff or f"--- {dest.relative_to(self.root).as_posix()} (new file)\n+++ {dest.relative_to(self.root).as_posix()}\n[content length: {len(content)} chars]\n")
            file_plan.append({"path": dest.relative_to(self.root).as_posix(), "bytes": len(content.encode("utf-8")), "existed": existed})

        preview = self._mask_text("\n".join(combined_diff_parts))
        if conflicts and not dry_run:
            return {
                "ok": False,
                "error": "target files already exist; set overwrite=true or choose a different project_name",
                "conflicts": conflicts,
                "template": scaffold.template,
                "project_name": scaffold.project_name,
                "files": file_plan,
                "preview": truncate(preview, 20_000),
            }

        print("\n--- Proposed project scaffold ---")
        print(f"template: {scaffold.template}")
        print(f"project: {scaffold.project_name}")
        print(truncate(preview, 20_000))
        print("--- End scaffold preview ---\n")

        result_base = {
            "ok": True,
            "dry_run": dry_run,
            "template": scaffold.template,
            "project_name": scaffold.project_name,
            "description": scaffold.description,
            "project_path": base.relative_to(self.root).as_posix(),
            "files": file_plan,
            "run_commands": scaffold.run_commands,
            "next_steps": scaffold.next_steps,
            "preview": truncate(preview, 20_000),
            "overwrite": overwrite,
            "conflicts": conflicts,
        }
        if dry_run:
            return result_base

        if self.cfg.require_approval_for_writes and not self._request_approval(
            kind="write",
            title=f"create_project: {scaffold.project_name} ({scaffold.template})",
            details={k: v for k, v in result_base.items() if k != "preview"} | {"preview": truncate(preview, 20_000)},
            console_prompt=f"Create project {scaffold.project_name} from template {scaffold.template}?",
        ):
            return {"ok": False, "cancelled": True, "error": "User rejected create_project", **result_base}

        backups: Dict[str, Optional[str]] = {}
        for rel_file, content in scaffold.files.items():
            dest = (base / rel_file).resolve()
            backups[dest.relative_to(self.root).as_posix()] = self._backup_file(dest)
            atomic_write_text(dest, content)
            self.indexer.upsert_path(dest)
        self.memory.add(
            "project_created",
            f"Created project {scaffold.project_name} using template {scaffold.template}",
            {"template": scaffold.template, "project_path": base.relative_to(self.root).as_posix(), "files": file_plan, "run_commands": scaffold.run_commands},
        )
        result_base["backups"] = backups
        result_base["created"] = True
        return result_base

    def search_project(self, query: str, limit: int) -> Dict[str, Any]:
        return self.indexer.search(query, limit=limit)

    def add_vector_memory(self, text: str, namespace: str = "general", source: str = "agent_tool") -> Dict[str, Any]:
        if self.vector_store is None:
            return {"ok": False, "error": "vector memory is not configured"}
        if not text.strip():
            return {"ok": False, "error": "text cannot be empty"}
        mid = self.vector_store.add(text=text, namespace=namespace or "general", source=source or "agent_tool")
        return {"ok": True, "id": mid, "namespace": namespace or "general"}

    def search_vector_memory(self, query: str, namespace: str = "", limit: int = 8) -> Dict[str, Any]:
        if self.vector_store is None:
            return {"ok": False, "error": "vector memory is not configured"}
        if not query.strip():
            return {"ok": False, "error": "query cannot be empty"}
        results = self.vector_store.search(query=query, namespace=namespace or None, limit=limit)
        return {"ok": True, "query": query, "namespace": namespace or None, "results": [dataclasses.asdict(r) for r in results]}

    def register_desktop_log(self, path: str) -> Dict[str, Any]:
        if self.desktop_io is None:
            return {"ok": False, "error": "desktop I/O registry is not configured"}
        if not path.strip():
            return {"ok": False, "error": "path cannot be empty"}
        return self.desktop_io.register_log_path(path)

    def observe_desktop_logs(self) -> Dict[str, Any]:
        if self.desktop_io is None:
            return {"ok": False, "error": "desktop I/O registry is not configured"}
        result = self.desktop_io.observe_from_logs()
        if self.vector_store is not None and result.get("ok"):
            for obs in result.get("observations", []):
                text = f"Desktop observation app={obs.get('app')} location={obs.get('location')} summary={obs.get('summary')}"
                self.vector_store.add(text, namespace="desktop_observation", source="desktop_logs", metadata=obs)
        return result

    def register_shortcut(self, args: Dict[str, Any]) -> Dict[str, Any]:
        if self.desktop_io is None:
            return {"ok": False, "error": "desktop I/O registry is not configured"}
        name = str(args.get("name", "")).strip()
        description = str(args.get("description", "")).strip()
        keys_raw = args.get("keys", [])
        if isinstance(keys_raw, str):
            keys = [x.strip() for x in keys_raw.split("+") if x.strip()]
        elif isinstance(keys_raw, list):
            keys = [str(x).strip() for x in keys_raw if str(x).strip()]
        else:
            keys = []
        if not name or not keys:
            return {"ok": False, "error": "shortcut name and keys are required"}
        action = ShortcutAction(
            name=name,
            description=description or name,
            keys=keys,
            app=str(args.get("app", "global") or "global"),
            risk=str(args.get("risk", "low") or "low"),
            requires_approval=bool(args.get("requires_approval", False)),
        )
        return self.desktop_io.register_shortcut(action)

    def suggest_shortcut(self, intent: str, app: str = "") -> Dict[str, Any]:
        if self.desktop_io is None:
            return {"ok": False, "error": "desktop I/O registry is not configured"}
        return self.desktop_io.suggest_shortcut(intent, app or None)

    def _desktop_confidence_ok(self) -> Tuple[bool, float, str]:
        threshold = self.cfg.min_desktop_confidence_for_shortcut
        if threshold <= 0:
            return True, 0.0, "confidence check disabled"
        if self.desktop_io is None:
            return False, 0.0, "desktop I/O registry is not configured"
        snapshot = self.desktop_io.get_state_snapshot(limit=5)
        current = snapshot.get("current_by_app", {}) or {}
        if not current:
            return (True, 0.0, "no desktop state; allowed by config") if self.cfg.allow_shortcut_without_desktop_state else (False, 0.0, "no desktop state")
        max_conf = max(float(v.get("confidence") or 0.0) for v in current.values())
        return max_conf >= threshold, max_conf, f"max confidence={max_conf}, threshold={threshold}"

    def execute_shortcut(self, name: str, dry_run: bool = False) -> Dict[str, Any]:
        if self.desktop_io is None:
            return {"ok": False, "error": "desktop I/O registry is not configured"}
        if not name.strip():
            return {"ok": False, "error": "shortcut name cannot be empty"}
        if not self.cfg.enable_shortcut_execution and not dry_run:
            return {"ok": False, "error": "shortcut execution is disabled. Enable it in runtime config or use dry_run=true."}
        ok_conf, confidence, conf_reason = self._desktop_confidence_ok()
        if not ok_conf and not dry_run:
            return {"ok": False, "error": "desktop confidence is too low for shortcut execution", "confidence": confidence, "reason": conf_reason}
        shortcut = self.desktop_io.shortcuts.get(name)
        if not shortcut:
            return {"ok": False, "error": f"shortcut not registered: {name}", "known_shortcuts": list(self.desktop_io.shortcuts.keys())}
        if self.cfg.require_approval_for_shortcuts and not dry_run:
            approved = self._request_approval(
                kind="shortcut",
                title=f"execute_shortcut: {name}",
                details={
                    "name": name,
                    "shortcut": dataclasses.asdict(shortcut),
                    "confidence": confidence,
                    "confidence_reason": conf_reason,
                    "method": self.cfg.shortcut_execution_method,
                },
                console_prompt=f"Execute shortcut {name} ({'+'.join(shortcut.keys)})?",
            )
            if not approved:
                return {"ok": False, "cancelled": True, "error": "User rejected execute_shortcut"}
        return self.desktop_io.execute_shortcut(
            name=name,
            dry_run=dry_run or self.cfg.shortcut_execution_dry_run,
            method=self.cfg.shortcut_execution_method,
            delay_ms=self.cfg.shortcut_execution_delay_ms,
        )

    def _run_git(self, args: List[str], max_chars: int = 12_000) -> Dict[str, Any]:
        try:
            proc = subprocess.run(
                ["git", *args],
                cwd=str(self.root),
                shell=False,
                capture_output=True,
                text=True,
                timeout=30,
            )
            return {
                "ok": proc.returncode == 0,
                "returncode": proc.returncode,
                "stdout": truncate(self._mask_text(proc.stdout), max_chars),
                "stderr": truncate(self._mask_text(proc.stderr), max_chars),
                "command": "git " + " ".join(args),
            }
        except FileNotFoundError:
            return {"ok": False, "error": "git executable not found"}
        except subprocess.TimeoutExpired:
            return {"ok": False, "error": "git command timed out"}

    def git_status(self, max_chars: int = 12_000) -> Dict[str, Any]:
        return self._run_git(["status", "--short", "--branch"], max_chars=max_chars)

    def git_diff(self, path: str = "", staged: bool = False, max_chars: int = 20_000) -> Dict[str, Any]:
        args = ["diff"]
        if staged:
            args.append("--staged")
        if path:
            p = self._safe_path(path)
            args.extend(["--", self._rel(p)])
        return self._run_git(args, max_chars=max_chars)

    def git_log(self, limit: int = 8) -> Dict[str, Any]:
        limit = max(1, min(limit, 30))
        return self._run_git(["log", f"-{limit}", "--oneline", "--decorate"], max_chars=12_000)

    def git_status_for_context(self) -> str:
        res = self.git_status(max_chars=2_000)
        if not res.get("ok"):
            err = res.get("stderr") or res.get("error") or "not a git repository"
            return f"[git unavailable or not a repo: {truncate(str(err), 300)}]"
        return res.get("stdout", "").strip() or "[git clean]"

    def ask_admin(self, question: str, options: Any, timeout_sec: int = 0) -> Dict[str, Any]:
        if not question.strip():
            return {"ok": False, "error": "question cannot be empty"}
        normalized_options: List[str] = []
        if isinstance(options, list):
            normalized_options = [str(x) for x in options[:6]]
        if self.admin is not None:
            return self.admin.ask_admin(
                question=question.strip(),
                options=normalized_options,
                timeout_sec=timeout_sec,
                console_fallback=lambda: input(question.strip() + "\nAdmin answer> ").strip(),
            )
        answer = input(question.strip() + "\nAdmin answer> ").strip()
        return {"ok": True, "answer": answer}

    def remember(self, text: str, kind: str) -> Dict[str, Any]:
        if not text.strip():
            return {"ok": False, "error": "memory text cannot be empty"}
        mid = self.memory.add(kind=kind or "experience", text=text.strip(), metadata={"source": "agent_tool"})
        return {"ok": True, "id": mid}

    def search_memory(self, query: str, limit: int) -> Dict[str, Any]:
        return {"ok": True, "results": self.memory.search(query, limit=limit)}


# -----------------------------
# Agent
# -----------------------------


SYSTEM_PROMPT = r"""
You are SkyGround Local Coding Agent, a careful Cursor-like coding assistant running on the user's own machine.

You can inspect and modify ONLY the selected workspace. You have tools for project indexing/search, file reading, file editing, git inspection, shell commands, and local memory.

CRITICAL OUTPUT RULE:
Return ONLY one valid JSON object. No markdown. No extra text.

JSON format:
{
  "thought": "brief private planning summary in Persian or English",
  "actions": [
    {"tool": "search_project", "args": {"query": "login", "limit": 10}},
    {"tool": "list_dir", "args": {"path": "."}},
    {"tool": "read_file", "args": {"path": "README.md", "max_chars": 12000}},
    {"tool": "edit_file", "args": {"path": "file.py", "old_text": "exact old text", "new_text": "new text"}},
    {"tool": "edit_file_multi", "args": {"path": "file.py", "replacements": [{"old_text": "exact old", "new_text": "new"}]}},
    {"tool": "apply_patch", "args": {"patch": "--- a/file.py\n+++ b/file.py\n@@ -1,1 +1,1 @@\n-old\n+new\n"}},
    {"tool": "write_file", "args": {"path": "new_file.py", "content": "..."}},
    {"tool": "git_status", "args": {}},
    {"tool": "git_diff", "args": {"path": "", "staged": false, "max_chars": 20000}},
    {"tool": "run_command", "args": {"command": "python -m pytest", "cwd": ".", "timeout_sec": 60}},
    {"tool": "index_project", "args": {}},
    {"tool": "list_project_templates", "args": {}},
    {"tool": "create_project", "args": {"template": "python_flask_site", "project_name": "my_site", "description": "A simple Python website", "dry_run": false}}, 
    {"tool": "search_vector_memory", "args": {"query": "login token", "namespace": "monthly_experience", "limit": 5}},
    {"tool": "observe_desktop_logs", "args": {}},
    {"tool": "suggest_shortcut", "args": {"intent": "open search", "app": "vscode"}},
    {"tool": "execute_shortcut", "args": {"name": "open_search", "dry_run": true}},
    {"tool": "ask_admin", "args": {"question": "Do you want me to run the full test suite?", "options": ["yes", "no"], "timeout_sec": 0}},
    {"tool": "remember", "args": {"kind": "project_fact", "text": "..."}},
    {"tool": "search_memory", "args": {"query": "...", "limit": 5}},
    {"tool": "finish", "args": {"answer": "final answer to user"}}
  ]
}

Available tools:
- index_project(): rebuild the local project index. Useful after many changes or if search seems stale.
- search_project(query, limit): search indexed paths, previews, and symbols. Auto-indexes on first use.
- list_project_templates(): list built-in project scaffold templates.
- create_project(template, project_name, description, overwrite, dry_run): create a new project from a built-in template. Use for new-project requests such as "یک وب‌سایت با پایتون بساز". Shows one scaffold preview and requires approval unless dry_run=true.
- list_dir(path): list files/directories under workspace.
- read_file(path, max_chars): read text file.
- write_file(path, content): create/replace a text file. Shows diff, creates backup, requires user approval.
- edit_file(path, old_text, new_text): exact single replacement. Shows diff, creates backup, requires user approval.
- edit_file_multi(path, replacements): multiple exact replacements in one file. Prefer this for several small edits. Shows one diff, creates backup, requires user approval.
- apply_patch(patch): apply a multi-file unified diff using git apply. Prefer this for coordinated multi-file changes. Shows patch, creates backups, requires user/admin approval.
- git_status(): read-only git status. No approval required.
- git_diff(path, staged, max_chars): read-only git diff. No approval required.
- git_log(limit): read-only recent commit log. No approval required.
- run_command(command, cwd, timeout_sec): run shell command. Requires user/admin approval.
- ask_admin(question, options, timeout_sec): ask the human admin through dashboard/CLI and wait for an answer.
- add_vector_memory(text, namespace, source): store an important learned fact in local vector memory.
- search_vector_memory(query, namespace, limit): retrieve semantically related past experiences from vector memory.
- register_desktop_log(path): register an application log file as a safe desktop-eye source.
- observe_desktop_logs(): read registered log tails to infer current app/screen/location without screenshots.
- register_shortcut(name, description, keys, app, risk, requires_approval): register a known shortcut.
- suggest_shortcut(intent, app): suggest registered shortcuts for an intent; does not execute.
- execute_shortcut(name, dry_run): execute a registered shortcut only; no free typing/clicking. Use dry_run first unless the user/admin clearly wants execution.
- remember(kind, text): store long-term experience.
- search_memory(query, limit): retrieve past experiences.
- finish(answer): finish the task.

Behavior rules:
1. For unfamiliar code tasks, start with search_project/list_dir/read_file before editing.
2. For bug fixes, search related names/errors, then inspect the smallest relevant files.
3. Prefer edit_file_multi or edit_file over rewriting whole files.
4. For coordinated multi-file edits, prefer apply_patch with a valid unified diff.
5. For brand-new projects, prefer list_project_templates/create_project before manually writing many files.
6. Use write_file mainly for new files or small complete rewrites.
7. Before meaningful edits in git projects, use git_status if not already available in context.
8. After edits, use git_diff to review and summarize the changes when useful.
9. Never attempt to access files outside workspace.
10. Never run destructive commands.
11. For desktop/app state, prefer observe_desktop_logs and registered shortcuts; do not request screenshots unless absolutely necessary and approved by the user.
12. Before executing a shortcut, verify it is registered and preferably run execute_shortcut with dry_run=true first. Never perform free-form clicking or typing.
13. Use vector memory for learned recurring patterns and search it before repeating old investigations.
14. If you need an operational decision during the task (permission, preference, risky choice), use ask_admin.
15. If you need more information and can stop the task, use finish(answer) with a concise question.
16. After successful changes, remember important project facts or decisions.
17. Final answer should be in Persian unless user asks otherwise.
""".strip()


class LocalCodingAgent:
    def _resolve_openai_api_key(self, cfg: AgentConfig) -> str:
        if cfg.openai_api_key:
            return cfg.openai_api_key
        if cfg.openai_api_key_env:
            return os.environ.get(cfg.openai_api_key_env, "")
        return ""

    def _create_llm_client_for_provider(self, provider: str, cfg: AgentConfig) -> Any:
        if provider == "ollama":
            return OllamaClient(cfg.ollama_url, cfg.model, cfg.temperature, cfg.num_ctx)
        if provider == "openai_compatible":
            return OpenAICompatibleClient(
                base_url=cfg.openai_base_url,
                api_key=self._resolve_openai_api_key(cfg),
                model=cfg.model,
                temperature=cfg.temperature,
                timeout_sec=cfg.openai_timeout_sec,
                max_tokens=cfg.openai_max_tokens,
            )
        raise ValueError(f"Unsupported llm provider: {provider}")

    def _create_llm_client(self, cfg: AgentConfig) -> Any:
        provider = cfg.llm_provider
        if provider == "auto":
            # Default active client for status/fallback. Per-task selection happens in _select_brain.
            if self._provider_available(cfg.brain_routing_complex_provider, cfg):
                provider = cfg.brain_routing_complex_provider
            elif self._provider_available(cfg.brain_routing_simple_provider, cfg):
                provider = cfg.brain_routing_simple_provider
            else:
                provider = "ollama"
        return self._create_llm_client_for_provider(provider, cfg)

    def _provider_available(self, provider: str, cfg: Optional[AgentConfig] = None) -> bool:
        cfg = cfg or self.cfg
        if provider == "ollama":
            return True
        if provider == "openai_compatible":
            return bool(cfg.openai_api_key or (cfg.openai_api_key_env and os.environ.get(cfg.openai_api_key_env)))
        return False

    def _routing_enabled(self) -> bool:
        return self.cfg.llm_provider == "auto" or self.cfg.brain_routing_enabled

    def _task_is_sensitive(self, text: str) -> bool:
        lowered = (text or "").lower()
        sensitive_keywords = [
            ".env", "api key", "apikey", "token", "secret", "password", "passwd", "pwd",
            "private key", "credential", "credentials", "ssh", "pem", "database_url",
            "db_url", "connection string", "authorization", "bearer", "access key",
        ]
        if find_secrets(text):
            return True
        return any(k in lowered for k in sensitive_keywords)

    def _task_is_complex(self, text: str) -> bool:
        lowered = (text or "").lower()
        complex_keywords = [
            "implement", "پیاده", "اعمال", "refactor", "ری‌فکتور", "rewrite", "bug", "fix",
            "debug", "error", "exception", "traceback", "stack", "test", "pytest", "build",
            "architecture", "معماری", "patch", "diff", "multi-file", "security", "review",
            "performance", "optimize", "بهینه", "database", "migration", "api", "login", "auth",
        ]
        return len(text or "") > 900 or any(k in lowered for k in complex_keywords)

    def _select_brain(self, task_text: str) -> Tuple[Any, Dict[str, Any]]:
        cfg = self.cfg
        if not self._routing_enabled():
            provider = cfg.llm_provider if cfg.llm_provider != "auto" else cfg.brain_routing_complex_provider
            if provider == "openai_compatible" and not self._provider_available(provider, cfg):
                provider = "ollama"
            return self._create_llm_client_for_provider(provider, cfg), {
                "routing_enabled": False,
                "provider": provider,
                "reason": "configured_provider",
                "sensitive": self._task_is_sensitive(task_text),
                "complex": self._task_is_complex(task_text),
            }

        sensitive = self._task_is_sensitive(task_text)
        complex_task = self._task_is_complex(task_text)
        reason = "simple_task"
        if sensitive and not cfg.brain_routing_allow_api_for_sensitive:
            provider = cfg.brain_routing_sensitive_provider
            reason = "sensitive_local_policy"
        elif complex_task:
            provider = cfg.brain_routing_complex_provider
            reason = "complex_task"
        else:
            provider = cfg.brain_routing_simple_provider

        fallback = None
        if provider == "openai_compatible" and not self._provider_available(provider, cfg):
            fallback = "openai_api_key_missing"
            provider = "ollama"
        if provider not in {"ollama", "openai_compatible"}:
            fallback = f"invalid_provider_{provider}"
            provider = "ollama"

        return self._create_llm_client_for_provider(provider, cfg), {
            "routing_enabled": True,
            "provider": provider,
            "reason": reason,
            "fallback": fallback,
            "sensitive": sensitive,
            "complex": complex_task,
            "allow_api_for_sensitive": cfg.brain_routing_allow_api_for_sensitive,
        }

    def __init__(self, cfg: AgentConfig):
        self.cfg = cfg
        self.root = Path(cfg.workspace_root).resolve()
        if not self.root.exists():
            raise FileNotFoundError(f"Workspace root does not exist: {self.root}")
        self.started_at = time.time()
        self.current_task: Optional[str] = None
        self.current_task_id: Optional[str] = None
        self.task_running = False
        self.total_tasks = 0
        self.last_error: Optional[str] = None
        self.last_brain_route: Optional[Dict[str, Any]] = None
        self.dashboard_server: Optional[Any] = None

        # Dashboard task manager state
        self.run_lock = threading.RLock()
        self.task_lock = threading.RLock()
        self.task_queue: "queue.Queue[str]" = queue.Queue()
        self.tasks: Dict[str, Dict[str, Any]] = {}
        self.task_worker_thread: Optional[threading.Thread] = None
        self.pause_requested = False

        mem_dir = self.root / cfg.memory_dir
        self.memory = MemoryStore(mem_dir / "memory.sqlite", mask_secrets_enabled=cfg.mask_secrets_in_memory)
        self.indexer = ProjectIndex(self.root, cfg, self.memory.conn, db_lock=self.memory.lock)
        vector_path = (self.root / cfg.vector_memory_file).resolve()
        desktop_state_path = (self.root / cfg.desktop_state_file).resolve()
        skills_path = (self.root / cfg.skills_file).resolve()
        intents_path = (self.root / cfg.intents_file).resolve()
        events_dir = (self.root / cfg.event_journal_dir).resolve()
        distillation_dir = (self.root / cfg.distillation_dir).resolve()
        try:
            vector_path.relative_to(self.root)
            desktop_state_path.relative_to(self.root)
            skills_path.relative_to(self.root)
            intents_path.relative_to(self.root)
            events_dir.relative_to(self.root)
            distillation_dir.relative_to(self.root)
        except ValueError:
            raise ValueError("agent state files must stay inside the workspace root")
        self.vector_store = VectorMemoryStore(vector_path, dimensions=cfg.vector_dimensions)
        self.desktop_io = DesktopIORegistry(self.root, state_path=desktop_state_path)
        self.event_journal = EventJournal(events_dir)
        self.intent_registry = IntentRegistry(intents_path)
        self.skill_registry = SkillRegistry(skills_path)
        self.reflex = ReflexEngine(self.intent_registry, self.skill_registry, self.event_journal)
        self.daily_distiller = DailyDistiller(self.event_journal, self.skill_registry, distillation_dir)
        self._seed_foundation_shortcuts()

        self.admin: Optional[Any] = None
        if cfg.enable_dashboard:
            if AdminControlCenter is None or DashboardServer is None:
                raise RuntimeError("dashboard.py is required when enable_dashboard=true")
            policy_path = (self.root / cfg.policy_file).resolve()
            try:
                policy_path.relative_to(self.root)
            except ValueError:
                raise ValueError("policy_file must stay inside the workspace root")
            self.admin = AdminControlCenter(approval_timeout_sec=cfg.approval_timeout_sec)
            self.admin.set_policy_storage(policy_path, auto_load=cfg.auto_load_policy)
            self.admin.set_status_provider(self.status_snapshot)
            self.admin.set_config_callbacks(self.runtime_config_snapshot, self.apply_runtime_config_update)
            self.admin.set_task_callbacks(self.submit_dashboard_task, self.task_manager_snapshot, self.control_dashboard_task)
            self.admin.set_agent_ops_handler(self.handle_dashboard_operation)
            self.dashboard_server = DashboardServer(self.admin, cfg.dashboard_host, cfg.dashboard_port, auth_token=cfg.dashboard_token)
            dashboard_url = self.dashboard_server.start_background()
            print(f"[dashboard] Admin dashboard: {dashboard_url}")

        self.tools = ToolExecutor(self.root, cfg, self.memory, self.indexer, admin=self.admin, vector_store=self.vector_store, desktop_io=self.desktop_io)
        self.llm = self._create_llm_client(cfg)
        if self.admin is not None:
            self.task_worker_thread = threading.Thread(target=self._task_worker_loop, name="SkyGroundTaskWorker", daemon=True)
            self.task_worker_thread.start()
        if cfg.auto_index_on_start and self.indexer.count() == 0:
            print("[index] auto-indexing project on start...")
            print(json.dumps(self.indexer.rebuild(), ensure_ascii=False, indent=2))

    def _seed_foundation_shortcuts(self) -> None:
        """Seed basic low-level shortcuts used by reflex skills."""
        defaults = [
            ShortcutAction("copy", "Copy selection", ["Ctrl", "C"], app="global", risk="low"),
            ShortcutAction("paste", "Paste clipboard", ["Ctrl", "V"], app="global", risk="medium"),
            ShortcutAction("cut", "Cut selection", ["Ctrl", "X"], app="global", risk="medium"),
            ShortcutAction("save", "Save active file/window", ["Ctrl", "S"], app="global", risk="low"),
            ShortcutAction("escape", "Press Escape", ["Esc"], app="global", risk="low"),
            ShortcutAction("open_search", "Open search / quick search", ["Ctrl", "K"], app="global", risk="low"),
            ShortcutAction("command_palette", "Open command palette", ["Ctrl", "Shift", "P"], app="vscode", risk="low"),
        ]
        for action in defaults:
            if action.name not in self.desktop_io.shortcuts:
                self.desktop_io.register_shortcut(action)

    # ---------- Dashboard task manager ----------

    def submit_dashboard_task(self, prompt: str, source: str = "dashboard") -> Dict[str, Any]:
        prompt = prompt.strip()
        if not prompt:
            return {"ok": False, "error": "task prompt cannot be empty"}
        task_id = str(uuid.uuid4())
        language_profile = detect_text_profile(prompt).to_dict()
        record = {
            "id": task_id,
            "prompt": prompt,
            "language_profile": language_profile,
            "source": source,
            "status": "queued",
            "created_at": now_local(),
            "updated_at": now_local(),
            "started_at": None,
            "finished_at": None,
            "result": "",
            "error": "",
            "cancel_requested": False,
        }
        with self.task_lock:
            self.tasks[task_id] = record
            self.task_queue.put(task_id)
        self.memory.add("task_queued", prompt, {"task_id": task_id, "source": source, "language_profile": language_profile})
        if self.admin is not None:
            self.admin.emit("task.queued", "Task queued", {"task_id": task_id, "prompt": truncate(prompt, 1200), "source": source, "language_profile": language_profile})
        visible_record = sanitize_for_display(dict(record)) if self.cfg.mask_secrets else dict(record)
        return {"ok": True, "task": visible_record}

    def task_manager_snapshot(self) -> Dict[str, Any]:
        with self.task_lock:
            tasks = [dict(v) for v in self.tasks.values()]
            tasks.sort(key=lambda t: t.get("created_at") or "")
            visible_tasks = sanitize_for_display(tasks[-100:]) if self.cfg.mask_secrets else tasks[-100:]
            return {
                "ok": True,
                "paused": self.pause_requested,
                "queue_size": self.task_queue.qsize(),
                "current_task_id": self.current_task_id,
                "tasks": visible_tasks,
            }

    def control_dashboard_task(self, action: str, task_id: Optional[str] = None) -> Dict[str, Any]:
        action = action.strip().lower()
        if action == "pause":
            self.pause_requested = True
            return {"ok": True, "paused": True}
        if action == "resume":
            self.pause_requested = False
            return {"ok": True, "paused": False}
        if action == "clear_emergency_stop":
            self.pause_requested = False
            return {"ok": True, "paused": False}
        if action == "emergency_stop":
            self.pause_requested = True
            with self.task_lock:
                for rec in self.tasks.values():
                    if rec.get("status") in {"queued", "running", "cancelling"}:
                        rec["cancel_requested"] = True
                        if rec.get("status") == "queued":
                            rec["status"] = "cancelled"
                            rec["finished_at"] = now_local()
                            rec["updated_at"] = now_local()
                            rec["error"] = "cancelled by emergency stop"
            return {"ok": True, "emergency_stop": True, "paused": True}
        if action == "cancel":
            if not task_id:
                return {"ok": False, "error": "task_id is required for cancel"}
            with self.task_lock:
                rec = self.tasks.get(task_id)
                if not rec:
                    return {"ok": False, "error": "task not found"}
                rec["cancel_requested"] = True
                rec["updated_at"] = now_local()
                if rec.get("status") == "queued":
                    rec["status"] = "cancelled"
                    rec["finished_at"] = now_local()
                    rec["error"] = "cancelled before start"
                elif rec.get("status") == "running":
                    rec["status"] = "cancelling"
            if self.admin is not None:
                self.admin.emit("task.cancel_requested", "Task cancel requested", {"task_id": task_id}, level="warning")
            return {"ok": True, "task_id": task_id, "cancel_requested": True}
        return {"ok": False, "error": f"unknown task control action: {action}"}

    def _task_worker_loop(self) -> None:
        while True:
            task_id = self.task_queue.get()
            try:
                with self.task_lock:
                    rec = self.tasks.get(task_id)
                    if not rec or rec.get("status") == "cancelled" or rec.get("cancel_requested"):
                        continue
                    prompt = str(rec.get("prompt", ""))
                try:
                    answer = self.run_task(prompt, task_id=task_id)
                    with self.task_lock:
                        rec = self.tasks.get(task_id)
                        if rec and rec.get("status") not in {"cancelled"}:
                            rec["status"] = "completed"
                            rec["result"] = answer
                            rec["finished_at"] = now_local()
                            rec["updated_at"] = now_local()
                    self.memory.add("task_completed", answer, {"task_id": task_id})
                except RuntimeError as e:
                    # Used for cooperative cancellation.
                    with self.task_lock:
                        rec = self.tasks.get(task_id)
                        if rec:
                            rec["status"] = "cancelled" if "cancelled" in str(e).lower() else "failed"
                            rec["error"] = str(e)
                            rec["finished_at"] = now_local()
                            rec["updated_at"] = now_local()
                    if self.admin is not None:
                        self.admin.emit("task.worker_cancelled", "Task cancelled/failed", {"task_id": task_id, "error": str(e)}, level="warning")
                except Exception as e:
                    with self.task_lock:
                        rec = self.tasks.get(task_id)
                        if rec:
                            rec["status"] = "failed"
                            rec["error"] = str(e)
                            rec["finished_at"] = now_local()
                            rec["updated_at"] = now_local()
                    if self.admin is not None:
                        self.admin.emit("task.worker_error", "Task worker error", {"task_id": task_id, "error": str(e), "traceback": traceback.format_exc(limit=3)}, level="error")
            finally:
                self.task_queue.task_done()

    def _is_task_cancelled(self, task_id: Optional[str]) -> bool:
        if not task_id:
            return False
        with self.task_lock:
            rec = self.tasks.get(task_id)
            return bool(rec and rec.get("cancel_requested"))

    def _wait_if_paused_or_cancelled(self, task_id: Optional[str]) -> None:
        while self.pause_requested:
            if self._is_task_cancelled(task_id):
                raise RuntimeError("Task cancelled")
            time.sleep(0.25)
        if self._is_task_cancelled(task_id):
            raise RuntimeError("Task cancelled")

    def _execute_skill_definition(self, skill: SkillDefinition, dry_run: bool, approval_reason: str) -> Dict[str, Any]:
        executor = skill.executor
        args = dict(skill.args or {})
        if executor == "execute_shortcut":
            return self.tools.execute_shortcut(str(args.get("name", "")), dry_run=dry_run)
        if dry_run:
            return {"ok": True, "dry_run": True, "executor": executor, "args": args, "message": "dry run; no tool executed"}
        if executor == "git_status":
            return self.tools.git_status()
        if executor == "git_diff":
            return self.tools.git_diff()
        if executor == "index_project":
            return self.tools.index_project()
        if executor == "observe_desktop_logs":
            return self.tools.observe_desktop_logs()
        if executor == "search_project":
            return self.tools.search_project(str(args.get("query", "")), int(args.get("limit") or 12))
        if executor == "search_memory":
            query = str(args.get("query", ""))
            if args.get("query_from_command"):
                query = str(args.get("_command", query))
            return self.tools.search_memory(query, int(args.get("limit") or 8))
        return {"ok": False, "error": f"unsupported reflex skill executor: {executor}", "args": args}

    def _approve_reflex_skill(self, skill: SkillDefinition, resolved: Dict[str, Any], reason: str) -> bool:
        if self.admin is not None:
            return bool(
                self.admin.request_approval(
                    kind="reflex",
                    title=f"reflex: {skill.id}",
                    details={"skill": dataclasses.asdict(skill), "resolved": resolved, "approval_reason": reason},
                    console_fallback=lambda: yes_no(f"Execute reflex skill {skill.id}?"),
                )
            )
        return yes_no(f"Execute reflex skill {skill.id}?")

    def execute_reflex_command(self, command: str, dry_run: bool = False) -> Dict[str, Any]:
        if not self.cfg.reflex_enabled:
            return {"ok": False, "error": "reflex layer is disabled"}
        result = self.reflex.execute(
            command=command,
            executor=self._execute_skill_definition,
            dry_run=dry_run,
            approval_callback=self._approve_reflex_skill,
            auto_execute_trusted=self.cfg.reflex_auto_execute_trusted,
            trust_threshold=self.cfg.reflex_trust_threshold,
            require_approval_for_confirm=self.cfg.reflex_require_approval_for_confirm,
        )
        if result.get("ok"):
            self.memory.add("reflex_executed", command, {"result": result})
        return result

    def admin_inject(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        """Admin injection center: text/file/JSON bundle into memory, vector memory, intents, skills, shortcuts."""
        mode = str(payload.get("mode", "text") or "text").lower()
        source = str(payload.get("source", "dashboard_admin") or "dashboard_admin")
        namespace = str(payload.get("namespace", "admin_injection") or "admin_injection")
        kind = str(payload.get("kind", "admin_note") or "admin_note")
        inject_memory = bool(payload.get("memory", True))
        inject_vector = bool(payload.get("vector", True))
        overwrite = bool(payload.get("overwrite", True))
        summary: Dict[str, Any] = {
            "ok": True,
            "mode": mode,
            "source": source,
            "namespace": namespace,
            "memory_added": 0,
            "vector_added": 0,
            "intents_added": 0,
            "skills_added": 0,
            "shortcuts_added": 0,
            "errors": [],
            "results": [],
        }

        def add_text(text: str, item_kind: str = kind, metadata: Optional[Dict[str, Any]] = None) -> None:
            text = (text or "").strip()
            if not text:
                return
            meta = {"source": source, **(metadata or {})}
            if inject_memory:
                self.memory.add(item_kind, text, meta)
                summary["memory_added"] += 1
            if inject_vector:
                self.vector_store.add(text, namespace=namespace, source=source, metadata={"kind": item_kind, **meta})
                summary["vector_added"] += 1

        if mode in {"text", "file_text", "manual"}:
            text = str(payload.get("text", ""))
            if not text.strip():
                return {"ok": False, "error": "text is empty"}
            add_text(text, kind, {"injection_mode": mode, "filename": payload.get("filename")})
        elif mode in {"json", "json_bundle", "bundle"}:
            raw = payload.get("json")
            if raw is None:
                raw = payload.get("text", "")
            try:
                obj = json.loads(raw) if isinstance(raw, str) else raw
            except Exception as e:
                return {"ok": False, "error": f"invalid JSON: {e}"}
            if isinstance(obj, list):
                obj = {"memories": obj}
            if not isinstance(obj, dict):
                return {"ok": False, "error": "JSON bundle must be an object or list"}
            for item in obj.get("memories", []):
                if isinstance(item, str):
                    add_text(item, kind, {"bundle_section": "memories"})
                elif isinstance(item, dict):
                    add_text(str(item.get("text", "")), str(item.get("kind", kind)), {"bundle_section": "memories", "metadata": item.get("metadata", {})})
            for item in obj.get("vector_memories", []):
                if isinstance(item, str):
                    self.vector_store.add(item, namespace=namespace, source=source, metadata={"bundle_section": "vector_memories"})
                    summary["vector_added"] += 1
                elif isinstance(item, dict):
                    self.vector_store.add(str(item.get("text", "")), namespace=str(item.get("namespace", namespace)), source=str(item.get("source", source)), metadata=item.get("metadata", {}))
                    summary["vector_added"] += 1
            for item in obj.get("intents", []):
                if isinstance(item, dict):
                    res = self.intent_registry.register_intent(item, overwrite=overwrite)
                    summary["results"].append(res)
                    if res.get("ok"):
                        summary["intents_added"] += 1
                    else:
                        summary["errors"].append(res)
            for item in obj.get("skills", []):
                if isinstance(item, dict):
                    res = self.skill_registry.register_skill(item, overwrite=overwrite)
                    summary["results"].append(res)
                    if res.get("ok"):
                        summary["skills_added"] += 1
                    else:
                        summary["errors"].append(res)
            for item in obj.get("shortcuts", []):
                if isinstance(item, dict):
                    res = self.tools.register_shortcut(item)
                    summary["results"].append(res)
                    if res.get("ok"):
                        summary["shortcuts_added"] += 1
                    else:
                        summary["errors"].append(res)
        else:
            return {"ok": False, "error": f"unknown injection mode: {mode}"}

        self.event_journal.record("admin.inject", summary)
        self.memory.add("admin_injection_summary", json.dumps(summary, ensure_ascii=False), {"source": source, "mode": mode})
        return summary

    def handle_dashboard_operation(self, operation: str, payload: Dict[str, Any]) -> Dict[str, Any]:
        operation = operation.strip().lower()
        if operation == "reflex_resolve":
            return self.reflex.resolve(str(payload.get("command", "")))
        if operation == "reflex_execute":
            return self.execute_reflex_command(str(payload.get("command", "")), dry_run=bool(payload.get("dry_run", False)))
        if operation == "skill_list":
            return {"ok": True, "skills": self.skill_registry.list_skills(), "intents": self.intent_registry.list_intents()}
        if operation == "skill_promote":
            return self.skill_registry.promote(str(payload.get("skill_id", "")), str(payload.get("status", "trusted")))
        if operation == "event_recent":
            return {"ok": True, "events": self.event_journal.recent(limit=int(payload.get("limit") or 100))}
        if operation == "event_counts":
            return self.event_journal.summarize_counts()
        if operation == "daily_distill":
            day = str(payload.get("day", "") or "") or None
            apply_changes = bool(payload.get("apply", False))
            inject_vector = bool(payload.get("inject_vector", True))
            report = self.daily_distiller.distill(day=day, apply=apply_changes)
            self.memory.add("daily_distillation", json.dumps(report, ensure_ascii=False), {"day": report.get("day"), "path": report.get("path"), "apply": apply_changes})
            if inject_vector:
                text = "\n".join(report.get("lesson_lines", []))
                self.vector_store.add(text, namespace="daily_distillation", source="daily_distiller", metadata={"day": report.get("day"), "path": report.get("path")})
            return report
        if operation == "admin_inject":
            return self.admin_inject(payload)
        if operation == "list_project_templates":
            return self.tools.list_project_templates()
        if operation == "create_project":
            return self.tools.create_project(
                template=str(payload.get("template", "")),
                project_name=str(payload.get("project_name", "")),
                description=str(payload.get("description", "")),
                overwrite=bool(payload.get("overwrite", False)),
                dry_run=bool(payload.get("dry_run", False)),
            )
        if operation == "search_vector_memory":
            return self.tools.search_vector_memory(
                query=str(payload.get("query", "")),
                namespace=str(payload.get("namespace", "") or ""),
                limit=int(payload.get("limit") or 8),
            )
        if operation == "monthly_inject_memory":
            namespace = str(payload.get("namespace", "monthly_experience") or "monthly_experience")
            month = str(payload.get("month", "") or "") or None
            rows = self.memory.export_rows(limit=int(payload.get("limit") or 5000))
            result = self.vector_store.monthly_inject_from_rows(rows, month=month, namespace=namespace)
            self.memory.add("monthly_vector_injection", json.dumps(result, ensure_ascii=False), {"namespace": namespace, "month": month})
            return result
        if operation == "register_desktop_log":
            return self.tools.register_desktop_log(str(payload.get("path", "")))
        if operation == "observe_desktop_logs":
            return self.tools.observe_desktop_logs()
        if operation == "get_desktop_state":
            return self.desktop_io.get_state_snapshot(limit=int(payload.get("limit") or 30))
        if operation == "register_shortcut":
            return self.tools.register_shortcut(payload)
        if operation == "suggest_shortcut":
            return self.tools.suggest_shortcut(str(payload.get("intent", "")), str(payload.get("app", "") or ""))
        if operation == "execute_shortcut":
            return self.tools.execute_shortcut(str(payload.get("name", "")), bool(payload.get("dry_run", self.cfg.shortcut_execution_dry_run)))
        return {"ok": False, "error": f"unknown dashboard operation: {operation}"}

    def status_snapshot(self) -> Dict[str, Any]:
        return {
            "ok": True,
            "workspace": str(self.root),
            "llm_provider": self.cfg.llm_provider,
            "brain_routing_enabled": self._routing_enabled(),
            "last_brain_route": self.last_brain_route,
            "model": self.cfg.model,
            "task_running": self.task_running,
            "current_task_id": self.current_task_id,
            "current_task": truncate(mask_secrets(self.current_task or "") if self.cfg.mask_secrets else (self.current_task or ""), 1000),
            "task_paused": self.pause_requested,
            "total_tasks": self.total_tasks,
            "uptime_sec": round(time.time() - self.started_at, 1),
            "last_error": mask_secrets(self.last_error or "") if (self.cfg.mask_secrets and self.last_error) else self.last_error,
            "index": self.indexer.summary(),
            "git_status": truncate(self.tools.git_status_for_context() if hasattr(self, "tools") else "", 2000),
            "current_task_language": detect_text_profile(self.current_task or "").to_dict() if self.current_task else None,
            "vector_memory_count": self.vector_store.count() if hasattr(self, "vector_store") else 0,
            "desktop_log_count": len(self.desktop_io.log_paths) if hasattr(self, "desktop_io") else 0,
            "shortcut_count": len(self.desktop_io.shortcuts) if hasattr(self, "desktop_io") else 0,
            "skill_count": len(self.skill_registry.skills) if hasattr(self, "skill_registry") else 0,
            "intent_count": len(self.intent_registry.intents) if hasattr(self, "intent_registry") else 0,
            "event_counts": self.event_journal.summarize_counts() if hasattr(self, "event_journal") else {},
            "policy_file": str(self.root / self.cfg.policy_file),
        }

    def runtime_config_snapshot(self) -> Dict[str, Any]:
        cfg_dict = dataclasses.asdict(self.cfg)
        if cfg_dict.get("dashboard_token"):
            cfg_dict["dashboard_token"] = "***"
        if cfg_dict.get("openai_api_key"):
            cfg_dict["openai_api_key"] = "***"
        cfg_dict["ignored_dirs"] = list(self.cfg.ignored_dirs)
        cfg_dict["ignored_file_globs"] = list(self.cfg.ignored_file_globs)
        cfg_dict["blocked_command_fragments"] = list(self.cfg.blocked_command_fragments)
        editable = [
            "llm_provider",
            "model",
            "ollama_url",
            "openai_base_url",
            "openai_api_key_env",
            "openai_api_key",
            "openai_timeout_sec",
            "openai_max_tokens",
            "brain_routing_enabled",
            "brain_routing_simple_provider",
            "brain_routing_complex_provider",
            "brain_routing_sensitive_provider",
            "brain_routing_allow_api_for_sensitive",
            "enable_shortcut_execution",
            "require_approval_for_shortcuts",
            "shortcut_execution_dry_run",
            "shortcut_execution_method",
            "shortcut_execution_delay_ms",
            "min_desktop_confidence_for_shortcut",
            "allow_shortcut_without_desktop_state",
            "reflex_enabled",
            "reflex_auto_execute_trusted",
            "reflex_trust_threshold",
            "reflex_require_approval_for_confirm",
            "skills_file",
            "intents_file",
            "event_journal_dir",
            "distillation_dir",
            "temperature",
            "num_ctx",
            "max_steps",
            "max_file_read_chars",
            "max_tree_entries",
            "command_timeout_sec",
            "require_approval_for_writes",
            "require_approval_for_commands",
            "create_backups",
            "mask_secrets",
            "mask_secrets_in_memory",
            "block_sensitive_file_reads",
            "approval_timeout_sec",
            "policy_file",
            "auto_load_policy",
            "vector_memory_file",
            "desktop_state_file",
        ]
        return {"ok": True, "config": cfg_dict, "editable_fields": editable}

    def apply_runtime_config_update(self, updates: Dict[str, Any]) -> Dict[str, Any]:
        editable_types: Dict[str, Any] = {
            "llm_provider": str,
            "model": str,
            "ollama_url": str,
            "openai_base_url": str,
            "openai_api_key_env": str,
            "openai_api_key": str,
            "openai_timeout_sec": int,
            "openai_max_tokens": int,
            "brain_routing_enabled": bool,
            "brain_routing_simple_provider": str,
            "brain_routing_complex_provider": str,
            "brain_routing_sensitive_provider": str,
            "brain_routing_allow_api_for_sensitive": bool,
            "enable_shortcut_execution": bool,
            "require_approval_for_shortcuts": bool,
            "shortcut_execution_dry_run": bool,
            "shortcut_execution_method": str,
            "shortcut_execution_delay_ms": int,
            "min_desktop_confidence_for_shortcut": float,
            "allow_shortcut_without_desktop_state": bool,
            "reflex_enabled": bool,
            "reflex_auto_execute_trusted": bool,
            "reflex_trust_threshold": float,
            "reflex_require_approval_for_confirm": bool,
            "skills_file": str,
            "intents_file": str,
            "event_journal_dir": str,
            "distillation_dir": str,
            "temperature": float,
            "num_ctx": int,
            "max_steps": int,
            "max_file_read_chars": int,
            "max_tree_entries": int,
            "command_timeout_sec": int,
            "require_approval_for_writes": bool,
            "require_approval_for_commands": bool,
            "create_backups": bool,
            "mask_secrets": bool,
            "mask_secrets_in_memory": bool,
            "block_sensitive_file_reads": bool,
            "approval_timeout_sec": int,
            "policy_file": str,
            "auto_load_policy": bool,
            "vector_memory_file": str,
            "desktop_state_file": str,
        }
        clean: Dict[str, Any] = {}
        for key, caster in editable_types.items():
            if key not in updates:
                continue
            value = updates[key]
            if caster is bool:
                clean[key] = bool(value)
            elif caster is int:
                clean[key] = int(value)
            elif caster is float:
                clean[key] = float(value)
            else:
                clean[key] = str(value)

        if not clean:
            return {"ok": False, "error": "no editable config fields provided"}

        candidate = dataclasses.replace(self.cfg, **clean)
        # Validate the fields that can affect runtime safety/stability.
        if candidate.llm_provider not in {"ollama", "openai_compatible", "auto"}:
            return {"ok": False, "error": "llm_provider must be 'ollama', 'openai_compatible', or 'auto'"}
        for provider_field in (candidate.brain_routing_simple_provider, candidate.brain_routing_complex_provider, candidate.brain_routing_sensitive_provider):
            if provider_field not in {"ollama", "openai_compatible"}:
                return {"ok": False, "error": "brain routing providers must be 'ollama' or 'openai_compatible'"}
        if not (0 <= candidate.temperature <= 2):
            return {"ok": False, "error": "temperature must be between 0 and 2"}
        if candidate.num_ctx <= 0:
            return {"ok": False, "error": "num_ctx must be positive"}
        if candidate.max_steps <= 0:
            return {"ok": False, "error": "max_steps must be positive"}
        if candidate.command_timeout_sec <= 0:
            return {"ok": False, "error": "command_timeout_sec must be positive"}
        if candidate.shortcut_execution_delay_ms < 0:
            return {"ok": False, "error": "shortcut_execution_delay_ms cannot be negative"}
        if not (0 <= candidate.min_desktop_confidence_for_shortcut <= 1):
            return {"ok": False, "error": "min_desktop_confidence_for_shortcut must be between 0 and 1"}
        if not (0 <= candidate.reflex_trust_threshold <= 1):
            return {"ok": False, "error": "reflex_trust_threshold must be between 0 and 1"}
        if candidate.openai_timeout_sec <= 0:
            return {"ok": False, "error": "openai_timeout_sec must be positive"}
        if candidate.openai_max_tokens < 0:
            return {"ok": False, "error": "openai_max_tokens cannot be negative"}
        if candidate.max_file_read_chars <= 100:
            return {"ok": False, "error": "max_file_read_chars is too small"}
        if candidate.approval_timeout_sec < 0:
            return {"ok": False, "error": "approval_timeout_sec cannot be negative"}
        policy_path: Optional[Path] = None
        vector_path: Optional[Path] = None
        desktop_state_path: Optional[Path] = None
        skills_path: Optional[Path] = None
        intents_path: Optional[Path] = None
        events_dir: Optional[Path] = None
        distillation_dir: Optional[Path] = None
        if self.admin is not None and (candidate.policy_file != self.cfg.policy_file or candidate.auto_load_policy != self.cfg.auto_load_policy):
            policy_path = (self.root / candidate.policy_file).resolve()
            try:
                policy_path.relative_to(self.root)
            except ValueError:
                return {"ok": False, "error": "policy_file must stay inside the workspace root"}
        if candidate.vector_memory_file != self.cfg.vector_memory_file:
            vector_path = (self.root / candidate.vector_memory_file).resolve()
            try:
                vector_path.relative_to(self.root)
            except ValueError:
                return {"ok": False, "error": "vector_memory_file must stay inside the workspace root"}
        if candidate.desktop_state_file != self.cfg.desktop_state_file:
            desktop_state_path = (self.root / candidate.desktop_state_file).resolve()
            try:
                desktop_state_path.relative_to(self.root)
            except ValueError:
                return {"ok": False, "error": "desktop_state_file must stay inside the workspace root"}
        if candidate.skills_file != self.cfg.skills_file:
            skills_path = (self.root / candidate.skills_file).resolve()
            try:
                skills_path.relative_to(self.root)
            except ValueError:
                return {"ok": False, "error": "skills_file must stay inside the workspace root"}
        if candidate.intents_file != self.cfg.intents_file:
            intents_path = (self.root / candidate.intents_file).resolve()
            try:
                intents_path.relative_to(self.root)
            except ValueError:
                return {"ok": False, "error": "intents_file must stay inside the workspace root"}
        if candidate.event_journal_dir != self.cfg.event_journal_dir:
            events_dir = (self.root / candidate.event_journal_dir).resolve()
            try:
                events_dir.relative_to(self.root)
            except ValueError:
                return {"ok": False, "error": "event_journal_dir must stay inside the workspace root"}
        if candidate.distillation_dir != self.cfg.distillation_dir:
            distillation_dir = (self.root / candidate.distillation_dir).resolve()
            try:
                distillation_dir.relative_to(self.root)
            except ValueError:
                return {"ok": False, "error": "distillation_dir must stay inside the workspace root"}

        old = self.cfg
        self.cfg = candidate
        # Recreate the brain client so provider/base_url/API-key/model changes apply immediately.
        self.llm = self._create_llm_client(candidate)
        self.tools.cfg = candidate
        self.indexer.cfg = candidate
        self.memory.mask_secrets_enabled = candidate.mask_secrets_in_memory
        if vector_path is not None:
            self.vector_store = VectorMemoryStore(vector_path, dimensions=candidate.vector_dimensions)
            self.tools.vector_store = self.vector_store
        if desktop_state_path is not None:
            self.desktop_io = DesktopIORegistry(self.root, state_path=desktop_state_path)
            self._seed_foundation_shortcuts()
            self.tools.desktop_io = self.desktop_io
        if skills_path is not None:
            self.skill_registry = SkillRegistry(skills_path)
            self.reflex = ReflexEngine(self.intent_registry, self.skill_registry, self.event_journal)
        if intents_path is not None:
            self.intent_registry = IntentRegistry(intents_path)
            self.reflex = ReflexEngine(self.intent_registry, self.skill_registry, self.event_journal)
        if events_dir is not None:
            self.event_journal = EventJournal(events_dir)
            self.reflex = ReflexEngine(self.intent_registry, self.skill_registry, self.event_journal)
            self.daily_distiller = DailyDistiller(self.event_journal, self.skill_registry, Path(self.root / candidate.distillation_dir).resolve())
        if distillation_dir is not None:
            self.daily_distiller = DailyDistiller(self.event_journal, self.skill_registry, distillation_dir)
        if self.admin is not None:
            self.admin.approval_timeout_sec = candidate.approval_timeout_sec
            if policy_path is not None:
                self.admin.set_policy_storage(policy_path, auto_load=candidate.auto_load_policy)
        return {
            "ok": True,
            "updated": clean,
            "old_model": old.model,
            "new_model": candidate.model,
            "note": "Runtime updated. If you want persistence, mirror these values into config.json.",
        }

    def build_context(self) -> str:
        recent_memories = self.memory.recent(limit=6)
        memories_text = "\n".join(
            f"- [{m['kind']}] {truncate(m['text'], 500)}" for m in recent_memories
        ) or "[no memories yet]"
        index_summary = json.dumps(self.indexer.summary(), ensure_ascii=False)
        git_status = self.tools.git_status_for_context()
        return textwrap.dedent(
            f"""
            Local time: {now_local()}
            Workspace root: {self.root}

            Git status snapshot:
            {git_status}

            Project index summary:
            {index_summary}

            Project tree snapshot:
            {self.tools.project_tree()}

            Recent memories:
            {memories_text}
            """
        ).strip()

    def run_task(self, user_task: str, task_id: Optional[str] = None) -> str:
        with self.run_lock:
            self.total_tasks += 1
            self.current_task = user_task
            self.current_task_id = task_id
            self.task_running = True
            self.last_error = None
            if task_id:
                with self.task_lock:
                    rec = self.tasks.get(task_id)
                    if rec:
                        rec["status"] = "running"
                        rec["started_at"] = now_local()
                        rec["updated_at"] = now_local()
            if self.admin is not None:
                self.admin.emit("task.started", "Task started", {"task": truncate(user_task, 1500), "task_no": self.total_tasks, "task_id": task_id})

            try:
                self._wait_if_paused_or_cancelled(task_id)
                safe_user_task = mask_secrets(user_task) if self.cfg.mask_secrets else user_task
                language_profile = detect_text_profile(safe_user_task).to_dict()
                self.memory.add("user_task", safe_user_task, {"time": now_local(), "task_id": task_id, "language_profile": language_profile})
                messages: List[Dict[str, str]] = [
                    {"role": "system", "content": SYSTEM_PROMPT},
                    {"role": "user", "content": self.build_context() + "\n\nUser task language profile:\n" + json.dumps(language_profile, ensure_ascii=False) + "\n\nUser task:\n" + safe_user_task},
                ]
                selected_llm, brain_route = self._select_brain(safe_user_task)
                self.last_brain_route = brain_route
                if task_id:
                    with self.task_lock:
                        rec = self.tasks.get(task_id)
                        if rec:
                            rec["brain_route"] = brain_route
                            rec["updated_at"] = now_local()
                if self.admin is not None:
                    self.admin.emit("brain.selected", "Brain selected for task", {"task_id": task_id, "brain_route": brain_route})

                final_answer = ""
                step = 1
                while step <= self.cfg.max_steps:
                    self._wait_if_paused_or_cancelled(task_id)
                    print(f"\n[agent] step {step}/{self.cfg.max_steps} - thinking with {selected_llm.model} via {brain_route.get('provider')}...")
                    if self.admin is not None:
                        self.admin.emit("agent.thinking", "LLM call started", {"step": step, "max_steps": self.cfg.max_steps, "model": selected_llm.model, "task_id": task_id, "brain_route": brain_route})
                    raw = selected_llm.chat(messages)
                    self._wait_if_paused_or_cancelled(task_id)
                    print("[agent] raw model output:")
                    safe_raw_for_display = mask_secrets(raw) if self.cfg.mask_secrets else raw
                    print(truncate(safe_raw_for_display, 3000))
                    try:
                        obj = extract_json_object(raw)
                    except Exception as e:
                        err = f"Invalid JSON from model: {e}"
                        print(f"[agent] {err}")
                        if self.admin is not None:
                            self.admin.emit("agent.invalid_json", err, {"raw": truncate(safe_raw_for_display, 2000), "task_id": task_id}, level="warning")
                        messages.append({"role": "assistant", "content": safe_raw_for_display})
                        messages.append({"role": "user", "content": "Your previous output was not valid JSON. Return ONLY the required JSON object."})
                        step += 1
                        continue

                    actions = obj.get("actions") or []
                    if not isinstance(actions, list):
                        messages.append({"role": "user", "content": "actions must be a list. Return valid JSON."})
                        step += 1
                        continue
                    if not actions:
                        safe_obj_for_context = sanitize_for_display(obj, max_string=8000) if self.cfg.mask_secrets else obj
                        messages.append({"role": "assistant", "content": json.dumps(safe_obj_for_context, ensure_ascii=False)})
                        messages.append({"role": "user", "content": "No actions were provided. Use finish(answer) or a tool action."})
                        step += 1
                        continue

                    observations = []
                    for action in actions:
                        self._wait_if_paused_or_cancelled(task_id)
                        if not isinstance(action, dict):
                            observations.append({"ok": False, "error": "action is not object", "action": action})
                            continue
                        tool = action.get("tool")
                        safe_args = sanitize_for_display(action.get('args') or {}, max_string=500) if self.cfg.mask_secrets else (action.get('args') or {})
                        print(f"[tool] {tool} {json.dumps(safe_args, ensure_ascii=False)[:500]}")
                        result = self.tools.execute(action)
                        safe_action_for_obs = sanitize_for_display(action, max_string=4000) if self.cfg.mask_secrets else action
                        safe_result_for_obs = sanitize_for_display(result, max_string=8000) if self.cfg.mask_secrets else result
                        observations.append({"action": safe_action_for_obs, "result": safe_result_for_obs})
                        if tool == "finish" and result.get("ok"):
                            final_answer = result.get("final", "")
                            self.memory.add("assistant_final", final_answer, {"time": now_local(), "task_id": task_id})
                            if self.admin is not None:
                                self.admin.emit("task.finished", "Task finished", {"answer": truncate(final_answer, 2000), "task_id": task_id}, level="info")
                            return final_answer

                    obs_text = json.dumps(observations, ensure_ascii=False, indent=2)
                    print("[agent] observations:")
                    print(truncate(obs_text, 5000))
                    safe_obj_for_context = sanitize_for_display(obj, max_string=8000) if self.cfg.mask_secrets else obj
                    messages.append({"role": "assistant", "content": json.dumps(safe_obj_for_context, ensure_ascii=False)})
                    messages.append({"role": "user", "content": "Tool observations:\n" + truncate(obs_text, 20_000) + "\n\nContinue. Return ONLY JSON."})
                    step += 1

                final_answer = "به سقف مراحل رسیدم. اگر لازم است، دوباره با دستور دقیق‌تر ادامه بده."
                self.memory.add("assistant_final", final_answer, {"time": now_local(), "max_steps_reached": True, "task_id": task_id})
                if self.admin is not None:
                    self.admin.emit("task.max_steps", "Task reached max steps", {"answer": final_answer, "task_id": task_id}, level="warning")
                return final_answer
            except Exception as e:
                self.last_error = str(e)
                if self.admin is not None:
                    level = "warning" if "cancelled" in str(e).lower() else "error"
                    self.admin.emit("task.error", "Task failed", {"error": str(e), "task_id": task_id, "traceback": traceback.format_exc(limit=3)}, level=level)
                raise
            finally:
                self.task_running = False
                self.current_task = None
                self.current_task_id = None


# -----------------------------
# CLI helpers
# -----------------------------


def handle_slash_command(agent: LocalCodingAgent, command: str) -> bool:
    parts = command.strip().split(maxsplit=1)
    cmd = parts[0].lower()
    arg = parts[1] if len(parts) > 1 else ""

    if cmd in {"/help", "/?"}:
        print(
            textwrap.dedent(
                """
                Local commands:
                  /help              show this help
                  /index             rebuild project index
                  /status            show git status
                  /diff [path]        show git diff, optionally for one path
                  /search QUERY       search project index without LLM
                  /memory QUERY       search memory without LLM
                  /summary           show project index summary
                  /dashboard         show admin dashboard URL
                  exit                quit
                """
            ).strip()
        )
        return True

    if cmd == "/index":
        print(json.dumps(agent.indexer.rebuild(), ensure_ascii=False, indent=2))
        return True

    if cmd == "/summary":
        print(json.dumps(agent.indexer.summary(), ensure_ascii=False, indent=2))
        return True

    if cmd == "/status":
        print(json.dumps(agent.tools.git_status(), ensure_ascii=False, indent=2))
        return True

    if cmd == "/diff":
        print(json.dumps(agent.tools.git_diff(path=arg), ensure_ascii=False, indent=2))
        return True

    if cmd == "/search":
        if not arg:
            print("Usage: /search QUERY")
        else:
            print(json.dumps(agent.indexer.search(arg), ensure_ascii=False, indent=2))
        return True

    if cmd == "/memory":
        if not arg:
            print("Usage: /memory QUERY")
        else:
            print(json.dumps(agent.memory.search(arg), ensure_ascii=False, indent=2))
        return True

    if cmd == "/dashboard":
        if agent.admin is not None:
            print(agent.admin.server_url or "dashboard enabled but URL is not available")
        else:
            print("dashboard is disabled. Set enable_dashboard=true in config.json")
        return True

    return False


# -----------------------------
# CLI
# -----------------------------


def main() -> int:
    parser = argparse.ArgumentParser(description="SkyGround Local Cursor-like Coding Agent with Ollama")
    parser.add_argument("--config", default="config.json", help="Path to config JSON")
    parser.add_argument("--root", default=None, help="Workspace/project root")
    parser.add_argument("--task", default=None, help="Run one task and exit")
    parser.add_argument("--index", action="store_true", help="Rebuild project index before starting")
    args = parser.parse_args()

    cfg = AgentConfig.load(args.config, root_override=args.root)
    agent = LocalCodingAgent(cfg)

    if args.index:
        print(json.dumps(agent.indexer.rebuild(), ensure_ascii=False, indent=2))

    print("=" * 72)
    print("SkyGround Local Coding Agent v3")
    print(f"Workspace: {agent.root}")
    print(f"Model: {cfg.model}")
    print(f"Ollama: {cfg.ollama_url}")
    if agent.admin is not None:
        print(f"Dashboard: {agent.admin.server_url}")
        if cfg.dashboard_token:
            print("Dashboard auth: enabled (use your dashboard_token to login)")
    print("Type '/help' for local commands, or 'exit' to quit.")
    print("=" * 72)

    if args.task:
        answer = agent.run_task(args.task)
        print("\n--- Final ---")
        print(mask_secrets(answer) if cfg.mask_secrets else answer)
        return 0

    while True:
        try:
            task = input("\nYou> ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nbye")
            return 0
        if not task:
            continue
        if task.lower() in {"exit", "quit", "خروج"}:
            print("bye")
            return 0
        if task.startswith("/") and handle_slash_command(agent, task):
            continue
        try:
            answer = agent.run_task(task)
            print("\nAgent>")
            print(mask_secrets(answer) if cfg.mask_secrets else answer)
        except Exception as e:
            print("\n[error]", e)
            traceback.print_exc()


if __name__ == "__main__":
    raise SystemExit(main())
```


## `dashboard.py`

```python
"""
Dashboard and admin supervision layer for SkyGround Local Coding Agent.

Dependency-free implementation based on Python standard library:
- ThreadingHTTPServer
- Polling JSON API
- Dark-mode single-page dashboard

The dashboard provides:
- Live status/events
- Approval queue for writes/commands
- Ask-admin queue for questions
- Runtime config updates
- Session permissions / access grants
"""

from __future__ import annotations

import dataclasses
import datetime as dt
import fnmatch
import html
import json
import threading
import time
import traceback
import urllib.error
import urllib.parse
import urllib.request
import uuid
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional
from urllib.parse import parse_qs, urlparse

from security import mask_secrets as shared_mask_secrets, sanitize_for_display as shared_sanitize_for_display


JsonDict = Dict[str, Any]


def utc_now() -> str:
    return dt.datetime.now(dt.timezone.utc).isoformat()


def local_now() -> str:
    return dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def shorten(value: Any, limit: int = 6000) -> Any:
    """Keep dashboard payloads reasonably small."""
    if isinstance(value, str):
        if len(value) > limit:
            return value[:limit] + f"\n... [truncated {len(value) - limit} chars]"
        return value
    if isinstance(value, list):
        return [shorten(v, limit=limit) for v in value[:200]]
    if isinstance(value, dict):
        return {str(k): shorten(v, limit=limit) for k, v in value.items()}
    return value


def normalize_list(value: Any) -> List[str]:
    """Accept list or textarea string and return clean policy entries."""
    if value is None:
        return []
    if isinstance(value, list):
        raw_items = value
    else:
        text = str(value).replace(",", "\n")
        raw_items = text.splitlines()
    items: List[str] = []
    for item in raw_items:
        s = str(item).strip()
        if not s or s.startswith("#"):
            continue
        items.append(s)
    return items


def match_any(text: str, patterns: List[str]) -> bool:
    """Case-insensitive fnmatch against a normalized text value."""
    if not patterns:
        return False
    value = text.replace("\\", "/").lower()
    for pattern in patterns:
        p = pattern.replace("\\", "/").lower()
        if fnmatch.fnmatch(value, p):
            return True
    return False


def contains_any(text: str, fragments: List[str]) -> bool:
    value = text.lower()
    return any(fragment.lower() in value for fragment in fragments if fragment)


def mask_secrets(text: str, keep: int = 4) -> str:
    """Best-effort masking for tokens/keys in URLs, headers, logs, and config snippets."""
    if not text:
        return text
    masked = text
    masked = re_sub_secret(r"(?i)(api[_-]?key|token|access[_-]?token|auth|authorization|secret|password)(=|:)([^&\s,}]+)", masked, keep=keep)
    masked = re_sub_secret(r"(?i)(bearer\s+)([A-Za-z0-9._\-]{12,})", masked, keep=keep, group=2)
    return masked


def re_sub_secret(pattern: str, text: str, keep: int = 4, group: int = 3) -> str:
    import re

    def repl(match: Any) -> str:
        value = match.group(group)
        if len(value) <= keep:
            replacement = "****"
        else:
            replacement = value[:keep] + "****"
        parts = list(match.groups())
        parts[group - 1] = replacement
        return "".join(parts)

    return re.sub(pattern, repl, text)


@dataclasses.dataclass
class ApprovalRequest:
    id: str
    kind: str
    title: str
    details: JsonDict
    created_at: str
    status: str = "pending"  # pending | approved | rejected | expired
    decided_at: Optional[str] = None
    decision_reason: str = ""


@dataclasses.dataclass
class AdminQuestion:
    id: str
    question: str
    options: List[str]
    created_at: str
    status: str = "pending"  # pending | answered | expired
    answer: str = ""
    answered_at: Optional[str] = None


def default_permissions() -> JsonDict:
    return {
        "read_only_mode": False,
        "auto_approve_writes": False,
        "auto_approve_commands": False,
        "auto_answer_questions": False,
        "auto_question_answer": "",

        # Granular session policy. Empty allowlists mean "any" when auto-approve is enabled.
        # Denylists always win.
        "allowed_write_globs": [],
        "denied_write_globs": [],
        "reject_unmatched_writes": False,
        "allowed_command_globs": [],
        "denied_command_fragments": [],
        "reject_unmatched_commands": False,
    }


COMMON_DENIED_COMMAND_FRAGMENTS = [
    "rm -rf",
    "del /s",
    "rmdir /s",
    "format ",
    "mkfs",
    "shutdown",
    "reboot",
    "reg delete",
    "Remove-Item -Recurse -Force",
]


POLICY_TEMPLATES: Dict[str, JsonDict] = {
    "cautious_manual": {
        "label": "Cautious Manual",
        "description": "حالت پیش‌فرض امن: همه write/commandها approval دستی می‌خواهند، با deny-list پایه.",
        "permissions": {
            "read_only_mode": False,
            "auto_approve_writes": False,
            "auto_approve_commands": False,
            "denied_write_globs": [".env", "*.pem", "*.key", "**/secrets/**", "**/.env*"],
            "denied_command_fragments": COMMON_DENIED_COMMAND_FRAGMENTS,
        },
    },
    "read_only_review": {
        "label": "Read-only Review",
        "description": "فقط بررسی و خواندن؛ همه write/edit/commandها reject می‌شوند.",
        "permissions": {
            "read_only_mode": True,
            "auto_approve_writes": False,
            "auto_approve_commands": False,
            "reject_unmatched_writes": True,
            "reject_unmatched_commands": True,
            "denied_command_fragments": COMMON_DENIED_COMMAND_FRAGMENTS,
        },
    },
    "safe_python": {
        "label": "Safe Python",
        "description": "مناسب پروژه Python: اجرای خودکار تست/لینت امن؛ ویرایش‌ها همچنان approval می‌خواهند.",
        "permissions": {
            "read_only_mode": False,
            "auto_approve_writes": False,
            "auto_approve_commands": True,
            "allowed_write_globs": ["src/**", "tests/**", "*.py", "pyproject.toml", "README.md", "docs/**"],
            "denied_write_globs": [".env", "*.pem", "*.key", "**/secrets/**", "**/.env*"],
            "allowed_command_globs": [
                "python -m pytest*",
                "pytest*",
                "python -m unittest*",
                "python -m ruff check*",
                "ruff check*",
                "python -m mypy*",
                "mypy*",
            ],
            "denied_command_fragments": COMMON_DENIED_COMMAND_FRAGMENTS,
            "reject_unmatched_commands": True,
        },
    },
    "safe_node": {
        "label": "Safe Node",
        "description": "مناسب پروژه Node/Frontend: اجرای خودکار test/build/lint؛ ویرایش‌ها approval می‌خواهند.",
        "permissions": {
            "read_only_mode": False,
            "auto_approve_writes": False,
            "auto_approve_commands": True,
            "allowed_write_globs": ["src/**", "tests/**", "test/**", "app/**", "components/**", "README.md", "docs/**"],
            "denied_write_globs": [".env", ".env.*", "*.pem", "*.key", "**/secrets/**"],
            "allowed_command_globs": [
                "npm test*",
                "npm run test*",
                "npm run build*",
                "npm run lint*",
                "pnpm test*",
                "pnpm run test*",
                "pnpm run build*",
                "pnpm run lint*",
                "yarn test*",
                "yarn build*",
                "yarn lint*",
            ],
            "denied_command_fragments": COMMON_DENIED_COMMAND_FRAGMENTS,
            "reject_unmatched_commands": True,
        },
    },
    "docs_only": {
        "label": "Docs Only",
        "description": "فقط مستندات auto-approve می‌شوند؛ commandها approval دستی می‌خواهند.",
        "permissions": {
            "read_only_mode": False,
            "auto_approve_writes": True,
            "auto_approve_commands": False,
            "allowed_write_globs": ["README.md", "docs/**", "*.md", "**/*.md"],
            "denied_write_globs": [".env", "*.pem", "*.key", "**/secrets/**"],
            "reject_unmatched_writes": True,
            "denied_command_fragments": COMMON_DENIED_COMMAND_FRAGMENTS,
        },
    },
    "src_tests_dev": {
        "label": "Src + Tests Development",
        "description": "ویرایش خودکار فقط در src/tests و اجرای خودکار تست‌های رایج.",
        "permissions": {
            "read_only_mode": False,
            "auto_approve_writes": True,
            "auto_approve_commands": True,
            "allowed_write_globs": ["src/**", "tests/**", "test/**"],
            "denied_write_globs": [".env", ".env.*", "*.pem", "*.key", "**/secrets/**"],
            "reject_unmatched_writes": True,
            "allowed_command_globs": ["python -m pytest*", "pytest*", "npm test*", "npm run test*", "npm run build*", "npm run lint*"],
            "denied_command_fragments": COMMON_DENIED_COMMAND_FRAGMENTS,
            "reject_unmatched_commands": True,
        },
    },
}


class AdminControlCenter:
    """Shared control plane between the agent runtime and dashboard HTTP API."""

    def __init__(self, approval_timeout_sec: int = 0):
        self.approval_timeout_sec = approval_timeout_sec
        self.lock = threading.RLock()
        self.condition = threading.Condition(self.lock)
        self.approvals: Dict[str, ApprovalRequest] = {}
        self.questions: Dict[str, AdminQuestion] = {}
        self.events: List[JsonDict] = []
        self.max_events = 1000
        self.server_url: Optional[str] = None
        self.dashboard_enabled = False
        self.status_provider: Optional[Callable[[], JsonDict]] = None
        self.config_getter: Optional[Callable[[], JsonDict]] = None
        self.config_updater: Optional[Callable[[JsonDict], JsonDict]] = None
        self.task_submitter: Optional[Callable[[str, str], JsonDict]] = None
        self.task_getter: Optional[Callable[[], JsonDict]] = None
        self.task_controller: Optional[Callable[[str, Optional[str]], JsonDict]] = None
        self.agent_ops_handler: Optional[Callable[[str, JsonDict], JsonDict]] = None
        self.emergency_stop_active = False
        self.policy_path: Optional[Path] = None
        self.policy_last_loaded_at: Optional[str] = None
        self.policy_last_saved_at: Optional[str] = None

        # Session-level admin grants/policies. They can optionally be persisted by dashboard action.
        self.permissions: JsonDict = default_permissions()

    # ---------- integration callbacks ----------

    def set_status_provider(self, fn: Callable[[], JsonDict]) -> None:
        self.status_provider = fn

    def set_config_callbacks(self, getter: Callable[[], JsonDict], updater: Callable[[JsonDict], JsonDict]) -> None:
        self.config_getter = getter
        self.config_updater = updater

    def set_task_callbacks(
        self,
        submitter: Callable[[str, str], JsonDict],
        getter: Callable[[], JsonDict],
        controller: Callable[[str, Optional[str]], JsonDict],
    ) -> None:
        self.task_submitter = submitter
        self.task_getter = getter
        self.task_controller = controller

    def set_agent_ops_handler(self, handler: Callable[[str, JsonDict], JsonDict]) -> None:
        self.agent_ops_handler = handler

    def set_server_url(self, url: str) -> None:
        with self.lock:
            self.server_url = url
            self.dashboard_enabled = True
        self.emit("dashboard.started", "Dashboard started", {"url": url})

    def set_policy_storage(self, path: Path, auto_load: bool = True) -> None:
        self.policy_path = Path(path)
        if auto_load and self.policy_path.exists():
            self.load_policy_from_disk()
        else:
            self.emit("policy.storage", "Policy storage configured", {"path": str(self.policy_path), "exists": self.policy_path.exists()})

    def get_policy_templates(self) -> List[JsonDict]:
        return [
            {
                "id": template_id,
                "label": data.get("label", template_id),
                "description": data.get("description", ""),
                "permissions": data.get("permissions", {}),
            }
            for template_id, data in POLICY_TEMPLATES.items()
        ]

    # ---------- events ----------

    def emit(self, event_type: str, message: str, data: Optional[JsonDict] = None, level: str = "info") -> None:
        safe_message = shared_mask_secrets(message)
        safe_data = shared_sanitize_for_display(data or {}, max_string=4000)
        event = {
            "id": str(uuid.uuid4()),
            "time": local_now(),
            "utc": utc_now(),
            "type": event_type,
            "level": level,
            "message": safe_message,
            "data": shorten(safe_data, limit=4000),
        }
        with self.lock:
            self.events.append(event)
            if len(self.events) > self.max_events:
                self.events = self.events[-self.max_events :]
            self.condition.notify_all()

    def get_events(self, limit: int = 200) -> List[JsonDict]:
        with self.lock:
            return list(self.events[-limit:])

    # ---------- granular policy ----------

    def _approval_paths(self, details: JsonDict) -> List[str]:
        paths: List[str] = []
        raw_paths = details.get("paths")
        if isinstance(raw_paths, list):
            paths.extend(str(p).replace("\\", "/") for p in raw_paths if str(p).strip())
        raw_path = details.get("path")
        if raw_path:
            paths.append(str(raw_path).replace("\\", "/"))
        return list(dict.fromkeys(paths))

    def _evaluate_policy(self, kind: str, title: str, details: JsonDict) -> JsonDict:
        """Return {action: ask|auto_approve|reject, reason, ...}. Denylists always win."""
        perms = self.permissions
        if perms.get("read_only_mode") and kind in {"write", "edit", "command", "shortcut"}:
            return {"action": "reject", "reason": "read_only_mode is enabled"}

        if kind in {"write", "edit"}:
            paths = self._approval_paths(details)
            allowed = normalize_list(perms.get("allowed_write_globs"))
            denied = normalize_list(perms.get("denied_write_globs"))
            denied_paths = [p for p in paths if match_any(p, denied)]
            if denied_paths:
                return {"action": "reject", "reason": "path denied by policy", "paths": denied_paths}

            unmatched = [p for p in paths if allowed and not match_any(p, allowed)]
            if unmatched and perms.get("reject_unmatched_writes"):
                return {"action": "reject", "reason": "path not in allowed_write_globs", "paths": unmatched}

            if perms.get("auto_approve_writes"):
                if allowed and unmatched:
                    return {"action": "ask", "reason": "auto-write enabled, but some paths are outside allowlist", "paths": unmatched}
                return {"action": "auto_approve", "reason": "auto_approve_writes policy matched", "paths": paths}

            return {"action": "ask", "reason": "manual approval required", "paths": paths}

        if kind == "command":
            command = str(details.get("command") or title)
            allowed_cmds = normalize_list(perms.get("allowed_command_globs"))
            denied_fragments = normalize_list(perms.get("denied_command_fragments"))
            if contains_any(command, denied_fragments):
                return {"action": "reject", "reason": "command contains denied fragment", "command": command}

            matched_allowed = (not allowed_cmds) or match_any(command, allowed_cmds)
            if not matched_allowed and perms.get("reject_unmatched_commands"):
                return {"action": "reject", "reason": "command not in allowed_command_globs", "command": command}

            if perms.get("auto_approve_commands"):
                if not matched_allowed:
                    return {"action": "ask", "reason": "auto-command enabled, but command is outside allowlist", "command": command}
                return {"action": "auto_approve", "reason": "auto_approve_commands policy matched", "command": command}

            return {"action": "ask", "reason": "manual approval required", "command": command}

        return {"action": "ask", "reason": "manual approval required"}

    # ---------- approvals ----------

    def request_approval(
        self,
        kind: str,
        title: str,
        details: JsonDict,
        console_fallback: Optional[Callable[[], bool]] = None,
        timeout_sec: Optional[int] = None,
    ) -> bool:
        """Create an approval request and wait for admin decision.

        If dashboard is not enabled, falls back to console_fallback when available.
        """
        with self.lock:
            if self.emergency_stop_active:
                self.emit(
                    "approval.emergency_rejected",
                    f"Rejected by emergency stop: {title}",
                    {"kind": kind, "details": details},
                    level="error",
                )
                return False
            policy = self._evaluate_policy(kind, title, details)
            if policy.get("action") == "reject":
                self.emit(
                    "approval.policy_rejected",
                    f"Rejected by policy: {title}",
                    {"kind": kind, "reason": policy.get("reason"), "policy": policy, "details": details},
                    level="warning",
                )
                return False
            if policy.get("action") == "auto_approve":
                self.emit(
                    "approval.policy_auto_approved",
                    f"Auto-approved by policy: {title}",
                    {"kind": kind, "reason": policy.get("reason"), "policy": policy, "details": details},
                )
                return True
            dashboard_enabled = self.dashboard_enabled
            server_url = self.server_url

        if not dashboard_enabled:
            if console_fallback is not None:
                return bool(console_fallback())
            return False

        req_id = str(uuid.uuid4())
        request_details = dict(details)
        request_details["policy"] = policy
        req = ApprovalRequest(
            id=req_id,
            kind=kind,
            title=shared_mask_secrets(title),
            details=shorten(shared_sanitize_for_display(request_details, max_string=8000), limit=8000),
            created_at=local_now(),
        )
        with self.condition:
            self.approvals[req_id] = req
            self.emit("approval.requested", title, {"approval_id": req_id, "kind": kind, "details": details})
            self.condition.notify_all()

            print("\n[admin approval required]")
            print(f"Open dashboard: {server_url}")
            print(f"Approval: {title}")

            timeout = self.approval_timeout_sec if timeout_sec is None else timeout_sec
            deadline = None if not timeout or timeout <= 0 else time.time() + timeout
            while req.status == "pending":
                remaining = None if deadline is None else max(0.0, deadline - time.time())
                if deadline is not None and remaining <= 0:
                    req.status = "expired"
                    req.decided_at = local_now()
                    self.emit("approval.expired", title, {"approval_id": req_id}, level="warning")
                    self.condition.notify_all()
                    return False
                self.condition.wait(timeout=remaining if remaining is not None else 1.0)

            approved = req.status == "approved"
            self.emit(
                "approval.decided",
                f"{'Approved' if approved else 'Rejected'}: {title}",
                {"approval_id": req_id, "status": req.status, "reason": req.decision_reason},
                level="info" if approved else "warning",
            )
            return approved

    def decide_approval(self, approval_id: str, approved: bool, reason: str = "") -> JsonDict:
        with self.condition:
            req = self.approvals.get(approval_id)
            if not req:
                return {"ok": False, "error": "approval not found"}
            if req.status != "pending":
                return {"ok": False, "error": f"approval already {req.status}"}
            req.status = "approved" if approved else "rejected"
            req.decided_at = local_now()
            req.decision_reason = reason
            self.condition.notify_all()
            return {"ok": True, "approval": dataclasses.asdict(req)}

    # ---------- questions ----------

    def ask_admin(
        self,
        question: str,
        options: Optional[List[str]] = None,
        console_fallback: Optional[Callable[[], str]] = None,
        timeout_sec: int = 0,
    ) -> JsonDict:
        options = options or []
        with self.lock:
            if self.emergency_stop_active:
                self.emit("question.emergency_rejected", question, {}, level="error")
                return {"ok": False, "error": "emergency stop is active"}
            if self.permissions.get("auto_answer_questions"):
                answer = str(self.permissions.get("auto_question_answer") or "")
                self.emit("question.auto_answered", question, {"answer": answer})
                return {"ok": True, "answer": answer, "auto": True}
            dashboard_enabled = self.dashboard_enabled
            server_url = self.server_url

        if not dashboard_enabled:
            if console_fallback is not None:
                return {"ok": True, "answer": console_fallback(), "auto": False}
            return {"ok": False, "error": "dashboard disabled and no console fallback"}

        qid = str(uuid.uuid4())
        q = AdminQuestion(id=qid, question=question, options=options, created_at=local_now())
        with self.condition:
            self.questions[qid] = q
            self.emit("question.requested", question, {"question_id": qid, "options": options})
            self.condition.notify_all()

            print("\n[admin answer required]")
            print(f"Open dashboard: {server_url}")
            print(f"Question: {question}")

            deadline = None if timeout_sec <= 0 else time.time() + timeout_sec
            while q.status == "pending":
                remaining = None if deadline is None else max(0.0, deadline - time.time())
                if deadline is not None and remaining <= 0:
                    q.status = "expired"
                    q.answered_at = local_now()
                    self.emit("question.expired", question, {"question_id": qid}, level="warning")
                    self.condition.notify_all()
                    return {"ok": False, "error": "question expired", "question_id": qid}
                self.condition.wait(timeout=remaining if remaining is not None else 1.0)

            return {"ok": True, "answer": q.answer, "question_id": qid, "auto": False}

    def answer_question(self, question_id: str, answer: str) -> JsonDict:
        with self.condition:
            q = self.questions.get(question_id)
            if not q:
                return {"ok": False, "error": "question not found"}
            if q.status != "pending":
                return {"ok": False, "error": f"question already {q.status}"}
            q.status = "answered"
            q.answer = answer
            q.answered_at = local_now()
            self.emit("question.answered", q.question, {"question_id": question_id, "answer": answer})
            self.condition.notify_all()
            return {"ok": True, "question": dataclasses.asdict(q)}

    # ---------- permissions/config/state ----------

    def update_permissions(self, updates: JsonDict) -> JsonDict:
        allowed = set(self.permissions.keys())
        list_fields = {
            "allowed_write_globs",
            "denied_write_globs",
            "allowed_command_globs",
            "denied_command_fragments",
        }
        with self.lock:
            for k, v in updates.items():
                if k not in allowed:
                    continue
                if k in list_fields:
                    self.permissions[k] = normalize_list(v)
                elif isinstance(self.permissions[k], bool):
                    self.permissions[k] = bool(v)
                else:
                    self.permissions[k] = str(v)
            self.emit("permissions.updated", "Session permissions updated", {"permissions": self.permissions})
            return {"ok": True, "permissions": dict(self.permissions)}

    def apply_policy_template(self, template_id: str, merge: bool = False) -> JsonDict:
        template = POLICY_TEMPLATES.get(template_id)
        if not template:
            return {"ok": False, "error": f"unknown policy template: {template_id}"}
        template_perms = dict(template.get("permissions") or {})
        with self.lock:
            if not merge:
                self.permissions = default_permissions()
            result = self.update_permissions(template_perms)
            self.emit(
                "policy.template_applied",
                f"Policy template applied: {template.get('label', template_id)}",
                {"template_id": template_id, "merge": merge, "permissions": self.permissions},
            )
            return {"ok": True, "template_id": template_id, "merge": merge, "permissions": dict(self.permissions), "update_result": result}

    def save_policy_to_disk(self) -> JsonDict:
        if self.policy_path is None:
            return {"ok": False, "error": "policy storage path is not configured"}
        with self.lock:
            payload = {
                "version": 1,
                "saved_at": local_now(),
                "permissions": dict(self.permissions),
            }
            path = self.policy_path
            path.parent.mkdir(parents=True, exist_ok=True)
            backup_path: Optional[Path] = None
            if path.exists():
                stamp = dt.datetime.now().strftime("%Y%m%d-%H%M%S")
                backup_path = path.with_name(f"{path.name}.bak-{stamp}")
                backup_path.write_bytes(path.read_bytes())
            tmp = path.with_name(f".{path.name}.tmp-{uuid.uuid4().hex[:8]}")
            tmp.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
            tmp.replace(path)
            self.policy_last_saved_at = payload["saved_at"]
            self.emit(
                "policy.saved",
                "Policy saved to disk",
                {"path": str(path), "backup": str(backup_path) if backup_path else None, "permissions": self.permissions},
            )
            return {"ok": True, "path": str(path), "backup": str(backup_path) if backup_path else None, "saved_at": self.policy_last_saved_at}

    def load_policy_from_disk(self) -> JsonDict:
        if self.policy_path is None:
            return {"ok": False, "error": "policy storage path is not configured"}
        path = self.policy_path
        if not path.exists():
            return {"ok": False, "error": f"policy file does not exist: {path}"}
        try:
            obj = json.loads(path.read_text(encoding="utf-8"))
        except Exception as e:
            return {"ok": False, "error": f"failed to read policy file: {e}"}
        permissions = obj.get("permissions", obj) if isinstance(obj, dict) else {}
        if not isinstance(permissions, dict):
            return {"ok": False, "error": "policy file must contain an object or {permissions: object}"}
        with self.lock:
            self.permissions = default_permissions()
            result = self.update_permissions(permissions)
            self.policy_last_loaded_at = local_now()
            self.emit("policy.loaded", "Policy loaded from disk", {"path": str(path), "permissions": self.permissions})
            return {"ok": True, "path": str(path), "loaded_at": self.policy_last_loaded_at, "permissions": dict(self.permissions), "update_result": result}

    def reset_policy(self, delete_file: bool = False) -> JsonDict:
        with self.lock:
            self.permissions = default_permissions()
            deleted = False
            if delete_file and self.policy_path is not None and self.policy_path.exists():
                self.policy_path.unlink()
                deleted = True
            self.emit("policy.reset", "Session policy reset", {"delete_file": delete_file, "deleted": deleted})
            return {"ok": True, "permissions": dict(self.permissions), "deleted_file": deleted}

    # ---------- task control / emergency ----------

    def submit_task(self, task: str, source: str = "dashboard") -> JsonDict:
        if not self.task_submitter:
            return {"ok": False, "error": "task submitter not registered"}
        if self.emergency_stop_active:
            return {"ok": False, "error": "emergency stop is active"}
        result = self.task_submitter(task, source)
        self.emit("task.submitted_from_dashboard", "Task submitted", {"task": shorten(task, 1000), "result": result})
        return result

    def get_tasks(self) -> JsonDict:
        if not self.task_getter:
            return {"ok": True, "registered": False, "tasks": []}
        try:
            result = self.task_getter()
            result["registered"] = True
            return result
        except Exception as e:
            return {"ok": False, "registered": True, "error": str(e), "traceback": traceback.format_exc(limit=2)}

    def control_task(self, action: str, task_id: Optional[str] = None) -> JsonDict:
        if action == "emergency_stop":
            self.trigger_emergency_stop("dashboard")
        elif action == "clear_emergency_stop":
            self.clear_emergency_stop()
        if not self.task_controller:
            return {"ok": False, "error": "task controller not registered"}
        result = self.task_controller(action, task_id)
        self.emit("task.control", f"Task control: {action}", {"task_id": task_id, "result": result}, level="warning" if action == "emergency_stop" else "info")
        return result

    def agent_op(self, operation: str, payload: JsonDict) -> JsonDict:
        if not self.agent_ops_handler:
            return {"ok": False, "error": "agent operations handler not registered"}
        try:
            result = self.agent_ops_handler(operation, payload)
            self.emit("agent.op", f"Agent operation: {operation}", {"payload": payload, "result": result}, level="info" if result.get("ok") else "warning")
            return result
        except Exception as e:
            result = {"ok": False, "error": str(e), "traceback": traceback.format_exc(limit=2)}
            self.emit("agent.op.error", f"Agent operation failed: {operation}", result, level="error")
            return result

    def trigger_emergency_stop(self, source: str = "system") -> JsonDict:
        with self.condition:
            self.emergency_stop_active = True
            self.permissions = default_permissions()
            self.permissions["read_only_mode"] = True
            for req in self.approvals.values():
                if req.status == "pending":
                    req.status = "rejected"
                    req.decided_at = local_now()
                    req.decision_reason = "emergency stop"
            for q in self.questions.values():
                if q.status == "pending":
                    q.status = "expired"
                    q.answered_at = local_now()
                    q.answer = "emergency stop"
            self.emit("emergency_stop", "Emergency stop activated", {"source": source}, level="error")
            self.condition.notify_all()
            return {"ok": True, "emergency_stop_active": True, "permissions": dict(self.permissions)}

    def clear_emergency_stop(self) -> JsonDict:
        with self.condition:
            self.emergency_stop_active = False
            self.emit("emergency_stop.cleared", "Emergency stop cleared", {}, level="warning")
            self.condition.notify_all()
            return {"ok": True, "emergency_stop_active": False}

    # ---------- external prompt API playground ----------

    def call_external_prompt_api(self, request: JsonDict) -> JsonDict:
        """Proxy one prompt to a user-provided API endpoint.

        This is intentionally generic so the user can paste the same endpoint/body they already use
        from PowerShell. Secrets are not stored server-side and are masked in events.
        """
        endpoint = str(request.get("endpoint") or request.get("url") or "").strip()
        prompt = str(request.get("prompt") or "")
        method = str(request.get("method") or "POST").upper()
        body_template = str(request.get("body_template") or '{"prompt":{{prompt_json}}}')
        headers_raw = request.get("headers") or {}
        timeout = int(request.get("timeout_sec") or 120)

        if not endpoint:
            return {"ok": False, "error": "endpoint/url is required"}
        if method not in {"POST", "GET"}:
            return {"ok": False, "error": "method must be POST or GET"}
        model = str(request.get("model") or "").strip()
        if timeout <= 0 or timeout > 600:
            return {"ok": False, "error": "timeout_sec must be between 1 and 600"}

        if isinstance(headers_raw, str):
            try:
                headers = json.loads(headers_raw) if headers_raw.strip() else {}
            except json.JSONDecodeError as e:
                return {"ok": False, "error": f"headers must be valid JSON: {e}"}
        elif isinstance(headers_raw, dict):
            headers = dict(headers_raw)
        else:
            return {"ok": False, "error": "headers must be an object or JSON string"}

        if not isinstance(headers, dict):
            return {"ok": False, "error": "headers must decode to an object"}
        headers = {str(k): str(v) for k, v in headers.items()}

        safe_endpoint = mask_secrets(endpoint)
        started = time.time()
        try:
            if method == "GET":
                sep = "&" if "?" in endpoint else "?"
                url = endpoint + sep + urllib.parse.urlencode({"prompt": prompt})
                req = urllib.request.Request(url, headers=headers, method="GET")
                data = None
            else:
                rendered_body = (
                    body_template
                    .replace("{{model}}", model)
                    .replace("{{model_json}}", json.dumps(model, ensure_ascii=False))
                    .replace("{{prompt_json}}", json.dumps(prompt, ensure_ascii=False))
                    .replace("{{prompt}}", prompt)
                )
                body_bytes = rendered_body.encode("utf-8")
                if not any(k.lower() == "content-type" for k in headers):
                    headers["Content-Type"] = "application/json"
                req = urllib.request.Request(endpoint, data=body_bytes, headers=headers, method="POST")
                data = rendered_body

            with urllib.request.urlopen(req, timeout=timeout) as resp:
                raw = resp.read()
                content_type = resp.headers.get("Content-Type", "")
                text = raw.decode("utf-8", errors="replace")
                elapsed = round(time.time() - started, 3)
                parsed: Any = None
                if "json" in content_type.lower() or text.strip().startswith(("{", "[")):
                    try:
                        parsed = json.loads(text)
                    except Exception:
                        parsed = None
                self.emit(
                    "external_api.called",
                    "External prompt API call completed",
                    {"endpoint": safe_endpoint, "method": method, "status": resp.status, "elapsed_sec": elapsed, "response_chars": len(text)},
                )
                return {
                    "ok": True,
                    "status": resp.status,
                    "content_type": content_type,
                    "elapsed_sec": elapsed,
                    "text": text,
                    "json": parsed,
                    "request_preview": {"endpoint": safe_endpoint, "method": method, "body": mask_secrets(data or "")[:2000]},
                }
        except urllib.error.HTTPError as e:
            body = e.read().decode("utf-8", errors="replace") if e.fp else ""
            self.emit("external_api.http_error", "External prompt API returned HTTP error", {"endpoint": safe_endpoint, "status": e.code, "body_preview": mask_secrets(body)[:1000]}, level="warning")
            return {"ok": False, "error": f"HTTP {e.code}: {e.reason}", "status": e.code, "text": body}
        except Exception as e:
            self.emit("external_api.error", "External prompt API call failed", {"endpoint": safe_endpoint, "error": str(e)}, level="error")
            return {"ok": False, "error": str(e), "traceback": traceback.format_exc(limit=2)}

    def get_state(self) -> JsonDict:
        with self.lock:
            approvals = [dataclasses.asdict(a) for a in self.approvals.values()]
            questions = [dataclasses.asdict(q) for q in self.questions.values()]
            permissions = dict(self.permissions)
            events = list(self.events[-250:])
            server_url = self.server_url
            policy_path = str(self.policy_path) if self.policy_path else None
            policy_exists = bool(self.policy_path and self.policy_path.exists())
        status: JsonDict = {}
        config: JsonDict = {}
        if self.status_provider:
            try:
                status = self.status_provider()
            except Exception as e:  # pragma: no cover - defensive
                status = {"ok": False, "error": str(e), "traceback": traceback.format_exc(limit=2)}
        if self.config_getter:
            try:
                config = self.config_getter()
            except Exception as e:  # pragma: no cover - defensive
                config = {"ok": False, "error": str(e)}
        return {
            "ok": True,
            "server_url": server_url,
            "emergency_stop_active": self.emergency_stop_active,
            "status": shorten(status, limit=5000),
            "config": shorten(config, limit=5000),
            "tasks": shorten(self.get_tasks(), limit=5000),
            "permissions": permissions,
            "policy_storage": {
                "path": policy_path,
                "exists": policy_exists,
                "last_loaded_at": self.policy_last_loaded_at,
                "last_saved_at": self.policy_last_saved_at,
            },
            "policy_templates": self.get_policy_templates(),
            "approvals": approvals[-100:],
            "questions": questions[-100:],
            "events": events,
        }

    def update_config(self, updates: JsonDict) -> JsonDict:
        if not self.config_updater:
            return {"ok": False, "error": "config updater not registered"}
        try:
            result = self.config_updater(updates)
            self.emit("config.updated", "Runtime config update requested", {"updates": updates, "result": result})
            return result
        except Exception as e:
            result = {"ok": False, "error": str(e), "traceback": traceback.format_exc(limit=3)}
            self.emit("config.update_failed", "Runtime config update failed", result, level="error")
            return result


class DashboardServer:
    def __init__(self, center: AdminControlCenter, host: str = "127.0.0.1", port: int = 8765, auth_token: str = ""):
        self.center = center
        self.host = host
        self.port = int(port)
        self.auth_token = auth_token
        self.httpd: Optional[ThreadingHTTPServer] = None
        self.thread: Optional[threading.Thread] = None

    def start_background(self) -> str:
        center = self.center
        auth_token = self.auth_token

        class Handler(DashboardRequestHandler):
            control_center = center

        Handler.auth_token = auth_token
        self.httpd = ThreadingHTTPServer((self.host, self.port), Handler)
        actual_host, actual_port = self.httpd.server_address[:2]
        url = f"http://{actual_host}:{actual_port}"
        self.center.set_server_url(url)
        self.thread = threading.Thread(target=self.httpd.serve_forever, name="SkyGroundDashboard", daemon=True)
        self.thread.start()
        return url

    def stop(self) -> None:
        if self.httpd:
            self.httpd.shutdown()


class DashboardRequestHandler(BaseHTTPRequestHandler):
    control_center: AdminControlCenter
    auth_token: str = ""

    server_version = "SkyGroundDashboard/0.5"

    def log_message(self, fmt: str, *args: Any) -> None:
        # Keep terminal clean; events are visible in dashboard.
        return

    def _is_authorized(self) -> bool:
        if not self.auth_token:
            return True
        parsed = urlparse(self.path)
        query_token = parse_qs(parsed.query).get("token", [""])[0]
        header_token = self.headers.get("X-Admin-Token", "")
        return query_token == self.auth_token or header_token == self.auth_token

    def _send_auth_required(self) -> None:
        parsed = urlparse(self.path)
        if parsed.path.startswith("/api/"):
            self._send_json({"ok": False, "error": "unauthorized"}, status=401)
        else:
            self._send_html(AUTH_HTML, status=401)

    # ---------- response helpers ----------

    def _send_json(self, obj: JsonDict, status: int = 200) -> None:
        data = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Cache-Control", "no-store")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def _send_html(self, body: str, status: int = 200) -> None:
        data = body.encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Cache-Control", "no-store")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def _read_json(self) -> JsonDict:
        length = int(self.headers.get("Content-Length", "0") or "0")
        if length <= 0:
            return {}
        raw = self.rfile.read(length).decode("utf-8")
        try:
            obj = json.loads(raw)
            if isinstance(obj, dict):
                return obj
            return {"value": obj}
        except json.JSONDecodeError:
            return {"_raw": raw}

    # ---------- HTTP ----------

    def do_GET(self) -> None:  # noqa: N802
        if not self._is_authorized():
            self._send_auth_required()
            return
        parsed = urlparse(self.path)
        path = parsed.path
        qs = parse_qs(parsed.query)
        if path == "/":
            self._send_html(DASHBOARD_HTML)
            return
        if path == "/api/state":
            self._send_json(self.control_center.get_state())
            return
        if path == "/api/events":
            limit = int(qs.get("limit", ["200"])[0])
            self._send_json({"ok": True, "events": self.control_center.get_events(limit=limit)})
            return
        self._send_json({"ok": False, "error": "not found"}, status=404)

    def do_POST(self) -> None:  # noqa: N802
        if not self._is_authorized():
            self._send_auth_required()
            return
        parsed = urlparse(self.path)
        path = parsed.path
        body = self._read_json()

        if path == "/api/approval":
            approval_id = str(body.get("id", ""))
            decision = str(body.get("decision", "")).lower()
            reason = str(body.get("reason", ""))
            if decision not in {"approve", "approved", "reject", "rejected"}:
                self._send_json({"ok": False, "error": "decision must be approve or reject"}, status=400)
                return
            self._send_json(self.control_center.decide_approval(approval_id, decision.startswith("approve"), reason))
            return

        if path == "/api/question":
            question_id = str(body.get("id", ""))
            answer = str(body.get("answer", ""))
            self._send_json(self.control_center.answer_question(question_id, answer))
            return

        if path == "/api/task":
            task = str(body.get("task", body.get("prompt", "")))
            source = str(body.get("source", "dashboard"))
            self._send_json(self.control_center.submit_task(task, source=source))
            return

        if path == "/api/task/control":
            action = str(body.get("action", ""))
            task_id = body.get("id", body.get("task_id"))
            self._send_json(self.control_center.control_task(action, str(task_id) if task_id else None))
            return

        if path == "/api/external_prompt":
            self._send_json(self.control_center.call_external_prompt_api(body))
            return

        if path == "/api/agent/op":
            operation = str(body.get("operation", body.get("op", "")))
            payload = body.get("payload", {})
            if not isinstance(payload, dict):
                payload = {"value": payload}
            self._send_json(self.control_center.agent_op(operation, payload))
            return

        if path == "/api/permissions":
            self._send_json(self.control_center.update_permissions(body))
            return

        if path == "/api/policy/template":
            template_id = str(body.get("id", body.get("template_id", "")))
            merge = bool(body.get("merge", False))
            self._send_json(self.control_center.apply_policy_template(template_id, merge=merge))
            return

        if path == "/api/policy/save":
            self._send_json(self.control_center.save_policy_to_disk())
            return

        if path == "/api/policy/load":
            self._send_json(self.control_center.load_policy_from_disk())
            return

        if path == "/api/policy/reset":
            self._send_json(self.control_center.reset_policy(delete_file=bool(body.get("delete_file", False))))
            return

        if path == "/api/config":
            self._send_json(self.control_center.update_config(body))
            return

        self._send_json({"ok": False, "error": "not found"}, status=404)


AUTH_HTML = r"""
<!doctype html>
<html lang="fa" dir="rtl">
<head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>SkyGround Login</title>
<style>body{margin:0;min-height:100vh;display:grid;place-items:center;background:#070b14;color:#edf4ff;font-family:system-ui,Tahoma}.box{width:min(440px,92vw);background:#111a2e;border:1px solid #22304d;border-radius:18px;padding:24px;box-shadow:0 18px 60px rgba(0,0,0,.35)}input,button{width:100%;padding:12px;border-radius:12px;border:1px solid #22304d;margin-top:10px}input{background:#070b14;color:#edf4ff}button{background:#6ee7ff;color:#031018;font-weight:900;cursor:pointer}.small{color:#8ea0c0;font-size:12px}</style></head>
<body><div class="box"><h2>SkyGround Admin Token</h2><p class="small">برای ورود، dashboard token را وارد کن.</p><input id="t" type="password" placeholder="Admin token"><button onclick="go()">ورود</button><p class="small">اگر token تنظیم نکرده‌ای، مقدار dashboard_token را در config بررسی کن.</p></div>
<script>function go(){const t=document.getElementById('t').value.trim(); if(!t)return; localStorage.setItem('sg_admin_token',t); location.href='/?token='+encodeURIComponent(t);}</script></body></html>
"""


DASHBOARD_HTML = r"""
<!doctype html>
<html lang="fa" dir="rtl">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <title>SkyGround Admin Dashboard</title>
  <style>
    :root{
      --bg:#070b14;--panel:#0d1424;--panel2:#111a2e;--muted:#8ea0c0;--text:#edf4ff;
      --line:#22304d;--brand:#6ee7ff;--ok:#22c55e;--warn:#f59e0b;--err:#ef4444;--purple:#a78bfa;
      --shadow:0 18px 60px rgba(0,0,0,.35);--radius:18px;
    }
    *{box-sizing:border-box}body{margin:0;background:radial-gradient(circle at top left,#10214b 0,#070b14 36%,#05070c 100%);color:var(--text);font:14px/1.55 system-ui,-apple-system,Segoe UI,Tahoma,Arial,sans-serif;min-height:100vh}
    .app{max-width:1480px;margin:0 auto;padding:22px}.top{display:flex;gap:14px;align-items:center;justify-content:space-between;margin-bottom:18px}
    .brand{display:flex;gap:12px;align-items:center}.logo{width:42px;height:42px;border-radius:14px;background:linear-gradient(135deg,var(--brand),var(--purple));box-shadow:0 0 35px rgba(110,231,255,.25)}
    h1{margin:0;font-size:22px}.sub{color:var(--muted);font-size:12px}.pill{border:1px solid var(--line);background:rgba(17,26,46,.7);border-radius:999px;padding:7px 11px;color:var(--muted)}
    .grid{display:grid;grid-template-columns:1.3fr .9fr;gap:16px}.cards{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:12px;margin-bottom:16px}
    .card,.panel{background:linear-gradient(180deg,rgba(17,26,46,.94),rgba(13,20,36,.94));border:1px solid var(--line);border-radius:var(--radius);box-shadow:var(--shadow)}
    .card{padding:15px}.k{color:var(--muted);font-size:12px}.v{font-size:18px;font-weight:800;margin-top:4px;direction:ltr;text-align:right}.panel{padding:15px;margin-bottom:16px}.panel h2{margin:0 0 12px;font-size:16px;display:flex;align-items:center;justify-content:space-between}
    .badge{display:inline-flex;align-items:center;gap:6px;border-radius:999px;padding:4px 9px;font-size:12px;border:1px solid var(--line);background:#0b1222;color:var(--muted)}
    .badge.ok{color:#bbf7d0;border-color:rgba(34,197,94,.35)}.badge.warn{color:#fde68a;border-color:rgba(245,158,11,.35)}.badge.err{color:#fecaca;border-color:rgba(239,68,68,.35)}
    .list{display:flex;flex-direction:column;gap:10px}.item{background:rgba(7,11,20,.55);border:1px solid rgba(34,48,77,.8);border-radius:14px;padding:12px}.item-head{display:flex;justify-content:space-between;gap:12px;align-items:start}.title{font-weight:800}.meta{color:var(--muted);font-size:12px;direction:ltr;text-align:left}.pre{direction:ltr;text-align:left;white-space:pre-wrap;word-break:break-word;background:#050812;border:1px solid var(--line);border-radius:12px;padding:10px;color:#d7e6ff;max-height:320px;overflow:auto}.row{display:flex;gap:8px;flex-wrap:wrap;align-items:center}.btn{border:0;border-radius:12px;padding:9px 12px;font-weight:800;cursor:pointer;color:#031018;background:var(--brand)}.btn.secondary{background:#1f2a44;color:var(--text);border:1px solid var(--line)}.btn.ok{background:var(--ok)}.btn.err{background:var(--err);color:white}.btn.warn{background:var(--warn)}.btn:disabled{opacity:.55;cursor:not-allowed}
    input,select,textarea{width:100%;background:#070b14;color:var(--text);border:1px solid var(--line);border-radius:12px;padding:10px;outline:none}textarea{min-height:74px;resize:vertical}.formgrid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px}.field label{display:block;color:var(--muted);font-size:12px;margin-bottom:5px}.switch{display:flex;align-items:center;gap:9px;margin:7px 0;color:var(--muted)}.switch input{width:auto}.tabs{display:flex;gap:8px;flex-wrap:wrap;margin-bottom:12px}.tab{padding:8px 11px;border:1px solid var(--line);background:#0b1222;border-radius:999px;color:var(--muted);cursor:pointer}.tab.active{color:#031018;background:var(--brand);border-color:transparent;font-weight:900}.hide{display:none}.log{max-height:520px;overflow:auto}.event{border-bottom:1px solid rgba(34,48,77,.55);padding:9px 2px}.event:last-child{border-bottom:0}.ltr{direction:ltr;text-align:left}.empty{color:var(--muted);padding:14px;text-align:center;border:1px dashed var(--line);border-radius:14px}.small{font-size:12px;color:var(--muted)}
    @media(max-width:1050px){.grid{grid-template-columns:1fr}.cards{grid-template-columns:repeat(2,minmax(0,1fr))}.formgrid{grid-template-columns:1fr}}
    @media(max-width:600px){.cards{grid-template-columns:1fr}.top{align-items:flex-start;flex-direction:column}}
  </style>
</head>
<body>
<div class="app">
  <div class="top">
    <div class="brand"><div class="logo"></div><div><h1>SkyGround Admin Dashboard</h1><div class="sub">نظارت، Approval، Ask، دسترسی و تنظیمات پارامتریک ایجنت محلی</div></div></div>
    <div class="row"><span class="pill" id="serverUrl">...</span><span class="pill" id="lastRefresh">...</span></div>
  </div>

  <div class="cards">
    <div class="card"><div class="k">Agent</div><div class="v" id="agentState">...</div></div>
    <div class="card"><div class="k">Model</div><div class="v" id="modelName">...</div></div>
    <div class="card"><div class="k">Brain route</div><div class="v" id="brainRouteTop">...</div></div>
    <div class="card"><div class="k">Pending approvals</div><div class="v" id="pendingApprovals">0</div></div>
    <div class="card"><div class="k">Pending asks</div><div class="v" id="pendingQuestions">0</div></div>
  </div>

  <div class="grid">
    <main>
      <div class="panel">
        <h2>Admin Injection Center <span class="badge ok">Memory + Skills</span></h2>
        <div class="small">تزریق دستی یا فایل به حافظه، vector memory، intentها، skillها و shortcutها. برای فایل، محتوا در مرورگر خوانده و به agent ارسال می‌شود.</div>
        <div class="formgrid" style="margin-top:10px">
          <div class="field"><label>Namespace</label><input id="injectNamespace" class="ltr" value="admin_injection" /></div>
          <div class="field"><label>Kind</label><input id="injectKind" class="ltr" value="admin_note" /></div>
        </div>
        <div class="row" style="margin:8px 0">
          <label class="switch"><input type="checkbox" id="injectMemory" checked> Memory</label>
          <label class="switch"><input type="checkbox" id="injectVector" checked> Vector</label>
          <label class="switch"><input type="checkbox" id="injectOverwrite" checked> Overwrite skills/intents</label>
        </div>
        <div class="field"><label>فایل تزریق اختیاری: txt/json/md</label><input id="injectFile" type="file" /></div>
        <div class="field"><label>Injection text یا JSON bundle</label><textarea id="injectText" class="ltr" placeholder='متن آموزشی یا JSON bundle مثل {"memories":[],"intents":[],"skills":[],"shortcuts":[]}'></textarea></div>
        <div class="row" style="margin-top:10px">
          <button class="btn secondary" onclick="loadInjectFile()">Load File</button>
          <button class="btn" onclick="injectTextMode()">Inject Text</button>
          <button class="btn ok" onclick="injectJsonBundle()">Inject JSON Bundle</button>
          <button class="btn secondary" onclick="fillSampleInjection()">Sample Bundle</button>
        </div>
        <pre class="pre" id="injectOutput">Injection output...</pre>
      </div>

      <div class="panel">
        <h2>Reflex / Skills <span class="badge ok">Fast Local Brain</span></h2>
        <div class="small">دستورهای پایه مثل «کپی کن»، «ذخیره کن»، «git status» بدون مغز بزرگ resolve می‌شوند. برای شروع Dry Run را تست کن.</div>
        <div class="formgrid" style="margin-top:10px">
          <div class="field"><label>Reflex command</label><input id="reflexCommand" placeholder="مثلاً: کپی کن یا save یا git status" /></div>
          <div class="field"><label>Promote skill id اختیاری</label><input id="promoteSkillId" class="ltr" placeholder="shortcut.copy" /></div>
        </div>
        <div class="row" style="margin-top:10px">
          <button class="btn secondary" onclick="reflexResolve()">Resolve</button>
          <button class="btn secondary" onclick="reflexExecute(true)">Dry Run</button>
          <button class="btn ok" onclick="reflexExecute(false)">Execute</button>
          <button class="btn secondary" onclick="skillList()">List Skills</button>
          <button class="btn secondary" onclick="promoteSkill('trusted')">Promote Trusted</button>
          <button class="btn warn" onclick="eventCounts()">Event Counts</button>
          <button class="btn secondary" onclick="dailyDistill(false)">Daily Distill</button>
          <button class="btn ok" onclick="dailyDistill(true)">Distill + Apply</button>
        </div>
        <pre class="pre" id="reflexOutput">Reflex output...</pre>
      </div>

      <div class="panel">
        <h2>Project Factory <span class="badge ok">Scaffold</span></h2>
        <div class="small">برای درخواست‌هایی مثل «یک وب‌سایت با پایتون بساز»، پروژه را مستقیم با فایل‌ها می‌سازد؛ نیازی به VS Code UI نیست. اول Preview را بزن.</div>
        <div class="formgrid" style="margin-top:10px">
          <div class="field"><label>Template</label><select id="scaffoldTemplate"><option value="python_flask_site">Python Flask Website</option><option value="python_fastapi_api">Python FastAPI API</option><option value="static_html_site">Static HTML Site</option><option value="python_cli_tool">Python CLI Tool</option></select></div>
          <div class="field"><label>Project folder name</label><input id="scaffoldProjectName" class="ltr" placeholder="my_python_site" /></div>
        </div>
        <div class="field"><label>Description</label><textarea id="scaffoldDescription" placeholder="مثلاً: یک وب‌سایت معرفی نمونه‌کار با ظاهر مدرن"></textarea></div>
        <label class="switch"><input type="checkbox" id="scaffoldOverwrite"> Overwrite existing files</label>
        <div class="row" style="margin-top:10px">
          <button class="btn secondary" onclick="scaffoldProject(true)">Preview / Dry Run</button>
          <button class="btn ok" onclick="scaffoldProject(false)">Create Project</button>
          <button class="btn secondary" onclick="submitScaffoldAsTask()">Ask Agent to Customize</button>
        </div>
        <pre class="pre" id="scaffoldOutput">Scaffold output...</pre>
      </div>

      <div class="panel">
        <h2>Task Manager <span class="badge ok">Command Center</span></h2>
        <div class="field"><label>Task جدید برای ایجنت</label><textarea id="newTask" placeholder="مثلاً: خطای login را بررسی کن و قبل از تغییرات approval بگیر..."></textarea></div>
        <div class="row" style="margin-top:10px">
          <button class="btn" onclick="submitTask()">Submit Task</button>
          <button class="btn secondary" onclick="controlTask('pause')">Pause</button>
          <button class="btn secondary" onclick="controlTask('resume')">Resume</button>
          <button class="btn err" onclick="controlTask('emergency_stop')">Emergency Stop</button>
          <button class="btn warn" onclick="controlTask('clear_emergency_stop')">Clear Stop</button>
        </div>
        <div class="small" id="taskRuntimeInfo">...</div>
        <div class="list" id="tasks"></div>
      </div>

      <div class="panel">
        <h2>Vector Memory + Desktop Logs <span class="badge ok">Learning Eye</span></h2>
        <div class="formgrid">
          <div class="field"><label>جستجو در حافظه برداری</label><input id="vecQuery" placeholder="مثلاً: login token خطا" /></div>
          <div class="field"><label>Namespace</label><input id="vecNamespace" class="ltr" placeholder="general یا monthly_experience" /></div>
        </div>
        <div class="row" style="margin-top:10px">
          <button class="btn" onclick="vectorSearch()">Search Vector Memory</button>
          <button class="btn secondary" onclick="monthlyInject()">Monthly Inject</button>
        </div>
        <hr style="border:0;border-top:1px solid var(--line);margin:14px 0">
        <div class="formgrid">
          <div class="field"><label>Log file path برای چشم ایجنت</label><input id="desktopLogPath" class="ltr" placeholder="C:\\path\\to\\app.log" /></div>
          <div class="field"><label>Shortcut intent</label><input id="shortcutIntent" placeholder="مثلاً open search یا go back" /></div>
        </div>
        <div class="formgrid">
          <div class="field"><label>Shortcut name</label><input id="shortcutName" class="ltr" placeholder="open_search" /></div>
          <div class="field"><label>Shortcut keys با +</label><input id="shortcutKeys" class="ltr" placeholder="Ctrl+K" /></div>
        </div>
        <div class="field"><label>Shortcut description</label><input id="shortcutDescription" placeholder="Open global search" /></div>
        <div class="row" style="margin-top:10px">
          <button class="btn secondary" onclick="registerDesktopLog()">Register Log</button>
          <button class="btn" onclick="observeDesktopLogs()">Observe Logs</button>
          <button class="btn secondary" onclick="getDesktopState()">Desktop State</button>
          <button class="btn secondary" onclick="registerShortcut()">Register Shortcut</button>
          <button class="btn secondary" onclick="suggestShortcut()">Suggest Shortcut</button>
          <button class="btn secondary" onclick="executeShortcut(true)">Dry Run Shortcut</button>
          <button class="btn ok" onclick="executeShortcut(false)">Execute Shortcut</button>
        </div>
        <div id="desktopStateView" style="margin-top:12px"></div>
        <pre class="pre" id="opsOutput">Vector/Desktop operation output...</pre>
      </div>

      <div class="panel">
        <h2>External API Chat / کمک‌برنامه‌نویس <span class="badge ok">Prompt API</span></h2>
        <div class="small">URL/API که با PowerShell تست کردی را اینجا بده؛ بعد مثل چت باهاش سؤال برنامه‌نویسی بپرس. خروجی را می‌توانی با یک دکمه تبدیل به Task برای agent داخلی کنی.</div>
        <div class="row" style="margin:8px 0">
          <button class="btn secondary" onclick="presetOpenAICompatible()">Preset OpenAI-compatible</button>
          <button class="btn secondary" onclick="presetGapGPT()">Preset GapGPT</button>
        </div>
        <div class="formgrid" style="margin-top:10px">
          <div class="field"><label>Endpoint URL</label><input id="extEndpoint" class="ltr" placeholder="https://example.com/v1/chat/completions یا base /v1" /></div>
          <div class="field"><label>Method</label><select id="extMethod"><option>POST</option><option>GET</option></select></div>
          <div class="field"><label>Model اختیاری</label><input id="extModel" class="ltr" placeholder="gpt-4o" /></div>
          <div class="field"><label>Response JSON path اختیاری</label><input id="extResponsePath" class="ltr" placeholder="choices.0.message.content" /></div>
        </div>
        <div class="field"><label>Headers JSON</label><textarea id="extHeaders" class="ltr" placeholder='{"Authorization":"Bearer YOUR_KEY"}'></textarea></div>
        <div class="field"><label>Body template</label><textarea id="extBody" class="ltr">{"prompt":{{prompt_json}}}</textarea></div>
        <div class="field"><label>System / Instruction اختیاری</label><textarea id="extSystemPrompt" placeholder="تو یک دستیار برنامه‌نویس دقیق هستی. پاسخ را کاربردی، مرحله‌ای و همراه کد بده.">تو یک دستیار برنامه‌نویس دقیق هستی. اگر کد لازم است، کد کامل و قابل اجرا بده. اگر نیاز به تغییر پروژه است، پیشنهاد patch یا مراحل دقیق بده.</textarea></div>
        <div class="field"><label>Context / Code اختیاری</label><textarea id="extContext" class="ltr" placeholder="کد، خطا، لاگ یا توضیح پروژه را اینجا paste کن..."></textarea></div>
        <div class="row" style="margin:8px 0">
          <button class="btn secondary" onclick="setExtPrompt('این کد/کانتکست را تحلیل کن و مشکل‌های احتمالی را بگو.')">Analyze</button>
          <button class="btn secondary" onclick="setExtPrompt('برای این مسئله کد تمیز، کامل و قابل اجرا بنویس.')">Generate Code</button>
          <button class="btn secondary" onclick="setExtPrompt('این خطا را debug کن و راه‌حل مرحله‌ای بده.')">Debug</button>
          <button class="btn secondary" onclick="setExtPrompt('برای این کد تست مناسب بنویس.')">Write Tests</button>
          <button class="btn secondary" onclick="setExtPrompt('این کد را refactor کن و نسخه بهتر را بده.')">Refactor</button>
        </div>
        <div class="field"><label>Prompt / سوال</label><textarea id="extPrompt" placeholder="مثلاً: این تابع را refactor کن و کد کامل بده..."></textarea></div>
        <div class="row" style="margin-top:10px">
          <button class="btn" onclick="sendExternalPrompt()">Ask API</button>
          <button class="btn secondary" onclick="sendApiResponseAsTask('review')">Review with Agent</button>
          <button class="btn ok" onclick="sendApiResponseAsTask('implement')">Implement Safely</button>
          <button class="btn warn" onclick="sendApiResponseAsTask('patch')">Apply as Patch</button>
          <button class="btn secondary" onclick="copyApiResponse()">Copy Response</button>
          <button class="btn warn" onclick="clearExternalChat()">Clear Chat</button>
        </div>
        <div class="list" id="extChat" style="margin-top:10px"></div>
        <pre class="pre" id="extOutput">API response...</pre>
      </div>

      <div class="panel">
        <h2>درخواست‌های Approval <span class="badge warn">Admin Gate</span></h2>
        <div class="list" id="approvals"></div>
      </div>

      <div class="panel">
        <h2>پرسش‌های ایجنت از ادمین <span class="badge">Ask Admin</span></h2>
        <div class="list" id="questions"></div>
      </div>

      <div class="panel">
        <h2>رویدادها و لاگ زنده <span class="badge">Polling Live</span></h2>
        <div class="log" id="events"></div>
      </div>
    </main>

    <aside>
      <div class="panel">
        <h2>Policy Templates <span class="badge ok">Preset + Persist</span></h2>
        <div class="field"><label>Template</label><select id="policyTemplate"></select></div>
        <div class="row" style="margin-top:10px">
          <button class="btn" onclick="applyTemplate(false)">اعمال Template</button>
          <button class="btn secondary" onclick="applyTemplate(true)">Merge</button>
        </div>
        <div style="height:10px"></div>
        <div class="row">
          <button class="btn ok" onclick="savePolicy()">Save Policy</button>
          <button class="btn secondary" onclick="loadPolicy()">Load Policy</button>
          <button class="btn warn" onclick="resetPolicy(false)">Reset Session</button>
        </div>
        <div class="small" id="policyStorageInfo">policy storage...</div>
        <div class="small">Templateها سریع policy امن می‌سازند؛ Save آن را در workspace ذخیره می‌کند.</div>
      </div>

      <div class="panel">
        <h2>دسترسی‌های Session <span class="badge warn">غیر دائمی</span></h2>
        <div class="switch"><input type="checkbox" id="readOnly"> <label for="readOnly">Read-only mode؛ همه write/command رد شوند</label></div>
        <div class="switch"><input type="checkbox" id="autoWrites"> <label for="autoWrites">Auto-approve برای write/edit</label></div>
        <div class="switch"><input type="checkbox" id="autoCommands"> <label for="autoCommands">Auto-approve برای command</label></div>
        <div class="switch"><input type="checkbox" id="autoQuestions"> <label for="autoQuestions">Auto-answer برای Ask</label></div>
        <div class="field"><label>پاسخ خودکار Ask</label><input id="autoQuestionAnswer" placeholder="مثلاً: ادامه بده" /></div>
        <hr style="border:0;border-top:1px solid var(--line);margin:14px 0">
        <div class="small">Policy جزئی‌تر؛ هر مورد یک خط. Deny همیشه اولویت دارد.</div>
        <div class="field"><label>Allowed write globs</label><textarea id="allowedWriteGlobs" class="ltr" placeholder="src/**&#10;README.md"></textarea></div>
        <div class="field"><label>Denied write globs</label><textarea id="deniedWriteGlobs" class="ltr" placeholder=".env&#10;**/secrets/**"></textarea></div>
        <div class="switch"><input type="checkbox" id="rejectUnmatchedWrites"> <label for="rejectUnmatchedWrites">Reject write/edit خارج از allowlist</label></div>
        <div class="field"><label>Allowed command globs</label><textarea id="allowedCommandGlobs" class="ltr" placeholder="python -m pytest*&#10;npm test*&#10;npm run build*"></textarea></div>
        <div class="field"><label>Denied command fragments</label><textarea id="deniedCommandFragments" class="ltr" placeholder="rm -rf&#10;del /s&#10;format "></textarea></div>
        <div class="switch"><input type="checkbox" id="rejectUnmatchedCommands"> <label for="rejectUnmatchedCommands">Reject command خارج از allowlist</label></div>
        <div style="height:10px"></div>
        <button class="btn" onclick="savePermissions()">ذخیره دسترسی‌های Session</button>
        <div class="small">مثال امن: auto-approve command را روشن کن، allowed command را فقط <span class="ltr">python -m pytest*</span> بگذار، و reject unmatched را فعال کن.</div>
      </div>

      <div class="panel">
        <h2>تنظیمات پارامتریک Runtime <span class="badge ok">Hot Update</span></h2>
        <div class="formgrid">
          <div class="field"><label>LLM Provider</label><select id="cfg_llm_provider"><option value="ollama">ollama</option><option value="openai_compatible">openai_compatible</option><option value="auto">auto / smart routing</option></select></div>
          <div class="field"><label>Model</label><input id="cfg_model" class="ltr" /></div>
          <div class="field"><label>Ollama URL</label><input id="cfg_ollama_url" class="ltr" /></div>
          <div class="field"><label>OpenAI-compatible base URL</label><input id="cfg_openai_base_url" class="ltr" placeholder="https://api.gapgpt.app/v1" /></div>
          <div class="field"><label>API key env var</label><input id="cfg_openai_api_key_env" class="ltr" placeholder="GAPGPT_API_KEY" /></div>
          <div class="field"><label>OpenAI max tokens / 0 default</label><input id="cfg_openai_max_tokens" type="number" min="0" /></div>
          <div class="field"><label>OpenAI timeout sec</label><input id="cfg_openai_timeout_sec" type="number" min="1" /></div>
          <div class="field"><label>Simple brain</label><select id="cfg_brain_routing_simple_provider"><option value="ollama">ollama</option><option value="openai_compatible">openai_compatible</option></select></div>
          <div class="field"><label>Complex brain</label><select id="cfg_brain_routing_complex_provider"><option value="openai_compatible">openai_compatible</option><option value="ollama">ollama</option></select></div>
          <div class="field"><label>Sensitive brain</label><select id="cfg_brain_routing_sensitive_provider"><option value="ollama">ollama</option><option value="openai_compatible">openai_compatible</option></select></div>
          <div class="field"><label>Temperature</label><input id="cfg_temperature" type="number" step="0.05" min="0" max="2" /></div>
          <div class="field"><label>num_ctx فقط Ollama</label><input id="cfg_num_ctx" type="number" step="512" min="1024" /></div>
          <div class="field"><label>max_steps</label><input id="cfg_max_steps" type="number" min="1" /></div>
          <div class="field"><label>command_timeout_sec</label><input id="cfg_command_timeout_sec" type="number" min="1" /></div>
          <div class="field"><label>max_file_read_chars</label><input id="cfg_max_file_read_chars" type="number" min="1000" /></div>
        </div>
        <div class="switch"><input type="checkbox" id="cfg_brain_routing_enabled"> <label for="cfg_brain_routing_enabled">Enable smart brain routing</label></div>
        <div class="switch"><input type="checkbox" id="cfg_brain_routing_allow_api_for_sensitive"> <label for="cfg_brain_routing_allow_api_for_sensitive">Allow API for sensitive tasks</label></div>
        <hr style="border:0;border-top:1px solid var(--line);margin:14px 0">
        <div class="switch"><input type="checkbox" id="cfg_enable_shortcut_execution"> <label for="cfg_enable_shortcut_execution">Enable registered shortcut execution</label></div>
        <div class="switch"><input type="checkbox" id="cfg_require_approval_for_shortcuts"> <label for="cfg_require_approval_for_shortcuts">Require approval for shortcuts</label></div>
        <div class="switch"><input type="checkbox" id="cfg_shortcut_execution_dry_run"> <label for="cfg_shortcut_execution_dry_run">Shortcut dry-run mode</label></div>
        <div class="switch"><input type="checkbox" id="cfg_allow_shortcut_without_desktop_state"> <label for="cfg_allow_shortcut_without_desktop_state">Allow shortcut without desktop state</label></div>
        <div class="formgrid"><div class="field"><label>Min desktop confidence</label><input id="cfg_min_desktop_confidence_for_shortcut" type="number" min="0" max="1" step="0.05" /></div><div class="field"><label>Shortcut delay ms</label><input id="cfg_shortcut_execution_delay_ms" type="number" min="0" /></div></div>
        <div class="switch"><input type="checkbox" id="cfg_require_approval_for_writes"> <label for="cfg_require_approval_for_writes">Require approval for writes</label></div>
        <div class="switch"><input type="checkbox" id="cfg_require_approval_for_commands"> <label for="cfg_require_approval_for_commands">Require approval for commands</label></div>
        <div class="switch"><input type="checkbox" id="cfg_mask_secrets"> <label for="cfg_mask_secrets">Mask secrets in logs/diffs/context</label></div>
        <div class="switch"><input type="checkbox" id="cfg_mask_secrets_in_memory"> <label for="cfg_mask_secrets_in_memory">Mask secrets in memory DB</label></div>
        <div class="switch"><input type="checkbox" id="cfg_block_sensitive_file_reads"> <label for="cfg_block_sensitive_file_reads">Block sensitive file reads</label></div>
        <button class="btn" onclick="saveConfig()">اعمال تنظیمات Runtime</button>
        <div class="small">این تغییرات روی runtime فعلی اعمال می‌شوند؛ برای دائمی‌سازی، config.json را هم بعداً همگام کن.</div>
      </div>

      <div class="panel">
        <h2>وضعیت سیستم</h2>
        <pre class="pre" id="statusJson">{}</pre>
      </div>
    </aside>
  </div>
</div>

<script>
let state = null;
let configLoadedOnce = false;
let templatesLoadedOnce = false;
let apiResponseText = '';
let apiChatHistory = [];
let lastDesktopState = null;
const urlToken = new URLSearchParams(location.search).get('token');
if(urlToken) localStorage.setItem('sg_admin_token', urlToken);
function adminToken(){ return localStorage.getItem('sg_admin_token') || ''; }
function esc(s){return String(s??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));}
async function api(path, opts={}){
  const headers = {'Content-Type':'application/json', ...(opts.headers||{})};
  const token = adminToken(); if(token) headers['X-Admin-Token'] = token;
  const res = await fetch(path, {...opts, headers});
  if(res.status===401){ alert('Unauthorized: dashboard token اشتباه است یا وارد نشده.'); throw new Error('unauthorized'); }
  return await res.json();
}
function badgeStatus(status){
  if(status==='approved'||status==='answered') return 'ok';
  if(status==='rejected'||status==='expired') return 'err';
  return 'warn';
}
function listToText(v){ return Array.isArray(v) ? v.join('\n') : (v || ''); }
function textToList(id){ return (document.getElementById(id).value || '').split(/\r?\n|,/).map(x=>x.trim()).filter(Boolean); }
function renderPolicyTemplates(){
  const sel = document.getElementById('policyTemplate');
  const templates = state?.policy_templates || [];
  if(!sel || templatesLoadedOnce || !templates.length) return;
  sel.innerHTML = templates.map(t=>`<option value="${esc(t.id)}">${esc(t.label)} — ${esc(t.description)}</option>`).join('');
  templatesLoadedOnce = true;
}
function renderApprovals(items){
  const pending = items.filter(x=>x.status==='pending').reverse();
  const recent = items.filter(x=>x.status!=='pending').slice(-8).reverse();
  const all = [...pending, ...recent];
  document.getElementById('pendingApprovals').textContent = pending.length;
  const el = document.getElementById('approvals');
  if(!all.length){el.innerHTML='<div class="empty">فعلاً approval pending وجود ندارد.</div>';return;}
  el.innerHTML = all.map(a=>`<div class="item">
    <div class="item-head"><div><div class="title">${esc(a.title)}</div><div class="small">${esc(a.kind)} · ${esc(a.created_at)}</div></div><span class="badge ${badgeStatus(a.status)}">${esc(a.status)}</span></div>
    <pre class="pre">${esc(JSON.stringify(a.details,null,2))}</pre>
    ${a.status==='pending'?`<div class="row"><input id="reason_${a.id}" placeholder="reason optional" /><button class="btn ok" onclick="decideApproval('${a.id}',true)">Approve</button><button class="btn err" onclick="decideApproval('${a.id}',false)">Reject</button></div>`:''}
  </div>`).join('');
}
function renderQuestions(items){
  const pending = items.filter(x=>x.status==='pending').reverse();
  const recent = items.filter(x=>x.status!=='pending').slice(-8).reverse();
  const all = [...pending, ...recent];
  document.getElementById('pendingQuestions').textContent = pending.length;
  const el = document.getElementById('questions');
  if(!all.length){el.innerHTML='<div class="empty">فعلاً سوال pending وجود ندارد.</div>';return;}
  el.innerHTML = all.map(q=>`<div class="item">
    <div class="item-head"><div><div class="title">${esc(q.question)}</div><div class="small">${esc(q.created_at)}</div></div><span class="badge ${badgeStatus(q.status)}">${esc(q.status)}</span></div>
    ${q.options && q.options.length ? `<div class="row">${q.options.map(o=>`<button class="btn secondary" onclick="quickAnswer('${q.id}', '${esc(o).replace(/'/g,'\\&#39;')}')">${esc(o)}</button>`).join('')}</div>`:''}
    ${q.status==='pending'?`<textarea id="answer_${q.id}" placeholder="پاسخ ادمین..."></textarea><button class="btn" onclick="answerQuestion('${q.id}')">ارسال پاسخ</button>`:`<pre class="pre">${esc(q.answer)}</pre>`}
  </div>`).join('');
}
function renderEvents(items){
  const el = document.getElementById('events');
  if(!items.length){el.innerHTML='<div class="empty">هنوز رویدادی ثبت نشده.</div>';return;}
  el.innerHTML = items.slice().reverse().map(e=>`<div class="event"><div class="row"><span class="badge ${e.level==='error'?'err':e.level==='warning'?'warn':''}">${esc(e.level)}</span><b>${esc(e.type)}</b><span class="small ltr">${esc(e.time)}</span></div><div>${esc(e.message)}</div>${e.data&&Object.keys(e.data).length?`<pre class="pre">${esc(JSON.stringify(e.data,null,2))}</pre>`:''}</div>`).join('');
}
function brainBadge(provider){
  if(provider === 'openai_compatible') return 'ok';
  if(provider === 'ollama') return '';
  return 'warn';
}
function renderBrainRoute(route){
  if(!route) return '<span class="badge">not selected yet</span>';
  const provider = route.provider || 'unknown';
  const bits = [
    `<span class="badge ${brainBadge(provider)}">${esc(provider)}</span>`,
    `<span class="badge">${esc(route.reason || 'configured')}</span>`
  ];
  if(route.sensitive) bits.push('<span class="badge err">sensitive</span>');
  if(route.complex) bits.push('<span class="badge warn">complex</span>');
  if(route.fallback) bits.push(`<span class="badge err">fallback: ${esc(route.fallback)}</span>`);
  return `<div class="row">${bits.join('')}</div>`;
}
function renderTasks(taskState){
  const el = document.getElementById('tasks');
  const info = document.getElementById('taskRuntimeInfo');
  const tasks = taskState?.tasks || [];
  const running = tasks.find(t=>t.status==='running');
  const lastRoute = state?.status?.last_brain_route || running?.brain_route || tasks.slice().reverse().find(t=>t.brain_route)?.brain_route;
  info.innerHTML = `paused: ${taskState?.paused ? 'yes' : 'no'} · queue: ${taskState?.queue_size ?? 0} · emergency: ${state?.emergency_stop_active ? 'ACTIVE' : 'off'}<br>current brain: ${renderBrainRoute(lastRoute)}`;
  if(!tasks.length){el.innerHTML='<div class="empty">هنوز task ثبت نشده.</div>';return;}
  const visible = tasks.slice(-20).reverse();
  el.innerHTML = visible.map(t=>`<div class="item">
    <div class="item-head"><div><div class="title">${esc(t.prompt || t.task || '')}</div><div class="small ltr">${esc(t.id)} · ${esc(t.created_at)} · source=${esc(t.source)}</div></div><span class="badge ${t.status==='completed'?'ok':(t.status==='failed'||t.status==='cancelled')?'err':'warn'}">${esc(t.status)}</span></div>
    <div style="margin:8px 0">${renderBrainRoute(t.brain_route)}</div>
    ${t.language_profile?`<div class="small">language: ${esc(t.language_profile.primary_script)} · direction: ${esc(t.language_profile.direction)}</div>`:''}
    ${t.result?`<pre class="pre">${esc(t.result)}</pre>`:''}
    ${t.error?`<pre class="pre">${esc(t.error)}</pre>`:''}
    ${(t.status==='queued'||t.status==='running'||t.status==='cancelling')?`<div class="row"><button class="btn err" onclick="controlTask('cancel','${t.id}')">Cancel</button></div>`:''}
  </div>`).join('');
}
function confidenceBadge(conf){
  const n = Number(conf || 0);
  if(n >= .75) return 'ok';
  if(n >= .45) return 'warn';
  return 'err';
}
function renderDesktopState(ds){
  lastDesktopState = ds || lastDesktopState;
  const el = document.getElementById('desktopStateView');
  if(!el) return;
  const stateObj = ds?.state || ds || {};
  const current = stateObj.current_by_app || {};
  const apps = Object.values(current);
  const timeline = stateObj.timeline || ds?.observations || [];
  const logs = stateObj.registered_logs || [];
  if(!apps.length && !timeline.length && !logs.length){
    el.innerHTML = '<div class="empty">هنوز desktop state نداریم. اول Register Log و سپس Observe Logs را بزن.</div>';
    return;
  }
  const appCards = apps.length ? `<div class="cards" style="grid-template-columns:repeat(2,minmax(0,1fr));margin-bottom:12px">${apps.map(a=>`<div class="card"><div class="row"><span class="badge ${confidenceBadge(a.confidence)}">confidence ${esc(a.confidence ?? '-')}</span><span class="badge">${esc(a.app || 'app')}</span></div><div class="v" style="font-size:15px;text-align:right;direction:rtl">${esc(a.screen || a.location || 'unknown')}</div><div class="small ltr">route: ${esc(a.route || '-')}</div><div class="small">state: ${esc(a.state || '-')} · result: ${esc(a.last_result || '-')}</div><div class="small">message: ${esc(a.last_message || a.summary || '-')}</div></div>`).join('')}</div>` : '';
  const logList = logs.length ? `<div class="small">Registered logs: ${logs.map(l=>`${esc(l.path)} (${l.exists?'ok':'missing'})`).join(' · ')}</div>` : '';
  const tl = timeline.slice(-8).reverse().map(o=>`<div class="event"><div class="row"><span class="badge ${confidenceBadge(o.confidence)}">${esc(o.app || 'app')}</span><span class="small ltr">${esc(o.created_at || '')}</span></div><div><b>${esc(o.location || 'unknown')}</b></div><div class="small">${esc(o.summary || '')}</div></div>`).join('');
  el.innerHTML = `${appCards}${logList}<div class="log" style="max-height:300px;margin-top:10px">${tl || '<div class="empty">timeline خالی است.</div>'}</div>`;
}
function loadFormFromState(){
  const cfg = state.config?.config || state.config || {};
  const perms = state.permissions || {};
  document.getElementById('readOnly').checked = !!perms.read_only_mode;
  document.getElementById('autoWrites').checked = !!perms.auto_approve_writes;
  document.getElementById('autoCommands').checked = !!perms.auto_approve_commands;
  document.getElementById('autoQuestions').checked = !!perms.auto_answer_questions;
  document.getElementById('autoQuestionAnswer').value = perms.auto_question_answer || '';
  document.getElementById('allowedWriteGlobs').value = listToText(perms.allowed_write_globs);
  document.getElementById('deniedWriteGlobs').value = listToText(perms.denied_write_globs);
  document.getElementById('rejectUnmatchedWrites').checked = !!perms.reject_unmatched_writes;
  document.getElementById('allowedCommandGlobs').value = listToText(perms.allowed_command_globs);
  document.getElementById('deniedCommandFragments').value = listToText(perms.denied_command_fragments);
  document.getElementById('rejectUnmatchedCommands').checked = !!perms.reject_unmatched_commands;
  for(const k of ['llm_provider','model','ollama_url','openai_base_url','openai_api_key_env','openai_max_tokens','openai_timeout_sec','brain_routing_simple_provider','brain_routing_complex_provider','brain_routing_sensitive_provider','temperature','num_ctx','max_steps','command_timeout_sec','max_file_read_chars','min_desktop_confidence_for_shortcut','shortcut_execution_delay_ms']){
    const input = document.getElementById('cfg_'+k); if(input && cfg[k]!==undefined) input.value = cfg[k];
  }
  const br = document.getElementById('cfg_brain_routing_enabled'); if(br) br.checked = !!cfg.brain_routing_enabled || cfg.llm_provider === 'auto';
  const bas = document.getElementById('cfg_brain_routing_allow_api_for_sensitive'); if(bas) bas.checked = !!cfg.brain_routing_allow_api_for_sensitive;
  const ese = document.getElementById('cfg_enable_shortcut_execution'); if(ese) ese.checked = !!cfg.enable_shortcut_execution;
  const ras = document.getElementById('cfg_require_approval_for_shortcuts'); if(ras) ras.checked = cfg.require_approval_for_shortcuts !== false;
  const sdr = document.getElementById('cfg_shortcut_execution_dry_run'); if(sdr) sdr.checked = !!cfg.shortcut_execution_dry_run;
  const aws = document.getElementById('cfg_allow_shortcut_without_desktop_state'); if(aws) aws.checked = cfg.allow_shortcut_without_desktop_state !== false;
  const w = document.getElementById('cfg_require_approval_for_writes'); if(w) w.checked = !!cfg.require_approval_for_writes;
  const c = document.getElementById('cfg_require_approval_for_commands'); if(c) c.checked = !!cfg.require_approval_for_commands;
  const ms = document.getElementById('cfg_mask_secrets'); if(ms) ms.checked = cfg.mask_secrets !== false;
  const msm = document.getElementById('cfg_mask_secrets_in_memory'); if(msm) msm.checked = cfg.mask_secrets_in_memory !== false;
  const bsr = document.getElementById('cfg_block_sensitive_file_reads'); if(bsr) bsr.checked = !!cfg.block_sensitive_file_reads;
}
async function refresh(){
  try{
    state = await api('/api/state');
    document.getElementById('serverUrl').textContent = state.server_url || location.href;
    document.getElementById('lastRefresh').textContent = new Date().toLocaleTimeString();
    const st = state.status || {};
    document.getElementById('agentState').textContent = state.emergency_stop_active ? 'STOP' : (st.task_running ? 'RUNNING' : 'IDLE');
    document.getElementById('modelName').textContent = (st.model || state.config?.config?.model || '...').slice(0,28);
    const topRoute = st.last_brain_route || null;
    document.getElementById('brainRouteTop').innerHTML = topRoute ? `${esc(topRoute.provider || '-')}` : (st.brain_routing_enabled ? 'auto' : (st.llm_provider || '...'));
    renderPolicyTemplates();
    renderTasks(state.tasks || {});
    renderApprovals(state.approvals || []);
    renderQuestions(state.questions || []);
    renderEvents(state.events || []);
    const ps = state.policy_storage || {};
    document.getElementById('policyStorageInfo').textContent = `file: ${ps.path || 'not configured'} · exists: ${ps.exists ? 'yes' : 'no'} · saved: ${ps.last_saved_at || '-'} · loaded: ${ps.last_loaded_at || '-'}`;
    document.getElementById('statusJson').textContent = JSON.stringify(st,null,2);
    if(!configLoadedOnce){ loadFormFromState(); configLoadedOnce = true; }
  }catch(e){ console.error(e); }
}
async function decideApproval(id, approved){
  const r = document.getElementById('reason_'+id)?.value || '';
  await api('/api/approval',{method:'POST',body:JSON.stringify({id,decision:approved?'approve':'reject',reason:r})});
  await refresh();
}
async function answerQuestion(id){
  const answer = document.getElementById('answer_'+id)?.value || '';
  await api('/api/question',{method:'POST',body:JSON.stringify({id,answer})});
  await refresh();
}
async function quickAnswer(id, answer){
  await api('/api/question',{method:'POST',body:JSON.stringify({id,answer})});
  await refresh();
}
function loadExternalApiSettings(){
  try{
    const s = JSON.parse(localStorage.getItem('sg_external_api') || '{}');
    if(s.endpoint) document.getElementById('extEndpoint').value = s.endpoint;
    if(s.method) document.getElementById('extMethod').value = s.method;
    if(s.headers) document.getElementById('extHeaders').value = s.headers;
    if(s.body) document.getElementById('extBody').value = s.body;
    if(s.model) document.getElementById('extModel').value = s.model;
    if(s.responsePath) document.getElementById('extResponsePath').value = s.responsePath;
    if(s.systemPrompt) document.getElementById('extSystemPrompt').value = s.systemPrompt;
    apiChatHistory = JSON.parse(localStorage.getItem('sg_external_chat') || '[]');
    renderExternalChat();
  }catch(e){ apiChatHistory = []; }
}
function saveExternalApiSettings(){
  localStorage.setItem('sg_external_api', JSON.stringify({
    endpoint:document.getElementById('extEndpoint').value,
    method:document.getElementById('extMethod').value,
    headers:document.getElementById('extHeaders').value,
    body:document.getElementById('extBody').value,
    model:document.getElementById('extModel').value,
    responsePath:document.getElementById('extResponsePath').value,
    systemPrompt:document.getElementById('extSystemPrompt').value
  }));
}
function setExtPrompt(text){ document.getElementById('extPrompt').value = text; }
function presetOpenAICompatible(){
  document.getElementById('extMethod').value = 'POST';
  document.getElementById('extModel').value = document.getElementById('extModel').value || 'gpt-4o';
  document.getElementById('extHeaders').value = JSON.stringify({Authorization:'Bearer YOUR_API_KEY','Content-Type':'application/json'}, null, 2);
  document.getElementById('extBody').value = JSON.stringify({model:'{{model}}', messages:[{role:'user', content:'__PROMPT__'}]}, null, 2).replace('"__PROMPT__"','{{prompt_json}}');
  document.getElementById('extResponsePath').value = 'choices.0.message.content';
  saveExternalApiSettings();
}
function presetGapGPT(){
  document.getElementById('extEndpoint').value = 'https://api.gapgpt.app/v1/chat/completions';
  document.getElementById('extModel').value = 'gpt-4o';
  presetOpenAICompatible();
  document.getElementById('extEndpoint').value = 'https://api.gapgpt.app/v1/chat/completions';
  saveExternalApiSettings();
}
function saveExternalChat(){ localStorage.setItem('sg_external_chat', JSON.stringify(apiChatHistory.slice(-20))); }
function clearExternalChat(){ apiChatHistory=[]; apiResponseText=''; localStorage.removeItem('sg_external_chat'); renderExternalChat(); document.getElementById('extOutput').textContent='API response...'; }
function renderExternalChat(){
  const el = document.getElementById('extChat'); if(!el) return;
  if(!apiChatHistory.length){ el.innerHTML='<div class="empty">هنوز چتی با API ثبت نشده.</div>'; return; }
  el.innerHTML = apiChatHistory.slice(-8).map(m=>`<div class="item"><div class="item-head"><div class="title">${m.role==='user'?'You':'API'}</div><span class="badge">${esc(m.time||'')}</span></div><pre class="pre">${esc(m.content)}</pre></div>`).join('');
}
function extractJsonPath(obj, path){
  if(!obj || !path) return null;
  let cur = obj;
  for(const part of path.split('.').filter(Boolean)){
    const key = /^\d+$/.test(part) ? Number(part) : part;
    if(cur == null || !(key in cur)) return null;
    cur = cur[key];
  }
  return typeof cur === 'string' ? cur : JSON.stringify(cur,null,2);
}
function buildExternalPrompt(){
  const sys = (document.getElementById('extSystemPrompt').value || '').trim();
  const ctx = (document.getElementById('extContext').value || '').trim();
  const user = (document.getElementById('extPrompt').value || '').trim();
  const history = apiChatHistory.slice(-6).map(m=>`${m.role==='user'?'User':'Assistant'}: ${m.content}`).join('\n\n');
  return `${sys?`Instruction:\n${sys}\n\n`:''}${ctx?`Context / Code:\n${ctx}\n\n`:''}${history?`Recent conversation:\n${history}\n\n`:''}User request:\n${user}`.trim();
}
async function sendExternalPrompt(){
  saveExternalApiSettings();
  const userPrompt = (document.getElementById('extPrompt').value || '').trim();
  if(!userPrompt){ alert('Prompt خالی است'); return; }
  const finalPrompt = buildExternalPrompt();
  const body = {
    endpoint:document.getElementById('extEndpoint').value,
    method:document.getElementById('extMethod').value,
    headers:document.getElementById('extHeaders').value,
    body_template:document.getElementById('extBody').value,
    model:document.getElementById('extModel').value,
    prompt:finalPrompt,
    timeout_sec:120
  };
  document.getElementById('extOutput').textContent = 'Calling external API...';
  apiChatHistory.push({role:'user', content:userPrompt, time:new Date().toLocaleTimeString()});
  renderExternalChat();
  const res = await api('/api/external_prompt',{method:'POST',body:JSON.stringify(body)});
  const extracted = res.ok ? (extractJsonPath(res.json, document.getElementById('extResponsePath').value.trim()) || res.text || JSON.stringify(res.json,null,2) || '') : (res.text || res.error || JSON.stringify(res,null,2));
  apiResponseText = extracted;
  document.getElementById('extOutput').textContent = res.ok ? extracted : ('ERROR:\n'+extracted);
  apiChatHistory.push({role:'assistant', content:extracted, time:new Date().toLocaleTimeString()});
  saveExternalChat();
  renderExternalChat();
}
async function sendApiResponseAsTask(mode='implement'){
  const text = apiResponseText || document.getElementById('extOutput').textContent || '';
  if(!text || text==='API response...'){ alert('اول API را صدا بزن.'); return; }
  const prompt = document.getElementById('extPrompt').value || '';
  const ctx = document.getElementById('extContext').value || '';
  let instruction = '';
  if(mode === 'review'){
    instruction = `فقط بررسی و تحلیل کن. هیچ فایلی را تغییر نده.\n- پاسخ API خارجی را با پروژه مقایسه کن.\n- فایل‌های مرتبط را با search_project/read_file پیدا و بررسی کن.\n- بگو آیا پیشنهاد API قابل اعمال است یا نه.\n- اگر تغییر لازم است، فقط برنامه اجرا و diff پیشنهادی را توضیح بده، اما write/edit/apply_patch انجام نده.`;
  } else if(mode === 'patch'){
    instruction = `اگر پاسخ API شامل unified diff یا patch معتبر است، آن را بررسی کن و با ابزار apply_patch اعمال کن؛ اما فقط بعد از validation و approval داشبورد.\n- اول git_status بگیر.\n- اگر patch ناقص/نامعتبر است، فایل‌های مرتبط را بخوان و از من/ادمین سوال بپرس یا گزارش بده.\n- بعد از اعمال، git_diff بگیر و خلاصه کن.\n- اگر تست مناسب واضح است، قبل از اجرا approval بگیر.`;
  } else {
    instruction = `پاسخ API خارجی را به عنوان پیشنهاد برنامه‌نویسی استفاده کن و آن را امن و کنترل‌شده روی پروژه بررسی و در صورت درست بودن اعمال کن.\nمراحل اجباری:\n1. اول git_status بگیر.\n2. با search_project/list_dir/read_file فایل‌های مرتبط را پیدا و بررسی کن.\n3. کورکورانه به پاسخ API اعتماد نکن؛ آن را با کد واقعی پروژه تطبیق بده.\n4. اگر تغییر لازم است، ترجیحاً apply_patch یا edit_file_multi استفاده کن.\n5. قبل از هر write/edit/apply_patch داشبورد approval می‌گیرد؛ diff/patch باید واضح باشد.\n6. بعد از تغییر، git_diff بگیر و خلاصه تغییرات را بگو.\n7. اگر تست مناسب مشخص است، برای اجرای آن approval بگیر.\n8. اگر اطلاعات کافی نیست، با ask_admin سوال بپرس.`;
  }
  const task = `${instruction}\n\nOriginal user prompt to external API:\n${prompt}\n\nOptional context/code pasted by user:\n${ctx}\n\nExternal API response:\n${text}`;
  const res = await api('/api/task',{method:'POST',body:JSON.stringify({task,source:'external_api_chat_'+mode})});
  if(!res.ok) alert('Task submit error: '+(res.error||JSON.stringify(res)));
  await refresh();
}
async function copyApiResponse(){
  const text = apiResponseText || document.getElementById('extOutput').textContent || '';
  await navigator.clipboard.writeText(text);
}
async function loadInjectFile(){
  const input = document.getElementById('injectFile');
  const file = input.files && input.files[0];
  if(!file){ alert('فایلی انتخاب نشده'); return; }
  const text = await file.text();
  document.getElementById('injectText').value = text;
  document.getElementById('injectOutput').textContent = `Loaded ${file.name} (${text.length} chars)`;
}
function injectPayload(mode){
  const file = document.getElementById('injectFile').files?.[0];
  return {
    mode,
    text:document.getElementById('injectText').value,
    json:document.getElementById('injectText').value,
    namespace:document.getElementById('injectNamespace').value,
    kind:document.getElementById('injectKind').value,
    memory:document.getElementById('injectMemory').checked,
    vector:document.getElementById('injectVector').checked,
    overwrite:document.getElementById('injectOverwrite').checked,
    filename:file ? file.name : undefined,
    source:'dashboard_admin'
  };
}
async function injectTextMode(){
  const res = await api('/api/agent/op',{method:'POST',body:JSON.stringify({operation:'admin_inject',payload:injectPayload('text')})});
  document.getElementById('injectOutput').textContent = JSON.stringify(res,null,2);
  await refresh();
}
async function injectJsonBundle(){
  const res = await api('/api/agent/op',{method:'POST',body:JSON.stringify({operation:'admin_inject',payload:injectPayload('json_bundle')})});
  document.getElementById('injectOutput').textContent = JSON.stringify(res,null,2);
  await refresh();
}
function fillSampleInjection(){
  const sample = {
    memories:[
      {kind:'user_preference', text:'پاسخ‌ها فارسی باشند مگر برای کد یا اصطلاح فنی.'},
      {kind:'workflow_rule', text:'قبل از تغییر فایل‌ها git_status بگیر و diff را برای approval نشان بده.'}
    ],
    intents:[
      {id:'browser.refresh', description:'Refresh active browser page', aliases:['refresh','رفرش','صفحه را تازه کن','ctrl+r'], risk:'low', ambiguous:false, status:'approved'}
    ],
    shortcuts:[
      {name:'refresh', description:'Refresh active page/window', keys:['Ctrl','R'], app:'global', risk:'low', requires_approval:false}
    ],
    skills:[
      {id:'shortcut.refresh', intent:'browser.refresh', description:'Refresh active page using Ctrl+R', executor:'execute_shortcut', args:{name:'refresh'}, safety_level:'fast', risk:'low', status:'approved', confidence:0.85, requires_approval:false}
    ]
  };
  document.getElementById('injectText').value = JSON.stringify(sample,null,2);
}
async function agentOp(operation, payload){ 
  const res = await api('/api/agent/op',{method:'POST',body:JSON.stringify({operation,payload})});
  document.getElementById('opsOutput').textContent = JSON.stringify(res,null,2);
  if(operation === 'observe_desktop_logs' || operation === 'get_desktop_state') renderDesktopState(res);
  return res;
}
async function vectorSearch(){
  await agentOp('search_vector_memory', {query:document.getElementById('vecQuery').value, namespace:document.getElementById('vecNamespace').value, limit:8});
}
async function monthlyInject(){
  await agentOp('monthly_inject_memory', {namespace:document.getElementById('vecNamespace').value || 'monthly_experience'});
}
async function registerDesktopLog(){
  await agentOp('register_desktop_log', {path:document.getElementById('desktopLogPath').value});
}
async function observeDesktopLogs(){
  await agentOp('observe_desktop_logs', {});
}
async function getDesktopState(){
  await agentOp('get_desktop_state', {limit:30});
}
async function registerShortcut(){
  await agentOp('register_shortcut', {
    name:document.getElementById('shortcutName').value,
    description:document.getElementById('shortcutDescription').value,
    keys:(document.getElementById('shortcutKeys').value || '').split('+').map(x=>x.trim()).filter(Boolean),
    app:'global', risk:'low', requires_approval:false
  });
}
async function suggestShortcut(){
  await agentOp('suggest_shortcut', {intent:document.getElementById('shortcutIntent').value});
}
async function executeShortcut(dryRun){
  const name = document.getElementById('shortcutName').value;
  if(!name){ alert('Shortcut name را وارد کن یا اول shortcut ثبت کن.'); return; }
  if(!dryRun && !confirm(`Execute shortcut ${name}?`)) return;
  await agentOp('execute_shortcut', {name, dry_run:dryRun});
}
async function reflexOp(operation, payload){
  const res = await api('/api/agent/op',{method:'POST',body:JSON.stringify({operation,payload})});
  document.getElementById('reflexOutput').textContent = JSON.stringify(res,null,2);
  return res;
}
async function reflexResolve(){
  await reflexOp('reflex_resolve', {command:document.getElementById('reflexCommand').value});
}
async function reflexExecute(dryRun){
  const command = document.getElementById('reflexCommand').value;
  if(!command){ alert('دستور reflex خالی است'); return; }
  if(!dryRun && !confirm(`Execute reflex command: ${command}?`)) return;
  await reflexOp('reflex_execute', {command, dry_run:dryRun});
  await refresh();
}
async function skillList(){
  await reflexOp('skill_list', {});
}
async function promoteSkill(status){
  const skill_id = document.getElementById('promoteSkillId').value;
  if(!skill_id){ alert('skill id را وارد کن'); return; }
  await reflexOp('skill_promote', {skill_id, status});
}
async function eventCounts(){
  await reflexOp('event_counts', {});
}
async function dailyDistill(apply){
  if(apply && !confirm('Distill + Apply می‌تواند بعضی skillهای کم‌ریسک را trusted کند. ادامه؟')) return;
  await reflexOp('daily_distill', {apply, inject_vector:true});
  await refresh();
}
function scaffoldPayload(dryRun){
  return {
    template:document.getElementById('scaffoldTemplate').value,
    project_name:document.getElementById('scaffoldProjectName').value,
    description:document.getElementById('scaffoldDescription').value,
    overwrite:document.getElementById('scaffoldOverwrite').checked,
    dry_run:dryRun
  };
}
async function scaffoldProject(dryRun){
  const payload = scaffoldPayload(dryRun);
  if(!payload.project_name){ alert('Project folder name خالی است'); return; }
  if(!dryRun && !confirm(`Create project ${payload.project_name}?`)) return;
  const res = await api('/api/agent/op',{method:'POST',body:JSON.stringify({operation:'create_project',payload})});
  document.getElementById('scaffoldOutput').textContent = JSON.stringify(res,null,2);
  await refresh();
}
async function submitScaffoldAsTask(){
  const p = scaffoldPayload(false);
  const task = `یک پروژه جدید با این مشخصات بساز و در صورت نیاز آن را سفارشی کن. قبل از اعمال فایل‌ها approval بگیر.\ntemplate=${p.template}\nproject_name=${p.project_name}\ndescription=${p.description}`;
  const res = await api('/api/task',{method:'POST',body:JSON.stringify({task,source:'project_factory'})});
  if(!res.ok) alert('Task submit error: '+(res.error||JSON.stringify(res)));
  await refresh();
}
async function submitTask(){ 
  const el = document.getElementById('newTask');
  const task = (el.value || '').trim();
  if(!task){ alert('Task خالی است'); return; }
  const res = await api('/api/task',{method:'POST',body:JSON.stringify({task,source:'dashboard'})});
  if(!res.ok) alert('Task submit error: '+(res.error||JSON.stringify(res)));
  else el.value = '';
  await refresh();
}
async function controlTask(action,id=null){
  if(action==='emergency_stop' && !confirm('Emergency Stop فعال شود؟ همه approvalهای pending رد می‌شوند و policy به read-only می‌رود.')) return;
  const res = await api('/api/task/control',{method:'POST',body:JSON.stringify({action,id})});
  if(!res.ok) alert('Task control error: '+(res.error||JSON.stringify(res)));
  await refresh();
}
async function applyTemplate(merge){
  const id = document.getElementById('policyTemplate').value;
  const res = await api('/api/policy/template',{method:'POST',body:JSON.stringify({id,merge})});
  if(!res.ok) alert('Template error: '+(res.error||JSON.stringify(res)));
  configLoadedOnce=false;
  await refresh();
}
async function savePolicy(){
  const res = await api('/api/policy/save',{method:'POST',body:JSON.stringify({})});
  if(!res.ok) alert('Save policy error: '+(res.error||JSON.stringify(res)));
  await refresh();
}
async function loadPolicy(){
  const res = await api('/api/policy/load',{method:'POST',body:JSON.stringify({})});
  if(!res.ok) alert('Load policy error: '+(res.error||JSON.stringify(res)));
  configLoadedOnce=false;
  await refresh();
}
async function resetPolicy(deleteFile=false){
  const res = await api('/api/policy/reset',{method:'POST',body:JSON.stringify({delete_file:deleteFile})});
  if(!res.ok) alert('Reset policy error: '+(res.error||JSON.stringify(res)));
  configLoadedOnce=false;
  await refresh();
}
async function savePermissions(){
  await api('/api/permissions',{method:'POST',body:JSON.stringify({
    read_only_mode:document.getElementById('readOnly').checked,
    auto_approve_writes:document.getElementById('autoWrites').checked,
    auto_approve_commands:document.getElementById('autoCommands').checked,
    auto_answer_questions:document.getElementById('autoQuestions').checked,
    auto_question_answer:document.getElementById('autoQuestionAnswer').value,
    allowed_write_globs:textToList('allowedWriteGlobs'),
    denied_write_globs:textToList('deniedWriteGlobs'),
    reject_unmatched_writes:document.getElementById('rejectUnmatchedWrites').checked,
    allowed_command_globs:textToList('allowedCommandGlobs'),
    denied_command_fragments:textToList('deniedCommandFragments'),
    reject_unmatched_commands:document.getElementById('rejectUnmatchedCommands').checked
  })});
  configLoadedOnce=false;
  await refresh();
}
async function saveConfig(){
  const body = {
    llm_provider:document.getElementById('cfg_llm_provider').value,
    model:document.getElementById('cfg_model').value,
    ollama_url:document.getElementById('cfg_ollama_url').value,
    openai_base_url:document.getElementById('cfg_openai_base_url').value,
    openai_api_key_env:document.getElementById('cfg_openai_api_key_env').value,
    openai_max_tokens:Number(document.getElementById('cfg_openai_max_tokens').value),
    openai_timeout_sec:Number(document.getElementById('cfg_openai_timeout_sec').value),
    brain_routing_enabled:document.getElementById('cfg_brain_routing_enabled').checked,
    brain_routing_simple_provider:document.getElementById('cfg_brain_routing_simple_provider').value,
    brain_routing_complex_provider:document.getElementById('cfg_brain_routing_complex_provider').value,
    brain_routing_sensitive_provider:document.getElementById('cfg_brain_routing_sensitive_provider').value,
    brain_routing_allow_api_for_sensitive:document.getElementById('cfg_brain_routing_allow_api_for_sensitive').checked,
    enable_shortcut_execution:document.getElementById('cfg_enable_shortcut_execution').checked,
    require_approval_for_shortcuts:document.getElementById('cfg_require_approval_for_shortcuts').checked,
    shortcut_execution_dry_run:document.getElementById('cfg_shortcut_execution_dry_run').checked,
    allow_shortcut_without_desktop_state:document.getElementById('cfg_allow_shortcut_without_desktop_state').checked,
    min_desktop_confidence_for_shortcut:Number(document.getElementById('cfg_min_desktop_confidence_for_shortcut').value),
    shortcut_execution_delay_ms:Number(document.getElementById('cfg_shortcut_execution_delay_ms').value),
    temperature:Number(document.getElementById('cfg_temperature').value),
    num_ctx:Number(document.getElementById('cfg_num_ctx').value),
    max_steps:Number(document.getElementById('cfg_max_steps').value),
    command_timeout_sec:Number(document.getElementById('cfg_command_timeout_sec').value),
    max_file_read_chars:Number(document.getElementById('cfg_max_file_read_chars').value),
    require_approval_for_writes:document.getElementById('cfg_require_approval_for_writes').checked,
    require_approval_for_commands:document.getElementById('cfg_require_approval_for_commands').checked,
    mask_secrets:document.getElementById('cfg_mask_secrets').checked,
    mask_secrets_in_memory:document.getElementById('cfg_mask_secrets_in_memory').checked,
    block_sensitive_file_reads:document.getElementById('cfg_block_sensitive_file_reads').checked
  };
  const res = await api('/api/config',{method:'POST',body:JSON.stringify(body)});
  if(!res.ok) alert('Config error: '+(res.error||JSON.stringify(res)));
  configLoadedOnce=false;
  await refresh();
}
loadExternalApiSettings();
refresh(); setInterval(refresh,1500);
</script>
</body>
</html>
"""
```


## `security.py`

```python
"""
Security helpers for SkyGround Local Agent.

Focus:
- Best-effort secret detection/masking before data is shown in dashboard/logs/memory/LLM context.
- Sensitive path heuristics.

No external dependencies.
"""

from __future__ import annotations

import re
from pathlib import Path
from typing import Any, Dict, List, Tuple


SECRET_PLACEHOLDER = "[SECRET_MASKED]"


SENSITIVE_FILE_GLOBS = (
    ".env",
    ".env.*",
    "**/.env",
    "**/.env.*",
    "*.pem",
    "*.key",
    "*.p12",
    "*.pfx",
    "id_rsa",
    "id_dsa",
    "id_ecdsa",
    "id_ed25519",
    "**/secrets/**",
    "**/secret/**",
    "**/credentials/**",
    "**/.aws/credentials",
    "**/.ssh/**",
)


# (name, regex, replacement function)
# Keep patterns intentionally broad but conservative enough for common tokens.
SECRET_PATTERNS: List[Tuple[str, re.Pattern[str]]] = [
    (
        "private_key_block",
        re.compile(
            r"-----BEGIN [A-Z0-9 ]*PRIVATE KEY-----[\s\S]*?-----END [A-Z0-9 ]*PRIVATE KEY-----",
            re.MULTILINE,
        ),
    ),
    ("aws_access_key", re.compile(r"\bAKIA[0-9A-Z]{16}\b")),
    ("github_token", re.compile(r"\bgh[pousr]_[A-Za-z0-9_]{20,}\b")),
    ("openai_key", re.compile(r"\bsk-[A-Za-z0-9_-]{20,}\b")),
    ("google_api_key", re.compile(r"\bAIza[0-9A-Za-z_\-]{20,}\b")),
    ("slack_token", re.compile(r"\bxox[baprs]-[A-Za-z0-9-]{10,}\b")),
    ("jwt", re.compile(r"\beyJ[A-Za-z0-9_\-]{10,}\.[A-Za-z0-9_\-]{10,}\.[A-Za-z0-9_\-]{10,}\b")),
    (
        "key_value_secret",
        re.compile(
            r"(?im)^([+\- ]?\s*(?:[A-Z0-9_\-]*?(?:API[_-]?KEY|TOKEN|SECRET|PASSWORD|PASSWD|PWD|PRIVATE[_-]?KEY|ACCESS[_-]?KEY|AUTH|CLIENT[_-]?SECRET|DATABASE_URL|DB_URL|CONNECTION_STRING)[A-Z0-9_\-]*?)\s*[=:]\s*)([^\s#,'\"]{6,}|['\"][^'\"]{6,}['\"])",
        ),
    ),
    (
        "json_secret",
        re.compile(
            r"(?i)(\"(?:api[_-]?key|token|secret|password|client[_-]?secret|access[_-]?key|authorization|auth)\"\s*:\s*\")(.*?)(\")"
        ),
    ),
    (
        "bearer_token",
        re.compile(r"(?i)(bearer\s+)([A-Za-z0-9._\-+/=]{12,})"),
    ),
    (
        "basic_auth_url",
        re.compile(r"(?i)(https?://)([^:/\s]+):([^@/\s]+)@"),
    ),
]


def _short_mask(value: str, keep: int = 4) -> str:
    raw = value.strip("'\"")
    quote_prefix = value[:1] if value[:1] in {"'", '"'} else ""
    quote_suffix = value[-1:] if value[-1:] in {"'", '"'} else ""
    if len(raw) <= keep:
        masked = SECRET_PLACEHOLDER
    else:
        masked = raw[:keep] + "…" + SECRET_PLACEHOLDER
    return quote_prefix + masked + quote_suffix


def mask_secrets(text: str) -> str:
    """Best-effort masking of common secrets in text."""
    if not text:
        return text
    masked = text

    # Blocks and simple full-value tokens.
    for name, pattern in SECRET_PATTERNS:
        if name in {"key_value_secret", "json_secret", "bearer_token", "basic_auth_url"}:
            continue
        masked = pattern.sub(lambda m: _short_mask(m.group(0)), masked)

    # Bearer token first, so `Authorization: Bearer TOKEN` does not leak after key/value masking.
    bearer = dict(SECRET_PATTERNS)["bearer_token"]
    masked = bearer.sub(lambda m: m.group(1) + _short_mask(m.group(2)), masked)

    # URL basic auth: preserve username, mask password.
    basic = dict(SECRET_PATTERNS)["basic_auth_url"]
    masked = basic.sub(lambda m: m.group(1) + m.group(2) + ":" + SECRET_PLACEHOLDER + "@", masked)

    # KEY=value style: preserve key and operator.
    key_value = dict(SECRET_PATTERNS)["key_value_secret"]
    masked = key_value.sub(lambda m: m.group(1) + _short_mask(m.group(2)), masked)

    # JSON style: preserve key and quotes.
    json_secret = dict(SECRET_PATTERNS)["json_secret"]
    masked = json_secret.sub(lambda m: m.group(1) + _short_mask(m.group(2)) + m.group(3), masked)

    return masked


def find_secrets(text: str) -> List[Dict[str, Any]]:
    """Return approximate detections without exposing full values."""
    findings: List[Dict[str, Any]] = []
    if not text:
        return findings
    for name, pattern in SECRET_PATTERNS:
        for match in pattern.finditer(text):
            findings.append(
                {
                    "type": name,
                    "start": match.start(),
                    "end": match.end(),
                    "preview": _short_mask(match.group(0)[:80]),
                }
            )
            if len(findings) >= 100:
                return findings
    return findings


def _sensitive_key(key: str) -> bool:
    return bool(re.search(r"(?i)(api[_-]?key|token|secret|password|passwd|pwd|authorization|auth|private[_-]?key|access[_-]?key|client[_-]?secret|database_url|db_url|connection_string)", key))


def sanitize_for_display(value: Any, max_string: int | None = None) -> Any:
    """Recursively mask secrets before sending data to logs/dashboard/memory."""
    if isinstance(value, str):
        s = mask_secrets(value)
        if max_string is not None and len(s) > max_string:
            s = s[:max_string] + f"\n... [truncated {len(s) - max_string} chars]"
        return s
    if isinstance(value, list):
        return [sanitize_for_display(v, max_string=max_string) for v in value]
    if isinstance(value, tuple):
        return tuple(sanitize_for_display(v, max_string=max_string) for v in value)
    if isinstance(value, dict):
        safe: Dict[str, Any] = {}
        for k, v in value.items():
            key = str(k)
            if _sensitive_key(key) and isinstance(v, str):
                safe[key] = _short_mask(v)
            else:
                safe[key] = sanitize_for_display(v, max_string=max_string)
        return safe
    return value


def looks_sensitive_path(path: str, extra_globs: Tuple[str, ...] = ()) -> bool:
    import fnmatch

    normalized = str(path).replace("\\", "/")
    name = Path(normalized).name
    for pattern in (*SENSITIVE_FILE_GLOBS, *extra_globs):
        p = pattern.replace("\\", "/")
        if fnmatch.fnmatch(normalized, p) or fnmatch.fnmatch(name, p):
            return True
    return False
```


## `text_intelligence.py`

```python
"""
Unicode-based text intelligence for Persian/Latin mixed environments.

Goals:
- Detect Persian/Arabic-script vs Latin-script text using Unicode ranges.
- Infer direction: rtl, ltr, mixed, neutral.
- Split text into script runs for UI/log handling.
- Avoid external dependencies.
"""

from __future__ import annotations

import dataclasses
import unicodedata
from typing import Dict, List


@dataclasses.dataclass(frozen=True)
class TextProfile:
    length: int
    letters: int
    persian_arabic_letters: int
    latin_letters: int
    digits: int
    persian_digits: int
    latin_digits: int
    other_letters: int
    rtl_strong: int
    ltr_strong: int
    primary_script: str  # persian_arabic | latin | mixed | neutral | other
    direction: str       # rtl | ltr | mixed | neutral
    persian_ratio: float
    latin_ratio: float
    is_mixed: bool

    def to_dict(self) -> Dict[str, object]:
        return dataclasses.asdict(self)


# Arabic block includes Persian letters. Additional Arabic supplement/extended blocks included.
def is_arabic_script_char(ch: str) -> bool:
    cp = ord(ch)
    return (
        0x0600 <= cp <= 0x06FF
        or 0x0750 <= cp <= 0x077F
        or 0x08A0 <= cp <= 0x08FF
        or 0xFB50 <= cp <= 0xFDFF
        or 0xFE70 <= cp <= 0xFEFF
    )


def is_persian_digit(ch: str) -> bool:
    cp = ord(ch)
    return 0x06F0 <= cp <= 0x06F9 or 0x0660 <= cp <= 0x0669


def is_latin_char(ch: str) -> bool:
    cp = ord(ch)
    return (0x0041 <= cp <= 0x005A) or (0x0061 <= cp <= 0x007A) or (0x00C0 <= cp <= 0x024F)


def unicode_direction(ch: str) -> str:
    bidi = unicodedata.bidirectional(ch)
    if bidi in {"R", "AL", "AN"}:
        return "rtl"
    if bidi in {"L", "EN"}:
        return "ltr"
    return "neutral"


def char_script(ch: str) -> str:
    if is_arabic_script_char(ch):
        if ch.isalpha() or is_persian_digit(ch):
            return "persian_arabic"
        return "neutral"
    if is_latin_char(ch):
        return "latin"
    if ch.isdigit():
        return "digit"
    if ch.isalpha():
        return "other"
    return "neutral"


def detect_text_profile(text: str) -> TextProfile:
    length = len(text or "")
    letters = 0
    persian_arabic_letters = 0
    latin_letters = 0
    other_letters = 0
    digits = 0
    persian_digits = 0
    latin_digits = 0
    rtl_strong = 0
    ltr_strong = 0

    for ch in text or "":
        direction = unicode_direction(ch)
        if direction == "rtl":
            rtl_strong += 1
        elif direction == "ltr":
            ltr_strong += 1

        if ch.isdigit():
            digits += 1
            if is_persian_digit(ch):
                persian_digits += 1
            elif "0" <= ch <= "9":
                latin_digits += 1

        if ch.isalpha():
            letters += 1
            if is_arabic_script_char(ch):
                persian_arabic_letters += 1
            elif is_latin_char(ch):
                latin_letters += 1
            else:
                other_letters += 1

    persian_ratio = persian_arabic_letters / letters if letters else 0.0
    latin_ratio = latin_letters / letters if letters else 0.0

    if letters == 0:
        primary_script = "neutral"
    elif persian_ratio >= 0.75:
        primary_script = "persian_arabic"
    elif latin_ratio >= 0.75:
        primary_script = "latin"
    elif persian_arabic_letters and latin_letters:
        primary_script = "mixed"
    else:
        primary_script = "other"

    if rtl_strong == 0 and ltr_strong == 0:
        direction = "neutral"
    elif rtl_strong and ltr_strong:
        # Treat as mixed if both sides are meaningful, not just one digit/word.
        smaller = min(rtl_strong, ltr_strong)
        larger = max(rtl_strong, ltr_strong)
        direction = "mixed" if smaller / larger >= 0.15 else ("rtl" if rtl_strong > ltr_strong else "ltr")
    else:
        direction = "rtl" if rtl_strong else "ltr"

    return TextProfile(
        length=length,
        letters=letters,
        persian_arabic_letters=persian_arabic_letters,
        latin_letters=latin_letters,
        digits=digits,
        persian_digits=persian_digits,
        latin_digits=latin_digits,
        other_letters=other_letters,
        rtl_strong=rtl_strong,
        ltr_strong=ltr_strong,
        primary_script=primary_script,
        direction=direction,
        persian_ratio=round(persian_ratio, 4),
        latin_ratio=round(latin_ratio, 4),
        is_mixed=primary_script == "mixed" or direction == "mixed",
    )


def split_script_runs(text: str) -> List[Dict[str, object]]:
    """Split text into consecutive script runs: Persian/Arabic, Latin, digit, neutral, other."""
    runs: List[Dict[str, object]] = []
    if not text:
        return runs
    current_script = char_script(text[0])
    buf = [text[0]]
    start = 0
    for idx, ch in enumerate(text[1:], start=1):
        script = char_script(ch)
        # Attach whitespace/punctuation to current run for readability.
        comparable = current_script if script == "neutral" else script
        if comparable == current_script or current_script == "neutral":
            if current_script == "neutral" and script != "neutral":
                current_script = script
            buf.append(ch)
            continue
        segment = "".join(buf)
        runs.append({"script": current_script, "direction": detect_text_profile(segment).direction, "start": start, "end": idx, "text": segment})
        start = idx
        current_script = script
        buf = [ch]
    segment = "".join(buf)
    runs.append({"script": current_script, "direction": detect_text_profile(segment).direction, "start": start, "end": len(text), "text": segment})
    return runs


def direction_hint(text: str) -> str:
    return detect_text_profile(text).direction
```


## `vector_memory.py`

```python
"""
Lightweight local vector memory for SkyGround.

This is a dependency-free hashed vector store. It is not as strong as a real embedding
model, but it gives us a stable interface for "monthly injection into vector brain".
Later it can be replaced with Ollama embeddings, sentence-transformers, bge, etc.
"""

from __future__ import annotations

import dataclasses
import datetime as dt
import hashlib
import json
import math
import re
import sqlite3
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple

from security import sanitize_for_display
from text_intelligence import detect_text_profile


TOKEN_RE = re.compile(r"[\w\u0600-\u06FF\u0750-\u077F\u08A0-\u08FF]+", re.UNICODE)


@dataclasses.dataclass(frozen=True)
class VectorSearchResult:
    id: int
    score: float
    created_at: str
    namespace: str
    source: str
    text: str
    metadata: Dict[str, Any]


class HashingVectorizer:
    def __init__(self, dimensions: int = 384):
        self.dimensions = dimensions

    def tokenize(self, text: str) -> List[str]:
        return [t.lower() for t in TOKEN_RE.findall(text or "") if len(t.strip()) >= 2]

    def embed_sparse(self, text: str) -> Dict[int, float]:
        vec: Dict[int, float] = {}
        for token in self.tokenize(text):
            digest = hashlib.blake2b(token.encode("utf-8"), digest_size=8).digest()
            n = int.from_bytes(digest, "big")
            idx = n % self.dimensions
            sign = 1.0 if (n >> 63) == 0 else -1.0
            vec[idx] = vec.get(idx, 0.0) + sign
        norm = math.sqrt(sum(v * v for v in vec.values()))
        if norm > 0:
            vec = {k: v / norm for k, v in vec.items()}
        return vec

    @staticmethod
    def cosine_sparse(a: Dict[int, float], b: Dict[int, float]) -> float:
        if not a or not b:
            return 0.0
        if len(a) > len(b):
            a, b = b, a
        return float(sum(v * b.get(k, 0.0) for k, v in a.items()))


def _encode_vec(vec: Dict[int, float]) -> str:
    return json.dumps({str(k): round(v, 6) for k, v in vec.items()}, separators=(",", ":"))


def _decode_vec(raw: str) -> Dict[int, float]:
    obj = json.loads(raw or "{}")
    return {int(k): float(v) for k, v in obj.items()}


class VectorMemoryStore:
    def __init__(self, db_path: Path, dimensions: int = 384):
        self.db_path = db_path
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self.conn = sqlite3.connect(str(self.db_path), check_same_thread=False)
        self.vectorizer = HashingVectorizer(dimensions=dimensions)
        self.conn.execute(
            """
            CREATE TABLE IF NOT EXISTS vector_memories (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                created_at TEXT NOT NULL,
                namespace TEXT NOT NULL,
                source TEXT NOT NULL,
                text TEXT NOT NULL,
                metadata_json TEXT NOT NULL,
                vector_json TEXT NOT NULL
            )
            """
        )
        self.conn.execute("CREATE INDEX IF NOT EXISTS idx_vector_memories_namespace ON vector_memories(namespace)")
        self.conn.commit()

    def add(self, text: str, namespace: str = "general", source: str = "manual", metadata: Optional[Dict[str, Any]] = None) -> int:
        safe_text = sanitize_for_display(text or "")
        safe_metadata = sanitize_for_display(metadata or {})
        profile = detect_text_profile(safe_text).to_dict()
        merged_metadata = {**safe_metadata, "text_profile": profile}
        vector = self.vectorizer.embed_sparse(safe_text)
        created_at = dt.datetime.now(dt.timezone.utc).isoformat()
        cur = self.conn.execute(
            "INSERT INTO vector_memories(created_at, namespace, source, text, metadata_json, vector_json) VALUES (?, ?, ?, ?, ?, ?)",
            (created_at, namespace, source, safe_text, json.dumps(merged_metadata, ensure_ascii=False), _encode_vec(vector)),
        )
        self.conn.commit()
        return int(cur.lastrowid)

    def search(self, query: str, namespace: Optional[str] = None, limit: int = 8) -> List[VectorSearchResult]:
        query_vec = self.vectorizer.embed_sparse(query)
        if namespace:
            rows = self.conn.execute(
                "SELECT id, created_at, namespace, source, text, metadata_json, vector_json FROM vector_memories WHERE namespace = ? ORDER BY id DESC LIMIT 2000",
                (namespace,),
            ).fetchall()
        else:
            rows = self.conn.execute(
                "SELECT id, created_at, namespace, source, text, metadata_json, vector_json FROM vector_memories ORDER BY id DESC LIMIT 2000"
            ).fetchall()
        scored: List[VectorSearchResult] = []
        for r in rows:
            score = self.vectorizer.cosine_sparse(query_vec, _decode_vec(r[6]))
            if score <= 0:
                continue
            scored.append(
                VectorSearchResult(
                    id=int(r[0]),
                    score=round(score, 4),
                    created_at=str(r[1]),
                    namespace=str(r[2]),
                    source=str(r[3]),
                    text=str(r[4]),
                    metadata=json.loads(r[5] or "{}"),
                )
            )
        scored.sort(key=lambda x: x.score, reverse=True)
        return scored[:limit]

    def count(self, namespace: Optional[str] = None) -> int:
        if namespace:
            row = self.conn.execute("SELECT COUNT(*) FROM vector_memories WHERE namespace = ?", (namespace,)).fetchone()
        else:
            row = self.conn.execute("SELECT COUNT(*) FROM vector_memories").fetchone()
        return int(row[0] or 0)

    def monthly_inject_from_rows(self, rows: Iterable[Dict[str, Any]], month: Optional[str] = None, namespace: str = "monthly_experience") -> Dict[str, Any]:
        """Inject memory rows into vector brain. month format: YYYY-MM; defaults current UTC month."""
        month = month or dt.datetime.now(dt.timezone.utc).strftime("%Y-%m")
        injected = 0
        skipped = 0
        for row in rows:
            created = str(row.get("created_at", ""))
            if month and not created.startswith(month):
                # Also accept local memory timestamps that may include date only; skip otherwise.
                skipped += 1
                continue
            text = str(row.get("text", "")).strip()
            if not text:
                skipped += 1
                continue
            metadata = {"memory_id": row.get("id"), "kind": row.get("kind"), "created_at": created, "month": month, "metadata": row.get("metadata", {})}
            self.add(text=text, namespace=namespace, source="monthly_injection", metadata=metadata)
            injected += 1
        return {"ok": True, "month": month, "namespace": namespace, "injected": injected, "skipped": skipped, "total_vectors": self.count(namespace)}
```


## `desktop_io.py`

```python
"""
Safe desktop I/O scaffolding for SkyGround.

Principle requested by user:
- Eye/hand should rely on shortcuts and log files as the normal path.
- Screenshots are exceptional and should require explicit approval/policy later.
- Agent learns stable navigation patterns from logs and stores them as experience.

This module is intentionally conservative: it does not click/type or take screenshots.
It provides:
- shortcut registry
- log registry
- log-tail observation
- current desktop/app state inference
- state timeline
"""

from __future__ import annotations

import dataclasses
import datetime as dt
import json
import platform
import re
import subprocess
from pathlib import Path
from typing import Any, Dict, List, Optional

from security import sanitize_for_display
from text_intelligence import detect_text_profile


KEY_VALUE_RE = re.compile(r"(?P<key>\b[A-Za-z_][A-Za-z0-9_.-]*)=(?P<value>\"[^\"]*\"|'[^']*'|[^\s]+)")

SCREEN_KEYS = {"screen", "view", "page", "window", "activity", "component"}
ROUTE_KEYS = {"route", "path", "url", "uri", "location", "href"}
STATE_KEYS = {"state", "status", "mode", "phase"}
ACTION_KEYS = {"action", "event", "intent", "command"}
RESULT_KEYS = {"result", "outcome", "level", "severity"}
TITLE_KEYS = {"title", "caption", "heading"}
ERROR_KEYS = {"error", "exception", "message", "msg"}


@dataclasses.dataclass
class ShortcutAction:
    name: str
    description: str
    keys: List[str]
    app: str = "global"
    risk: str = "low"  # low | medium | high
    requires_approval: bool = False


@dataclasses.dataclass
class DesktopObservation:
    created_at: str
    source: str
    app: str
    location: str
    summary: str
    raw_tail: str
    text_profile: Dict[str, Any]
    markers: Dict[str, str]
    confidence: float


class DesktopIORegistry:
    def __init__(self, root: Path, state_path: Optional[Path] = None):
        self.root = root.resolve()
        self.state_path = state_path or (self.root / ".sg_agent" / "desktop_state.json")
        self.state_path.parent.mkdir(parents=True, exist_ok=True)
        self.shortcuts: Dict[str, ShortcutAction] = {}
        self.log_paths: List[Path] = []
        self._load_state()

    def _load_state(self) -> None:
        if not self.state_path.exists():
            self.state: Dict[str, Any] = {"shortcuts": {}, "log_paths": [], "observations": [], "current_by_app": {}}
            return
        try:
            self.state = json.loads(self.state_path.read_text(encoding="utf-8"))
            self.state.setdefault("shortcuts", {})
            self.state.setdefault("log_paths", [])
            self.state.setdefault("observations", [])
            self.state.setdefault("current_by_app", {})
            for name, data in self.state.get("shortcuts", {}).items():
                self.shortcuts[name] = ShortcutAction(**data)
            self.log_paths = [Path(p) for p in self.state.get("log_paths", [])]
        except Exception:
            self.state = {"shortcuts": {}, "log_paths": [], "observations": [], "current_by_app": {}}

    def save(self) -> None:
        self.state["shortcuts"] = {name: dataclasses.asdict(action) for name, action in self.shortcuts.items()}
        self.state["log_paths"] = [str(p) for p in self.log_paths]
        self.state.setdefault("observations", [])
        self.state.setdefault("current_by_app", {})
        tmp = self.state_path.with_name(f".{self.state_path.name}.tmp")
        tmp.write_text(json.dumps(self.state, ensure_ascii=False, indent=2), encoding="utf-8")
        tmp.replace(self.state_path)

    def register_shortcut(self, action: ShortcutAction) -> Dict[str, Any]:
        self.shortcuts[action.name] = action
        self.save()
        return {"ok": True, "shortcut": dataclasses.asdict(action)}

    def execute_shortcut(
        self,
        name: str,
        dry_run: bool = False,
        method: str = "powershell_sendkeys",
        delay_ms: int = 120,
    ) -> Dict[str, Any]:
        """Execute a registered shortcut.

        Conservative by design:
        - Only registered shortcut names can be executed.
        - No free typing/clicking is supported.
        - On non-Windows, only dry_run is supported for now.
        """
        name = (name or "").strip()
        if not name:
            return {"ok": False, "error": "shortcut name cannot be empty"}
        action = self.shortcuts.get(name)
        if not action:
            return {"ok": False, "error": f"shortcut not registered: {name}", "known_shortcuts": list(self.shortcuts.keys())}
        sendkeys = self._to_windows_sendkeys(action.keys)
        execution = {
            "created_at": dt.datetime.now(dt.timezone.utc).isoformat(),
            "name": name,
            "shortcut": dataclasses.asdict(action),
            "method": method,
            "dry_run": dry_run,
            "sendkeys": sendkeys,
            "platform": platform.system(),
        }
        if dry_run:
            execution.update({"ok": True, "message": "dry run only; no keys sent"})
            self._record_execution(execution)
            return execution
        if platform.system().lower() != "windows":
            execution.update({"ok": False, "error": "actual shortcut execution is currently supported only on Windows; use dry_run elsewhere"})
            self._record_execution(execution)
            return execution
        if method != "powershell_sendkeys":
            execution.update({"ok": False, "error": f"unsupported shortcut method: {method}"})
            self._record_execution(execution)
            return execution
        ps_sendkeys = sendkeys.replace("'", "''")
        ps = (
            "$wshell = New-Object -ComObject WScript.Shell; "
            f"Start-Sleep -Milliseconds {max(0, int(delay_ms))}; "
            f"$wshell.SendKeys('{ps_sendkeys}')"
        )
        try:
            proc = subprocess.run(
                ["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", ps],
                capture_output=True,
                text=True,
                timeout=8,
            )
            execution.update(
                {
                    "ok": proc.returncode == 0,
                    "returncode": proc.returncode,
                    "stdout": sanitize_for_display(proc.stdout, max_string=2000),
                    "stderr": sanitize_for_display(proc.stderr, max_string=2000),
                }
            )
        except Exception as e:
            execution.update({"ok": False, "error": str(e)})
        self._record_execution(execution)
        return execution

    def _record_execution(self, execution: Dict[str, Any]) -> None:
        self.state.setdefault("executions", []).append(execution)
        self.state["executions"] = self.state.get("executions", [])[-200:]
        self.save()

    def _to_windows_sendkeys(self, keys: List[str]) -> str:
        modifiers = []
        normals = []
        for raw in keys:
            key = str(raw).strip()
            low = key.lower()
            if low in {"ctrl", "control"}:
                modifiers.append("^")
            elif low == "alt":
                modifiers.append("%")
            elif low == "shift":
                modifiers.append("+")
            elif low in {"win", "windows", "meta", "cmd", "command"}:
                # WScript SendKeys does not reliably support Windows key. Keep explicit.
                normals.append("{WIN}")
            else:
                normals.append(self._normal_key_to_sendkeys(key))
        if not normals:
            return "".join(modifiers)
        # Common shortcut form: modifiers + final key. If multiple normal keys exist, send sequentially.
        first = "".join(modifiers) + normals[0]
        return first + "".join(normals[1:])

    def _normal_key_to_sendkeys(self, key: str) -> str:
        low = key.lower()
        special = {
            "enter": "{ENTER}",
            "return": "{ENTER}",
            "tab": "{TAB}",
            "esc": "{ESC}",
            "escape": "{ESC}",
            "space": " ",
            "backspace": "{BACKSPACE}",
            "delete": "{DELETE}",
            "del": "{DELETE}",
            "insert": "{INSERT}",
            "home": "{HOME}",
            "end": "{END}",
            "pageup": "{PGUP}",
            "pgup": "{PGUP}",
            "pagedown": "{PGDN}",
            "pgdn": "{PGDN}",
            "up": "{UP}",
            "down": "{DOWN}",
            "left": "{LEFT}",
            "right": "{RIGHT}",
        }
        if low in special:
            return special[low]
        if re.fullmatch(r"f([1-9]|1[0-9]|2[0-4])", low):
            return "{" + low.upper() + "}"
        if len(key) == 1:
            return key.lower()
        # For unknown named keys, try SendKeys named-key syntax.
        return "{" + key.upper() + "}"

    def register_log_path(self, path: str) -> Dict[str, Any]:
        p = Path(path).expanduser().resolve()
        # Log files can be outside workspace because many apps write logs elsewhere.
        # We only read tails and sanitize; future policy can restrict this.
        if p not in self.log_paths:
            self.log_paths.append(p)
        self.save()
        return {"ok": True, "log_path": str(p), "exists": p.exists()}

    def read_log_tail(self, path: Path, max_chars: int = 8000) -> str:
        if not path.exists() or not path.is_file():
            return ""
        data = path.read_bytes()
        tail = data[-max_chars:]
        return tail.decode("utf-8", errors="replace")

    def observe_from_logs(self, max_chars_per_log: int = 8000) -> Dict[str, Any]:
        observations: List[Dict[str, Any]] = []
        for p in self.log_paths:
            raw = self.read_log_tail(p, max_chars=max_chars_per_log)
            if not raw:
                continue
            safe_raw = sanitize_for_display(raw, max_string=max_chars_per_log)
            lines = [line for line in safe_raw.splitlines() if line.strip()]
            tail_line = lines[-1] if lines else ""
            app = self._guess_app_name(p, lines)
            markers = self._extract_recent_markers(lines)
            location = self._build_location(markers, lines)
            summary = self._build_summary(markers, tail_line)
            confidence = self._confidence(markers, location)
            obs = DesktopObservation(
                created_at=dt.datetime.now(dt.timezone.utc).isoformat(),
                source=str(p),
                app=app,
                location=location,
                summary=summary,
                raw_tail=safe_raw,
                text_profile=detect_text_profile(safe_raw).to_dict(),
                markers=markers,
                confidence=confidence,
            )
            obs_dict = dataclasses.asdict(obs)
            observations.append(obs_dict)
            self.state.setdefault("observations", []).append(obs_dict)
            self._update_current_state(obs_dict)
        self.state["observations"] = self.state.get("observations", [])[-300:]
        self.save()
        return {
            "ok": True,
            "observations": observations,
            "state": self.get_state_snapshot(),
            "known_shortcuts": [dataclasses.asdict(s) for s in self.shortcuts.values()],
        }

    def _guess_app_name(self, path: Path, lines: List[str]) -> str:
        markers = self._extract_recent_markers(lines)
        for key in ("app", "application", "process", "service"):
            if key in markers:
                return markers[key]
        return path.stem

    def _extract_recent_markers(self, lines: List[str]) -> Dict[str, str]:
        merged: Dict[str, str] = {}
        for line in lines[-80:]:
            for match in KEY_VALUE_RE.finditer(line):
                key = match.group("key").strip().lower()
                value = match.group("value").strip().strip("'\"")
                if len(value) > 500:
                    value = value[-500:]
                merged[key] = value
        return merged

    def _build_location(self, markers: Dict[str, str], lines: List[str]) -> str:
        parts: List[str] = []
        for keys, label in ((SCREEN_KEYS, "screen"), (ROUTE_KEYS, "route"), (STATE_KEYS, "state"), (TITLE_KEYS, "title")):
            for key in keys:
                if key in markers:
                    parts.append(f"{label}={markers[key]}")
                    break
        if parts:
            return " ".join(parts)[-500:]
        return self._guess_location(lines)

    def _build_summary(self, markers: Dict[str, str], tail_line: str) -> str:
        parts: List[str] = []
        for keys, label in ((ACTION_KEYS, "action"), (RESULT_KEYS, "result"), (ERROR_KEYS, "message")):
            for key in keys:
                if key in markers:
                    parts.append(f"{label}={markers[key]}")
                    break
        if parts:
            return " ".join(parts)[-600:]
        return tail_line[-600:] if tail_line else "No recent log line"

    def _confidence(self, markers: Dict[str, str], location: str) -> float:
        score = 0.15
        if any(k in markers for k in SCREEN_KEYS):
            score += 0.25
        if any(k in markers for k in ROUTE_KEYS):
            score += 0.25
        if any(k in markers for k in STATE_KEYS):
            score += 0.15
        if any(k in markers for k in ACTION_KEYS | RESULT_KEYS | ERROR_KEYS):
            score += 0.10
        if location != "unknown":
            score += 0.10
        return round(min(score, 1.0), 3)

    def _update_current_state(self, obs: Dict[str, Any]) -> None:
        app = str(obs.get("app") or "unknown")
        markers = obs.get("markers") or {}
        current = {
            "app": app,
            "last_seen_at": obs.get("created_at"),
            "source": obs.get("source"),
            "location": obs.get("location"),
            "summary": obs.get("summary"),
            "confidence": obs.get("confidence"),
            "screen": self._first_marker(markers, SCREEN_KEYS),
            "route": self._first_marker(markers, ROUTE_KEYS),
            "state": self._first_marker(markers, STATE_KEYS),
            "title": self._first_marker(markers, TITLE_KEYS),
            "last_action": self._first_marker(markers, ACTION_KEYS),
            "last_result": self._first_marker(markers, RESULT_KEYS),
            "last_message": self._first_marker(markers, ERROR_KEYS),
        }
        self.state.setdefault("current_by_app", {})[app] = current

    @staticmethod
    def _first_marker(markers: Dict[str, str], keys: set[str]) -> Optional[str]:
        for key in keys:
            if key in markers:
                return markers[key]
        return None

    def _guess_location(self, lines: List[str]) -> str:
        # Fallback heuristic; apps should prefer explicit markers.
        for line in reversed(lines[-50:]):
            lower = line.lower()
            for marker in ("route=", "path=", "url=", "screen=", "view=", "window=", "page="):
                if marker in lower:
                    return line.strip()[-300:]
        return "unknown"

    def get_state_snapshot(self, limit: int = 30) -> Dict[str, Any]:
        observations = self.state.get("observations", [])[-limit:]
        return {
            "ok": True,
            "state_path": str(self.state_path),
            "registered_logs": [{"path": str(p), "exists": p.exists()} for p in self.log_paths],
            "current_by_app": self.state.get("current_by_app", {}),
            "timeline": observations,
            "shortcuts": [dataclasses.asdict(s) for s in self.shortcuts.values()],
            "executions": self.state.get("executions", [])[-limit:],
        }

    def suggest_shortcut(self, intent: str, app: Optional[str] = None) -> Dict[str, Any]:
        intent_l = intent.lower()
        candidates: List[ShortcutAction] = []
        for action in self.shortcuts.values():
            if app and action.app not in {app, "global"}:
                continue
            hay = f"{action.name} {action.description} {' '.join(action.keys)}".lower()
            if any(token in hay for token in intent_l.split() if len(token) >= 2):
                candidates.append(action)
        return {"ok": True, "intent": intent, "candidates": [dataclasses.asdict(c) for c in candidates[:10]]}
```


## `event_journal.py`

```python
"""
Append-only JSONL event journal for SkyGround.

Purpose:
- Store raw operational events locally.
- Support later daily distillation / skill promotion.
- Keep events sanitized before writing.
"""

from __future__ import annotations

import datetime as dt
import json
from pathlib import Path
from typing import Any, Dict, List, Optional

from security import sanitize_for_display


class EventJournal:
    def __init__(self, events_dir: Path):
        self.events_dir = Path(events_dir)
        self.events_dir.mkdir(parents=True, exist_ok=True)

    def _path_for_date(self, day: Optional[str] = None) -> Path:
        day = day or dt.datetime.now(dt.timezone.utc).strftime("%Y-%m-%d")
        return self.events_dir / f"{day}.jsonl"

    def record(self, event_type: str, data: Optional[Dict[str, Any]] = None, level: str = "info") -> Dict[str, Any]:
        event = {
            "time": dt.datetime.now(dt.timezone.utc).isoformat(),
            "type": event_type,
            "level": level,
            "data": sanitize_for_display(data or {}, max_string=8000),
        }
        path = self._path_for_date()
        with path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(event, ensure_ascii=False, separators=(",", ":")) + "\n")
        return {"ok": True, "path": str(path), "event": event}

    def recent(self, limit: int = 100, day: Optional[str] = None) -> List[Dict[str, Any]]:
        path = self._path_for_date(day)
        if not path.exists():
            return []
        lines = path.read_text(encoding="utf-8", errors="replace").splitlines()[-limit:]
        events: List[Dict[str, Any]] = []
        for line in lines:
            try:
                events.append(json.loads(line))
            except Exception:
                continue
        return events

    def summarize_counts(self, day: Optional[str] = None) -> Dict[str, Any]:
        events = self.recent(limit=10000, day=day)
        counts: Dict[str, int] = {}
        levels: Dict[str, int] = {}
        for event in events:
            counts[event.get("type", "unknown")] = counts.get(event.get("type", "unknown"), 0) + 1
            levels[event.get("level", "info")] = levels.get(event.get("level", "info"), 0) + 1
        return {"ok": True, "total": len(events), "counts": counts, "levels": levels, "day": day or dt.datetime.now(dt.timezone.utc).strftime("%Y-%m-%d")}
```


## `intent_registry.py`

```python
"""
Intent registry and lightweight recognizer.

This is the small local "reflex brain" entry point: map phrases like
"کپی کن" and "copy" to the same canonical intent without calling an LLM.
"""

from __future__ import annotations

import dataclasses
import difflib
import json
import re
from pathlib import Path
from typing import Any, Dict, List, Optional


@dataclasses.dataclass
class IntentDefinition:
    id: str
    description: str
    aliases: List[str]
    risk: str = "low"          # low | medium | high
    ambiguous: bool = False
    status: str = "approved"   # candidate | approved | trusted | blocked


DEFAULT_INTENTS: List[IntentDefinition] = [
    IntentDefinition("clipboard.copy", "Copy current selection", ["copy", "copy this", "copy selected", "کپی", "کپی کن", "رونوشت", "ctrl+c", "کنترل سی"], status="trusted"),
    IntentDefinition("clipboard.paste", "Paste clipboard", ["paste", "paste here", "پیست", "بچسبان", "جایگذاری", "ctrl+v", "کنترل وی"], risk="medium"),
    IntentDefinition("clipboard.cut", "Cut current selection", ["cut", "cut this", "کات", "ببر", "ctrl+x", "کنترل ایکس"], risk="medium", ambiguous=True),
    IntentDefinition("file.save_active", "Save active file/window", ["save", "save file", "save active", "ذخیره", "ذخیره کن", "ctrl+s", "کنترل اس"], status="trusted"),
    IntentDefinition("ui.escape", "Dismiss/cancel current modal", ["escape", "esc", "cancel", "لغو", "ببند", "خروج از پنجره", "فرار"], risk="low"),
    IntentDefinition("search.open", "Open search", ["search", "open search", "جستجو", "جستجو کن", "سرچ", "ctrl+f", "ctrl+k"], risk="low"),
    IntentDefinition("command_palette.open", "Open command palette", ["command palette", "open command palette", "پالت دستور", "ctrl+shift+p"], risk="low"),
    IntentDefinition("project.index", "Index the project", ["index project", "reindex", "ایندکس", "ایندکس کن", "پروژه را ایندکس کن"], risk="low", status="trusted"),
    IntentDefinition("project.search", "Search project", ["search project", "find in project", "در پروژه بگرد", "جستجوی پروژه"], risk="low"),
    IntentDefinition("git.status", "Show git status", ["git status", "وضعیت گیت", "گیت status", "وضعیت تغییرات"], risk="low", status="trusted"),
    IntentDefinition("git.diff", "Show git diff", ["git diff", "diff", "تغییرات را نشان بده", "دیف"], risk="low", status="trusted"),
    IntentDefinition("desktop.observe", "Observe registered desktop logs", ["observe logs", "desktop state", "وضعیت صفحه", "لاگ را بخوان", "چشم", "ببین کجاست"], risk="low", status="trusted"),
    IntentDefinition("memory.search", "Search memory", ["search memory", "memory search", "حافظه را بگرد", "در حافظه بگرد"], risk="low"),
    IntentDefinition("danger.delete", "Ambiguous delete/remove request", ["delete", "remove", "حذف", "حذف کن", "پاک کن", "reset"], risk="high", ambiguous=True, status="blocked"),
]


def normalize_text(text: str) -> str:
    text = (text or "").strip().lower()
    text = text.replace("ي", "ی").replace("ك", "ک")
    text = text.replace("\u200c", " ")
    text = re.sub(r"[\[\]{}()<>`'\".,;:!?؟،]+", " ", text)
    text = re.sub(r"\s+", " ", text).strip()
    # Normalize ctrl + c variations.
    text = text.replace("ctrl +", "ctrl+").replace("control +", "ctrl+").replace("کنترل ", "کنترل ")
    return text


@dataclasses.dataclass
class IntentMatch:
    intent: IntentDefinition
    score: float
    matched_alias: str
    method: str

    def to_dict(self) -> Dict[str, Any]:
        return {"intent": dataclasses.asdict(self.intent), "score": self.score, "matched_alias": self.matched_alias, "method": self.method}


class IntentRegistry:
    def __init__(self, path: Path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.intents: Dict[str, IntentDefinition] = {}
        self._load_or_seed()

    def _load_or_seed(self) -> None:
        if self.path.exists():
            try:
                data = json.loads(self.path.read_text(encoding="utf-8"))
                for item in data.get("intents", []):
                    intent = IntentDefinition(**item)
                    self.intents[intent.id] = intent
            except Exception:
                self.intents = {}
        changed = False
        for intent in DEFAULT_INTENTS:
            if intent.id not in self.intents:
                self.intents[intent.id] = intent
                changed = True
        if changed or not self.path.exists():
            self.save()

    def save(self) -> None:
        payload = {"version": 1, "intents": [dataclasses.asdict(i) for i in self.intents.values()]}
        tmp = self.path.with_name(f".{self.path.name}.tmp")
        tmp.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
        tmp.replace(self.path)

    def list_intents(self) -> List[Dict[str, Any]]:
        return [dataclasses.asdict(i) for i in self.intents.values()]

    def register_intent(self, data: Dict[str, Any], overwrite: bool = True) -> Dict[str, Any]:
        """Register or update an intent from an admin-provided JSON object."""
        intent_id = str(data.get("id", "")).strip()
        if not intent_id:
            return {"ok": False, "error": "intent id is required"}
        if intent_id in self.intents and not overwrite:
            return {"ok": False, "error": "intent already exists", "id": intent_id}
        aliases_raw = data.get("aliases", [])
        if isinstance(aliases_raw, str):
            aliases = [x.strip() for x in aliases_raw.replace(",", "\n").splitlines() if x.strip()]
        elif isinstance(aliases_raw, list):
            aliases = [str(x).strip() for x in aliases_raw if str(x).strip()]
        else:
            aliases = []
        if not aliases:
            return {"ok": False, "error": "at least one alias is required"}
        intent = IntentDefinition(
            id=intent_id,
            description=str(data.get("description", intent_id)),
            aliases=aliases,
            risk=str(data.get("risk", "low")),
            ambiguous=bool(data.get("ambiguous", False)),
            status=str(data.get("status", "approved")),
        )
        self.intents[intent.id] = intent
        self.save()
        return {"ok": True, "intent": dataclasses.asdict(intent)}

    def resolve(self, text: str, limit: int = 5) -> Dict[str, Any]: 
        norm = normalize_text(text)
        matches: List[IntentMatch] = []
        if not norm:
            return {"ok": False, "error": "empty command", "matches": []}
        for intent in self.intents.values():
            if intent.status == "blocked" and intent.risk != "high":
                continue
            for alias in intent.aliases:
                na = normalize_text(alias)
                if not na:
                    continue
                if norm == na:
                    matches.append(IntentMatch(intent, 1.0, alias, "exact"))
                elif na in norm or norm in na:
                    score = min(len(na), len(norm)) / max(len(na), len(norm))
                    matches.append(IntentMatch(intent, round(max(0.72, score), 4), alias, "contains"))
                else:
                    ratio = difflib.SequenceMatcher(None, norm, na).ratio()
                    if ratio >= 0.78:
                        matches.append(IntentMatch(intent, round(ratio, 4), alias, "fuzzy"))
        # Deduplicate by intent, keep best.
        best: Dict[str, IntentMatch] = {}
        for m in matches:
            old = best.get(m.intent.id)
            if old is None or m.score > old.score:
                best[m.intent.id] = m
        ordered = sorted(best.values(), key=lambda m: m.score, reverse=True)[:limit]
        return {"ok": True, "input": text, "normalized": norm, "matches": [m.to_dict() for m in ordered]}
```


## `skill_registry.py`

```python
"""
Skill registry for SkyGround reflex layer.

Skills connect canonical intents to concrete executors/tools.
"""

from __future__ import annotations

import dataclasses
import json
from pathlib import Path
from typing import Any, Dict, List, Optional


SAFETY_ORDER = {"silent": 0, "fast": 1, "confirm": 2, "approval": 3, "blocked": 4}


@dataclasses.dataclass
class SkillDefinition:
    id: str
    intent: str
    description: str
    executor: str
    args: Dict[str, Any]
    safety_level: str = "fast"     # silent | fast | confirm | approval | blocked
    risk: str = "low"              # low | medium | high
    status: str = "approved"       # candidate | learned | approved | trusted | deprecated | blocked
    confidence: float = 0.8
    usage_count: int = 0
    success_count: int = 0
    failure_count: int = 0
    requires_approval: bool = False
    reporting_on_success: str = "event_only"  # silent | event_only | summary | brain_report
    reporting_on_failure: str = "brain_report"


DEFAULT_SKILLS: List[SkillDefinition] = [
    SkillDefinition("shortcut.copy", "clipboard.copy", "Copy selection using Ctrl+C", "execute_shortcut", {"name": "copy"}, "fast", "low", "trusted", 0.95, requires_approval=False, reporting_on_success="silent"),
    SkillDefinition("shortcut.paste", "clipboard.paste", "Paste clipboard using Ctrl+V", "execute_shortcut", {"name": "paste"}, "confirm", "medium", "approved", 0.8),
    SkillDefinition("shortcut.cut", "clipboard.cut", "Cut selection using Ctrl+X", "execute_shortcut", {"name": "cut"}, "confirm", "medium", "approved", 0.75),
    SkillDefinition("shortcut.save", "file.save_active", "Save active file using Ctrl+S", "execute_shortcut", {"name": "save"}, "fast", "low", "trusted", 0.95, requires_approval=False, reporting_on_success="silent"),
    SkillDefinition("shortcut.escape", "ui.escape", "Press Escape", "execute_shortcut", {"name": "escape"}, "fast", "low", "trusted", 0.9),
    SkillDefinition("shortcut.open_search", "search.open", "Open search using Ctrl+K", "execute_shortcut", {"name": "open_search"}, "fast", "low", "approved", 0.85),
    SkillDefinition("shortcut.command_palette", "command_palette.open", "Open command palette using Ctrl+Shift+P", "execute_shortcut", {"name": "command_palette"}, "fast", "low", "approved", 0.85),
    SkillDefinition("project.index", "project.index", "Rebuild project index", "index_project", {}, "silent", "low", "trusted", 0.95, reporting_on_success="silent"),
    SkillDefinition("git.status", "git.status", "Read git status", "git_status", {}, "silent", "low", "trusted", 0.95, reporting_on_success="silent"),
    SkillDefinition("git.diff", "git.diff", "Read git diff", "git_diff", {}, "silent", "low", "trusted", 0.95, reporting_on_success="event_only"),
    SkillDefinition("desktop.observe", "desktop.observe", "Observe registered desktop logs", "observe_desktop_logs", {}, "silent", "low", "trusted", 0.9, reporting_on_success="silent"),
    SkillDefinition("memory.search", "memory.search", "Search memory; requires query", "search_memory", {"query_from_command": True}, "fast", "low", "approved", 0.7),
]


class SkillRegistry:
    def __init__(self, path: Path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.skills: Dict[str, SkillDefinition] = {}
        self._load_or_seed()

    def _load_or_seed(self) -> None:
        if self.path.exists():
            try:
                data = json.loads(self.path.read_text(encoding="utf-8"))
                for item in data.get("skills", []):
                    skill = SkillDefinition(**item)
                    self.skills[skill.id] = skill
            except Exception:
                self.skills = {}
        changed = False
        for skill in DEFAULT_SKILLS:
            if skill.id not in self.skills:
                self.skills[skill.id] = skill
                changed = True
        if changed or not self.path.exists():
            self.save()

    def save(self) -> None:
        payload = {"version": 1, "skills": [dataclasses.asdict(s) for s in self.skills.values()]}
        tmp = self.path.with_name(f".{self.path.name}.tmp")
        tmp.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
        tmp.replace(self.path)

    def list_skills(self) -> List[Dict[str, Any]]:
        return [dataclasses.asdict(s) for s in self.skills.values()]

    def register_skill(self, data: Dict[str, Any], overwrite: bool = True) -> Dict[str, Any]:
        """Register or update a skill from an admin-provided JSON object."""
        skill_id = str(data.get("id", "")).strip()
        intent = str(data.get("intent", "")).strip()
        executor = str(data.get("executor", "")).strip()
        if not skill_id:
            return {"ok": False, "error": "skill id is required"}
        if not intent:
            return {"ok": False, "error": "skill intent is required"}
        if not executor:
            return {"ok": False, "error": "skill executor is required"}
        if skill_id in self.skills and not overwrite:
            return {"ok": False, "error": "skill already exists", "id": skill_id}
        args = data.get("args", {})
        if not isinstance(args, dict):
            return {"ok": False, "error": "skill args must be an object"}
        skill = SkillDefinition(
            id=skill_id,
            intent=intent,
            description=str(data.get("description", skill_id)),
            executor=executor,
            args=args,
            safety_level=str(data.get("safety_level", "fast")),
            risk=str(data.get("risk", "low")),
            status=str(data.get("status", "approved")),
            confidence=float(data.get("confidence", 0.8)),
            usage_count=int(data.get("usage_count", 0)),
            success_count=int(data.get("success_count", 0)),
            failure_count=int(data.get("failure_count", 0)),
            requires_approval=bool(data.get("requires_approval", False)),
            reporting_on_success=str(data.get("reporting_on_success", "event_only")),
            reporting_on_failure=str(data.get("reporting_on_failure", "brain_report")),
        )
        if skill.safety_level not in SAFETY_ORDER:
            return {"ok": False, "error": f"invalid safety_level: {skill.safety_level}"}
        if skill.status not in {"candidate", "learned", "approved", "trusted", "deprecated", "blocked"}:
            return {"ok": False, "error": f"invalid status: {skill.status}"}
        self.skills[skill.id] = skill
        self.save()
        return {"ok": True, "skill": dataclasses.asdict(skill)}

    def find_by_intent(self, intent_id: str) -> Optional[SkillDefinition]:
        candidates = [s for s in self.skills.values() if s.intent == intent_id and s.status not in {"deprecated"}]
        if not candidates:
            return None
        candidates.sort(key=lambda s: (s.status == "trusted", s.confidence, s.success_count - s.failure_count), reverse=True)
        return candidates[0]

    def update_stats(self, skill_id: str, ok: bool) -> None:
        skill = self.skills.get(skill_id)
        if not skill:
            return
        skill.usage_count += 1
        if ok:
            skill.success_count += 1
            # Promote trusted after repeated success for non-dangerous skills.
            if skill.success_count >= 5 and skill.failure_count == 0 and skill.risk == "low" and skill.status in {"approved", "learned"}:
                skill.status = "trusted"
                skill.confidence = max(skill.confidence, 0.9)
            else:
                skill.confidence = min(0.99, skill.confidence + 0.01)
        else:
            skill.failure_count += 1
            skill.confidence = max(0.1, skill.confidence - 0.08)
            if skill.failure_count >= 3 and skill.failure_count > skill.success_count:
                skill.status = "learned" if skill.status == "trusted" else skill.status
        self.save()

    def promote(self, skill_id: str, status: str = "trusted") -> Dict[str, Any]:
        if status not in {"candidate", "learned", "approved", "trusted", "deprecated", "blocked"}:
            return {"ok": False, "error": "invalid status"}
        skill = self.skills.get(skill_id)
        if not skill:
            return {"ok": False, "error": "skill not found"}
        skill.status = status
        if status == "trusted":
            skill.confidence = max(skill.confidence, 0.9)
        self.save()
        return {"ok": True, "skill": dataclasses.asdict(skill)}
```


## `reflex_engine.py`

```python
"""
Reflex engine: local intent -> skill -> executor without calling a big LLM.
"""

from __future__ import annotations

import dataclasses
from typing import Any, Callable, Dict, Optional, Tuple

from event_journal import EventJournal
from intent_registry import IntentRegistry
from skill_registry import SAFETY_ORDER, SkillDefinition, SkillRegistry


class ReflexEngine:
    def __init__(self, intents: IntentRegistry, skills: SkillRegistry, journal: EventJournal):
        self.intents = intents
        self.skills = skills
        self.journal = journal

    def resolve(self, command: str) -> Dict[str, Any]:
        intent_result = self.intents.resolve(command)
        if not intent_result.get("ok") or not intent_result.get("matches"):
            return {"ok": False, "command": command, "needs_brain": True, "reason": "no_intent_match", "intent_result": intent_result}
        best = intent_result["matches"][0]
        intent = best["intent"]
        if intent.get("status") == "blocked":
            return {"ok": False, "command": command, "blocked": True, "reason": "intent_blocked", "intent_match": best}
        if intent.get("ambiguous") and best.get("score", 0) < 0.98:
            return {"ok": False, "command": command, "needs_clarification": True, "reason": "ambiguous_intent", "intent_match": best, "matches": intent_result.get("matches", [])}
        skill = self.skills.find_by_intent(intent["id"])
        if not skill:
            return {"ok": False, "command": command, "needs_brain": True, "reason": "missing_skill", "intent_match": best}
        return {"ok": True, "command": command, "intent_match": best, "skill": dataclasses.asdict(skill)}

    def should_request_approval(
        self,
        skill: SkillDefinition,
        dry_run: bool,
        auto_execute_trusted: bool = True,
        trust_threshold: float = 0.85,
        require_approval_for_confirm: bool = True,
    ) -> Tuple[bool, str]:
        if dry_run:
            return False, "dry_run"
        if skill.status == "blocked" or skill.safety_level == "blocked":
            return True, "blocked_or_admin_only"
        if skill.requires_approval:
            return True, "skill_requires_approval"
        safety = SAFETY_ORDER.get(skill.safety_level, 3)
        if safety <= SAFETY_ORDER["fast"]:
            return False, "fast_or_silent"
        if safety == SAFETY_ORDER["confirm"]:
            if auto_execute_trusted and skill.status == "trusted" and skill.confidence >= trust_threshold:
                return False, "trusted_confirm_auto"
            return require_approval_for_confirm, "confirm_level"
        return True, "approval_level"

    def execute(
        self,
        command: str,
        executor: Callable[[SkillDefinition, bool, str], Dict[str, Any]],
        dry_run: bool = False,
        approval_callback: Optional[Callable[[SkillDefinition, Dict[str, Any], str], bool]] = None,
        auto_execute_trusted: bool = True,
        trust_threshold: float = 0.85,
        require_approval_for_confirm: bool = True,
    ) -> Dict[str, Any]:
        resolved = self.resolve(command)
        if not resolved.get("ok"):
            self.journal.record("reflex.resolve_failed", resolved, level="warning")
            return resolved
        skill = SkillDefinition(**resolved["skill"])
        approval_needed, approval_reason = self.should_request_approval(
            skill,
            dry_run=dry_run,
            auto_execute_trusted=auto_execute_trusted,
            trust_threshold=trust_threshold,
            require_approval_for_confirm=require_approval_for_confirm,
        )
        if skill.status == "blocked" or skill.safety_level == "blocked":
            result = {"ok": False, "error": "skill is blocked", "resolved": resolved}
            self.journal.record("reflex.blocked", result, level="warning")
            return result
        if approval_needed:
            if approval_callback is None:
                result = {"ok": False, "needs_approval": True, "approval_reason": approval_reason, "resolved": resolved}
                self.journal.record("reflex.approval_missing", result, level="warning")
                return result
            approved = approval_callback(skill, resolved, approval_reason)
            if not approved:
                result = {"ok": False, "cancelled": True, "error": "approval rejected", "approval_reason": approval_reason, "resolved": resolved}
                self.journal.record("reflex.approval_rejected", result, level="warning")
                return result
        result = executor(skill, dry_run, approval_reason)
        ok = bool(result.get("ok"))
        self.skills.update_stats(skill.id, ok=ok)
        event_type = "reflex.executed" if ok else "reflex.failed"
        self.journal.record(event_type, {"command": command, "skill_id": skill.id, "intent": skill.intent, "dry_run": dry_run, "approval_reason": approval_reason, "result": result}, level="info" if ok else "warning")
        result["resolved"] = resolved
        result["approval_reason"] = approval_reason
        return result
```


## `daily_distiller.py`

```python
"""
Daily distiller for SkyGround agent.

Reads the append-only event journal and produces a deterministic daily learning report:
- event counts
- reflex skill usage/failures
- unknown/ambiguous commands that need brain/admin review
- skill promotion/demotion recommendations
- short memory-ready lesson lines

No LLM is required. This is the first safe layer of daily learning.
"""

from __future__ import annotations

import datetime as dt
import json
from pathlib import Path
from typing import Any, Dict, List, Optional

from event_journal import EventJournal
from security import sanitize_for_display
from skill_registry import SkillRegistry


class DailyDistiller:
    def __init__(self, journal: EventJournal, skills: SkillRegistry, output_dir: Path):
        self.journal = journal
        self.skills = skills
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)

    def _day(self, day: Optional[str] = None) -> str:
        return day or dt.datetime.now(dt.timezone.utc).strftime("%Y-%m-%d")

    def _output_path(self, day: str) -> Path:
        return self.output_dir / f"{day}.json"

    def distill(self, day: Optional[str] = None, apply: bool = False) -> Dict[str, Any]:
        day = self._day(day)
        events = self.journal.recent(limit=10000, day=day)
        counts = self.journal.summarize_counts(day=day)

        skill_stats: Dict[str, Dict[str, Any]] = {}
        unknown_commands: Dict[str, int] = {}
        blocked_or_ambiguous: Dict[str, int] = {}
        approval_missing = 0
        injections = 0

        for event in events:
            etype = event.get("type", "")
            data = event.get("data") or {}
            if etype in {"reflex.executed", "reflex.failed"}:
                skill_id = str(data.get("skill_id") or data.get("result", {}).get("resolved", {}).get("skill", {}).get("id") or "unknown")
                stat = skill_stats.setdefault(skill_id, {"success": 0, "failure": 0, "dry_run": 0, "commands": {}})
                if data.get("dry_run"):
                    stat["dry_run"] += 1
                if etype == "reflex.executed":
                    stat["success"] += 1
                else:
                    stat["failure"] += 1
                cmd = str(data.get("command") or "")[:200]
                if cmd:
                    stat["commands"][cmd] = stat["commands"].get(cmd, 0) + 1
            elif etype == "reflex.resolve_failed":
                cmd = str(data.get("command") or data.get("input") or data.get("intent_result", {}).get("input") or "")[:200]
                reason = str(data.get("reason") or "unknown")
                if reason in {"no_intent_match", "missing_skill"}:
                    unknown_commands[cmd or "[empty]"] = unknown_commands.get(cmd or "[empty]", 0) + 1
                else:
                    blocked_or_ambiguous[cmd or reason] = blocked_or_ambiguous.get(cmd or reason, 0) + 1
            elif etype in {"reflex.approval_missing", "reflex.approval_rejected", "reflex.blocked"}:
                approval_missing += 1
            elif etype == "admin.inject":
                injections += 1

        recommendations: List[Dict[str, Any]] = []
        for skill_id, stat in sorted(skill_stats.items()):
            skill = self.skills.skills.get(skill_id)
            if not skill:
                continue
            total = stat["success"] + stat["failure"]
            if total == 0:
                continue
            if stat["success"] >= 3 and stat["failure"] == 0 and skill.risk == "low" and skill.status in {"approved", "learned"}:
                recommendations.append(
                    {
                        "type": "promote_skill",
                        "skill_id": skill_id,
                        "target_status": "trusted",
                        "reason": f"{stat['success']} successful executions and no failures today",
                        "applyable": True,
                    }
                )
            if stat["failure"] >= 2:
                recommendations.append(
                    {
                        "type": "review_skill",
                        "skill_id": skill_id,
                        "reason": f"{stat['failure']} failures today",
                        "applyable": False,
                    }
                )

        for cmd, n in sorted(unknown_commands.items(), key=lambda x: x[1], reverse=True)[:20]:
            if cmd and cmd != "[empty]":
                recommendations.append(
                    {
                        "type": "candidate_intent_or_skill",
                        "command": cmd,
                        "count": n,
                        "reason": "command could not be resolved by reflex layer",
                        "applyable": False,
                    }
                )

        lesson_lines: List[str] = []
        if skill_stats:
            top = sorted(skill_stats.items(), key=lambda kv: kv[1]["success"] + kv[1]["failure"], reverse=True)[:5]
            for skill_id, stat in top:
                lesson_lines.append(f"Skill {skill_id}: success={stat['success']} failure={stat['failure']} dry_run={stat['dry_run']} on {day}.")
        if unknown_commands:
            lesson_lines.append(f"There were {sum(unknown_commands.values())} unresolved reflex commands; consider adding intents/skills for frequent commands.")
        if injections:
            lesson_lines.append(f"Admin performed {injections} injection event(s) on {day}.")
        if approval_missing:
            lesson_lines.append(f"There were {approval_missing} approval/blocked reflex events; review safety levels if workflow is too slow.")
        if not lesson_lines:
            lesson_lines.append(f"No significant learning events recorded for {day}.")

        applied: List[Dict[str, Any]] = []
        if apply:
            for rec in recommendations:
                if rec.get("type") == "promote_skill" and rec.get("applyable"):
                    res = self.skills.promote(str(rec["skill_id"]), str(rec.get("target_status", "trusted")))
                    applied.append({"recommendation": rec, "result": res})

        report = {
            "ok": True,
            "day": day,
            "event_counts": counts,
            "skill_stats": skill_stats,
            "unknown_commands": unknown_commands,
            "blocked_or_ambiguous": blocked_or_ambiguous,
            "recommendations": recommendations,
            "lesson_lines": lesson_lines,
            "applied": applied,
            "apply": apply,
        }
        report = sanitize_for_display(report, max_string=12000)
        path = self._output_path(day)
        path.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
        report["path"] = str(path)
        return report
```


## `project_scaffolds.py`

```python
"""
Project scaffold templates for SkyGround Agent.

These templates let the agent create new projects from zero without relying on UI actions.
They are intentionally small, understandable, and easy for the agent/user to modify later.
"""

from __future__ import annotations

import dataclasses
import re
from typing import Dict, List


@dataclasses.dataclass(frozen=True)
class ScaffoldResult:
    template: str
    project_name: str
    description: str
    files: Dict[str, str]
    run_commands: List[str]
    next_steps: List[str]


SAFE_PROJECT_RE = re.compile(r"^[A-Za-z0-9_.-]+$")


def safe_project_name(name: str) -> str:
    name = (name or "").strip().replace(" ", "_")
    if not name:
        raise ValueError("project_name is required")
    if name in {".", ".."} or "/" in name or "\\" in name:
        raise ValueError("project_name must be a simple folder name, not a path")
    if not SAFE_PROJECT_RE.match(name):
        raise ValueError("project_name may only contain letters, numbers, underscore, dash, and dot")
    return name


def _title(name: str) -> str:
    return name.replace("_", " ").replace("-", " ").title()


def list_templates() -> List[Dict[str, str]]:
    return [
        {"id": "python_flask_site", "label": "Python Flask Website", "description": "Small Flask website with templates/static files."},
        {"id": "python_fastapi_api", "label": "Python FastAPI API", "description": "Small FastAPI backend with health and items endpoints."},
        {"id": "static_html_site", "label": "Static HTML Site", "description": "Simple HTML/CSS/JS site with no backend."},
        {"id": "python_cli_tool", "label": "Python CLI Tool", "description": "Small argparse-based command line tool."},
    ]


def create_scaffold(template: str, project_name: str, description: str = "") -> ScaffoldResult:
    project_name = safe_project_name(project_name)
    template = (template or "").strip()
    description = (description or "").strip() or f"A new {template} project generated by SkyGround."
    if template == "python_flask_site":
        return python_flask_site(project_name, description)
    if template == "python_fastapi_api":
        return python_fastapi_api(project_name, description)
    if template == "static_html_site":
        return static_html_site(project_name, description)
    if template == "python_cli_tool":
        return python_cli_tool(project_name, description)
    raise ValueError(f"Unknown scaffold template: {template}")


def python_flask_site(project_name: str, description: str) -> ScaffoldResult:
    title = _title(project_name)
    files = {
        "README.md": f"""# {title}\n\n{description}\n\n## Setup\n\n```powershell\npython -m venv .venv\n.\\.venv\\Scripts\\python -m pip install -r requirements.txt\n.\\.venv\\Scripts\\python app.py\n```\n\nOpen:\n\n```text\nhttp://127.0.0.1:5000\n```\n\n## Structure\n\n```text\napp.py\ntemplates/index.html\nstatic/style.css\n```\n""",
        "requirements.txt": "Flask>=3.0,<4\n",
        "app.py": """from flask import Flask, render_template\n\napp = Flask(__name__)\n\n\n@app.route(\"/\")\ndef index():\n    return render_template(\"index.html\")\n\n\n@app.route(\"/health\")\ndef health():\n    return {\"status\": \"ok\"}\n\n\nif __name__ == \"__main__\":\n    app.run(host=\"127.0.0.1\", port=5000, debug=True)\n""",
        "templates/index.html": f"""<!doctype html>\n<html lang=\"fa\" dir=\"rtl\">\n<head>\n  <meta charset=\"utf-8\" />\n  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\" />\n  <title>{title}</title>\n  <link rel=\"stylesheet\" href=\"{{{{ url_for('static', filename='style.css') }}}}\" />\n</head>\n<body>\n  <main class=\"hero\">\n    <section class=\"card\">\n      <p class=\"eyebrow\">ساخته شده با Flask</p>\n      <h1>{title}</h1>\n      <p>{description}</p>\n      <a class=\"button\" href=\"/health\">بررسی سلامت API</a>\n    </section>\n  </main>\n</body>\n</html>\n""",
        "static/style.css": """:root {\n  color-scheme: dark;\n  font-family: Tahoma, system-ui, -apple-system, Segoe UI, sans-serif;\n  background: #0f172a;\n  color: #e5eefb;\n}\n\nbody {\n  margin: 0;\n  min-height: 100vh;\n  background: radial-gradient(circle at top, #1e3a8a 0, #0f172a 42%, #020617 100%);\n}\n\n.hero {\n  min-height: 100vh;\n  display: grid;\n  place-items: center;\n  padding: 32px;\n}\n\n.card {\n  width: min(760px, 92vw);\n  padding: 42px;\n  border: 1px solid rgba(148, 163, 184, 0.28);\n  border-radius: 28px;\n  background: rgba(15, 23, 42, 0.78);\n  box-shadow: 0 24px 80px rgba(0, 0, 0, 0.42);\n}\n\n.eyebrow {\n  color: #67e8f9;\n  font-weight: 700;\n}\n\nh1 {\n  font-size: clamp(34px, 7vw, 72px);\n  margin: 0 0 18px;\n}\n\np {\n  line-height: 1.9;\n  color: #cbd5e1;\n}\n\n.button {\n  display: inline-block;\n  margin-top: 18px;\n  padding: 12px 18px;\n  border-radius: 14px;\n  color: #082f49;\n  background: #67e8f9;\n  text-decoration: none;\n  font-weight: 800;\n}\n""",
        ".gitignore": ".venv/\n__pycache__/\n*.pyc\n.env\n.sg_agent/\n",
    }
    return ScaffoldResult(
        template="python_flask_site",
        project_name=project_name,
        description=description,
        files=files,
        run_commands=[
            "python -m venv .venv",
            ".\\.venv\\Scripts\\python -m pip install -r requirements.txt",
            ".\\.venv\\Scripts\\python app.py",
        ],
        next_steps=["Open http://127.0.0.1:5000", "Edit templates/index.html and static/style.css"],
    )


def python_fastapi_api(project_name: str, description: str) -> ScaffoldResult:
    title = _title(project_name)
    files = {
        "README.md": f"""# {title}\n\n{description}\n\n## Setup\n\n```powershell\npython -m venv .venv\n.\\.venv\\Scripts\\python -m pip install -r requirements.txt\n.\\.venv\\Scripts\\python -m uvicorn main:app --reload\n```\n\nDocs:\n\n```text\nhttp://127.0.0.1:8000/docs\n```\n""",
        "requirements.txt": "fastapi>=0.110,<1\nuvicorn[standard]>=0.27,<1\n",
        "main.py": f"""from fastapi import FastAPI\nfrom pydantic import BaseModel\n\napp = FastAPI(title=\"{title}\")\n\n\nclass Item(BaseModel):\n    name: str\n    description: str | None = None\n\n\n@app.get(\"/\")\ndef root():\n    return {{\"message\": \"Welcome to {title}\"}}\n\n\n@app.get(\"/health\")\ndef health():\n    return {{\"status\": \"ok\"}}\n\n\n@app.post(\"/items\")\ndef create_item(item: Item):\n    return {{\"ok\": True, \"item\": item}}\n""",
        ".gitignore": ".venv/\n__pycache__/\n*.pyc\n.env\n.sg_agent/\n",
    }
    return ScaffoldResult("python_fastapi_api", project_name, description, files, ["python -m venv .venv", ".\\.venv\\Scripts\\python -m pip install -r requirements.txt", ".\\.venv\\Scripts\\python -m uvicorn main:app --reload"], ["Open http://127.0.0.1:8000/docs"])


def static_html_site(project_name: str, description: str) -> ScaffoldResult:
    title = _title(project_name)
    files = {
        "README.md": f"# {title}\n\n{description}\n\nOpen `index.html` in your browser.\n",
        "index.html": f"""<!doctype html>\n<html lang=\"fa\" dir=\"rtl\">\n<head>\n  <meta charset=\"utf-8\" />\n  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\" />\n  <title>{title}</title>\n  <link rel=\"stylesheet\" href=\"static/style.css\" />\n</head>\n<body>\n  <main class=\"container\">\n    <h1>{title}</h1>\n    <p>{description}</p>\n    <button id=\"hello\">کلیک کن</button>\n  </main>\n  <script src=\"static/app.js\"></script>\n</body>\n</html>\n""",
        "static/style.css": """body {\n  margin: 0;\n  min-height: 100vh;\n  display: grid;\n  place-items: center;\n  font-family: Tahoma, sans-serif;\n  background: linear-gradient(135deg, #0f172a, #1e3a8a);\n  color: white;\n}\n.container {\n  width: min(720px, 92vw);\n  padding: 36px;\n  border-radius: 24px;\n  background: rgba(255,255,255,0.08);\n}\nbutton {\n  padding: 12px 18px;\n  border: 0;\n  border-radius: 12px;\n  cursor: pointer;\n}\n""",
        "static/app.js": """document.getElementById('hello')?.addEventListener('click', () => {\n  alert('سلام از سایت ساخته‌شده با SkyGround!');\n});\n""",
        ".gitignore": ".sg_agent/\n",
    }
    return ScaffoldResult("static_html_site", project_name, description, files, ["start index.html"], ["Open index.html in a browser"])


def python_cli_tool(project_name: str, description: str) -> ScaffoldResult:
    title = _title(project_name)
    module_name = re.sub(r"[^A-Za-z0-9_]", "_", project_name).lower()
    files = {
        "README.md": f"""# {title}\n\n{description}\n\n## Run\n\n```powershell\npython main.py --name Ali\n```\n""",
        "main.py": f"""import argparse\n\n\ndef main() -> int:\n    parser = argparse.ArgumentParser(description={description!r})\n    parser.add_argument(\"--name\", default=\"World\", help=\"Name to greet\")\n    args = parser.parse_args()\n    print(f\"Hello, {{args.name}}! This is {title}.\")\n    return 0\n\n\nif __name__ == \"__main__\":\n    raise SystemExit(main())\n""",
        "tests/test_basic.py": f"""import subprocess\nimport sys\n\n\ndef test_cli_runs():\n    result = subprocess.run([sys.executable, \"main.py\", \"--name\", \"Test\"], capture_output=True, text=True)\n    assert result.returncode == 0\n    assert \"Test\" in result.stdout\n""",
        ".gitignore": "__pycache__/\n*.pyc\n.pytest_cache/\n.sg_agent/\n",
    }
    return ScaffoldResult("python_cli_tool", project_name, description, files, ["python main.py --name Ali", "python -m pytest"], ["Add your CLI logic in main.py"])
```


## `config.example.json`

```json
{
  "llm_provider": "ollama",
  "ollama_url": "http://localhost:11434",
  "openai_base_url": "https://api.gapgpt.app/v1",
  "openai_api_key_env": "GAPGPT_API_KEY",
  "openai_api_key": "",
  "openai_timeout_sec": 600,
  "openai_max_tokens": 0,
  "brain_routing_enabled": false,
  "brain_routing_simple_provider": "ollama",
  "brain_routing_complex_provider": "openai_compatible",
  "brain_routing_sensitive_provider": "ollama",
  "brain_routing_allow_api_for_sensitive": false,
  "model": "qwen2.5-coder:7b-instruct",
  "temperature": 0.2,
  "num_ctx": 8192,
  "max_steps": 8,
  "workspace_root": ".",
  "memory_dir": ".sg_agent",

  "max_file_read_chars": 20000,
  "max_tree_entries": 250,

  "auto_index_on_start": false,
  "max_index_files": 5000,
  "max_index_file_bytes": 250000,
  "index_preview_chars": 1500,

  "command_timeout_sec": 60,
  "require_approval_for_writes": true,
  "require_approval_for_commands": true,
  "create_backups": true,
  "backup_dir": ".sg_agent/backups",
  "enable_shortcut_execution": false,
  "require_approval_for_shortcuts": true,
  "shortcut_execution_dry_run": false,
  "shortcut_execution_method": "powershell_sendkeys",
  "shortcut_execution_delay_ms": 120,
  "min_desktop_confidence_for_shortcut": 0.0,
  "allow_shortcut_without_desktop_state": true,
  "mask_secrets": true,
  "mask_secrets_in_memory": true,
  "block_sensitive_file_reads": false,
  "sensitive_file_globs": [
    ".env",
    ".env.*",
    "**/.env",
    "**/.env.*",
    "*.pem",
    "*.key",
    "id_rsa",
    "id_ed25519",
    "**/secrets/**",
    "**/credentials/**",
    "**/.ssh/**"
  ],

  "enable_dashboard": true,
  "dashboard_host": "127.0.0.1",
  "dashboard_port": 8765,
  "dashboard_token": "",
  "approval_timeout_sec": 0,
  "policy_file": ".sg_agent/policy.json",
  "auto_load_policy": true,
  "vector_memory_file": ".sg_agent/vector_memory.sqlite",
  "vector_dimensions": 384,
  "desktop_state_file": ".sg_agent/desktop_state.json",
  "reflex_enabled": true,
  "reflex_auto_execute_trusted": true,
  "reflex_trust_threshold": 0.85,
  "reflex_require_approval_for_confirm": true,
  "skills_file": ".sg_agent/skills.json",
  "intents_file": ".sg_agent/intents.json",
  "event_journal_dir": ".sg_agent/events",
  "distillation_dir": ".sg_agent/distillations",

  "ignored_dirs": [
    ".git",
    ".sg_agent",
    "node_modules",
    ".venv",
    "venv",
    "__pycache__",
    "dist",
    "build",
    ".next",
    ".nuxt",
    ".svelte-kit",
    "target",
    "out",
    "coverage",
    ".pytest_cache",
    ".mypy_cache",
    ".ruff_cache"
  ],
  "ignored_file_globs": [
    "*.pyc",
    "*.pyo",
    "*.exe",
    "*.dll",
    "*.so",
    "*.dylib",
    "*.bin",
    "*.png",
    "*.jpg",
    "*.jpeg",
    "*.gif",
    "*.ico",
    "*.pdf",
    "*.zip",
    "*.tar",
    "*.gz",
    "*.7z",
    "*.rar",
    "*.mp4",
    "*.mp3",
    "*.wav",
    "*.lock"
  ],
  "blocked_command_fragments": [
    "rm -rf /",
    "sudo rm",
    "mkfs",
    "format ",
    "del /s",
    "rmdir /s",
    "shutdown",
    "reboot",
    "reg delete",
    "Remove-Item -Recurse -Force C:\\",
    "Remove-Item -Recurse -Force /"
  ]
}
```


## `README.md`

```markdown
# SkyGround Local Cursor-like Coding Agent v3

یک ایجنت برنامه‌نویسی محلی برای **Windows + Ollama**؛ شبیه نسخه‌ی ساده، قابل توسعه و قابل نظارت از Cursor Agent.

نسخه ۳ علاوه بر ابزارهای کدنویسی، یک **داشبورد ادمین** هم دارد برای:

- ثبت task از داشبورد و اجرای صفی توسط ایجنت
- Reflex/Skill Layer برای اجرای سریع دستورات پایه مثل «کپی کن»، `save` و `git status` بدون مغز بزرگ
- API Playground برای صدا زدن API خارجی/لینک prompt و تبدیل پاسخ به task
- Secret Scanner/Masking برای جلوگیری از نمایش token/key/password در log/diff/memory
- نظارت زنده روی وضعیت ایجنت
- Admin Token اختیاری برای محافظت داشبورد
- Pause/Resume/Cancel/Emergency Stop
- تأیید یا رد عملیات خطرناک مثل write/edit/command
- پرسش/پاسخ بین ایجنت و ادمین
- دادن دسترسی موقت و granular مثل فقط `src/**` یا فقط `python -m pytest*`
- تغییر پارامترهای runtime مثل مدل، temperature، max_steps بدون restart

---

## معماری

```text
User / Admin
  ↓
CLI + Admin Dashboard + API Playground
  ↓
Local Coding Agent
  ↓
Ollama Local Model = مغز آفلاین
  ↓
Tools = چشم و دست
  - list_dir / read_file        دیدن پروژه و فایل‌ها
  - search_project / index      جستجوی پروژه و symbolها
  - write_file / edit_file      ویرایش امن با diff و backup
  - apply_patch                 patch چندفایلی با unified diff
  - git_status / git_diff       آگاهی از وضعیت Git
  - run_command                 اجرای تست/فرمان با approval
  - ask_admin                   پرسش از ادمین از داشبورد
  - remember / search_memory    حافظه تجربه محلی
  ↓
SQLite Memory + Project Index
```

---

## قابلیت‌های اصلی

### 0) Task Manager از داشبورد

داشبورد حالا فقط مرکز نظارت نیست؛ مرکز فرماندهی هم هست.

از داخل داشبورد می‌توانی:

```text
Submit Task
Pause
Resume
Cancel Task
Emergency Stop
Clear Stop
```

Taskها status دارند:

```text
queued
running
cancelling
completed
failed
cancelled
```

ایجنت taskهای ثبت‌شده از داشبورد را در یک worker پس‌زمینه، یکی‌یکی اجرا می‌کند. اگر task وسط کار نیاز به approval یا سؤال داشته باشد، همان داشبورد آن را مدیریت می‌کند.

`Emergency Stop` این کارها را انجام می‌دهد:

- approvalهای pending را reject می‌کند.
- سؤال‌های pending را expire می‌کند.
- policy را به read-only mode می‌برد.
- taskهای queued/running را cancel می‌کند.
- اجرای task بعد از نقطه امن بعدی متوقف می‌شود.

### 0.1) Admin Injection Center

در داشبورد بخشی اضافه شده است:

```text
Admin Injection Center
```

از اینجا می‌توانی هم دستی و هم از طریق فایل، داده آموزشی به ایجنت تزریق کنی:

```text
متن ساده → memory.sqlite و vector_memory.sqlite
JSON bundle → memory + vector + intents + skills + shortcuts
```

فایل در مرورگر خوانده می‌شود و محتوا به agent فرستاده می‌شود. فرمت JSON bundle نمونه:

```json
{
  "memories": [
    {"kind": "user_preference", "text": "پاسخ‌ها فارسی باشند."}
  ],
  "intents": [
    {"id": "browser.refresh", "description": "Refresh page", "aliases": ["refresh", "رفرش", "ctrl+r"]}
  ],
  "shortcuts": [
    {"name": "refresh", "description": "Refresh active page", "keys": ["Ctrl", "R"], "risk": "low"}
  ],
  "skills": [
    {"id": "shortcut.refresh", "intent": "browser.refresh", "executor": "execute_shortcut", "args": {"name": "refresh"}, "safety_level": "fast"}
  ]
}
```

دکمه `Sample Bundle` همین نمونه را داخل داشبورد آماده می‌کند.

### 0.25) Reflex / Skills؛ چهار دست و پای ایجنت

برای اینکه ایجنت برای کارهای پایه هر بار سراغ مغز بزرگ نرود، یک لایه Reflex اضافه شده است.

این لایه دستورهایی مثل این‌ها را local تشخیص می‌دهد:

```text
کپی کن
copy
ذخیره کن
save
git status
observe logs
```

و آن‌ها را به intent و skill تبدیل می‌کند:

```text
کپی کن → clipboard.copy → shortcut.copy → Ctrl+C
ذخیره کن → file.save_active → shortcut.save → Ctrl+S
git status → git.status → git_status tool
```

فایل‌های مربوطه:

```text
.sg_agent/intents.json
.sg_agent/skills.json
.sg_agent/events/YYYY-MM-DD.jsonl
```

در داشبورد بخش جدیدی هست:

```text
Reflex / Skills
```

دکمه‌ها:

```text
Resolve          فقط تشخیص intent/skill
Dry Run          تست بدون اجرای واقعی
Execute          اجرای skill
List Skills      دیدن مهارت‌ها
Event Counts     شمارش رویدادها
Daily Distill    خلاصه و پیشنهاد یادگیری روزانه
Distill + Apply  اعمال پیشنهادهای امن مثل trusted کردن skillهای موفق
```

نمونه تست:

```text
Reflex command: کپی کن
Dry Run
```

باید ببینی:

```text
intent = clipboard.copy
skill = shortcut.copy
sendkeys = ^c
```

این همان مرحله «چهار دست و پا رفتن» ایجنت است: اول مهارت‌های پایه، بعد رشد و اعتماد بیشتر.

### 0.4) Project Factory / Scaffold Mode

برای ساخت پروژه از صفر، داشبورد بخش جدید دارد:

```text
Project Factory
```

از اینجا می‌توانی بدون VS Code UI، مستقیم پروژه بسازی. اول `Preview / Dry Run` را بزن، بعد اگر درست بود `Create Project`.

Templateهای اولیه:

```text
python_flask_site
python_fastapi_api
static_html_site
python_cli_tool
```

مثلاً برای درخواست «یک وب‌سایت با پایتون بساز»، template مناسب:

```text
python_flask_site
```

خروجی نمونه:

```text
my_site/
  app.py
  requirements.txt
  README.md
  templates/index.html
  static/style.css
```

ساخت پروژه با یک preview/diff کلی انجام می‌شود و برای اعمال، approval می‌گیرد مگر اینکه policy را کم‌سخت‌گیر کرده باشی.

### 0.5) External API Chat برای لینک/API خارجی

اگر از یک سایت API گرفته‌ای و با PowerShell به آن prompt می‌فرستی، حالا می‌توانی همان را از داشبورد راحت‌تر و شبیه چت استفاده کنی.

در بخش زیر:

```text
External API Chat / کمک‌برنامه‌نویس
```

می‌توانی وارد کنی:

- Endpoint URL
- Method: `POST` یا `GET`
- Headers JSON مثل Authorization
- Body template با placeholderهای زیر:

```text
{{prompt_json}}   امن برای قرار گرفتن داخل JSON
{{prompt}}        متن خام prompt
```

مثلاً Body template پیشنهادی برای API ساده:

```json
{"prompt":{{prompt_json}}}
```

برای APIهای OpenAI-compatible مثل GapGPT:

```json
{
  "model": "{{model}}",
  "messages": [
    {
      "role": "user",
      "content": {{prompt_json}}
    }
  ]
}
```

و Response JSON path معمولاً این است:

```text
choices.0.message.content
```

امکانات این بخش:

- Preset آماده برای OpenAI-compatible API
- Preset آماده برای GapGPT
- فیلد Model با placeholderهای `{{model}}` و `{{model_json}}`
- System/Instruction اختصاصی برای API
- Context/Code برای paste کردن کد یا خطا
- Quick prompts مثل Analyze، Generate Code، Debug، Write Tests، Refactor
- Chat history محلی در مرورگر
- Response JSON path برای استخراج جواب تمیز، مثل:

```text
answer
text
choices.0.message.content
```

دکمه‌ها:

```text
Ask API                  ارسال سوال به API
Use Response as Agent Task تبدیل جواب API به task برای agent داخلی
Copy Response             کپی جواب
Clear Chat                پاک‌کردن تاریخچه local
```

`Use Response as Agent Task` پاسخ API را به عنوان context به agent داخلی می‌دهد تا اگر لازم بود فایل‌های پروژه را بخواند، diff بسازد و با approval تغییرات را اعمال کند.

نکته امنیتی: headerها و endpointهای دارای token در event log تا حد ممکن mask می‌شوند، اما بهتر است API key را در repo ذخیره نکنی.

### 0.75) Secret Scanner / Masking

برای امنیت بیشتر، سیستم ماسک‌کردن secret اضافه شده است. به‌صورت پیش‌فرض فعال است و قبل از نمایش/ذخیره در بخش‌های حساس، مقدارهایی مثل این‌ها را mask می‌کند:

```text
API keys
Bearer tokens
passwordها
secretها
private key blockها
DATABASE_URL / DB_URL
GitHub/OpenAI/Google/Slack tokenهای رایج
```

مثلاً:

```text
OPENAI_API_KEY=sk-abcdefghijklmnopqrstuvwxyz
```

در داشبورد/log/context به شکل زیر دیده می‌شود:

```text
OPENAI_API_KEY=sk-a…[SECRET_MASKED]
```

محل‌هایی که masking اعمال می‌شود:

- `read_file` output
- project index preview/snippets
- dashboard event log
- approval diff/patch preview
- command stdout/stderr
- git diff/status output
- memory database
- task snapshot در داشبورد
- raw model output هنگام نمایش در CLI

تنظیمات مربوطه در `config.json`:

```json
"mask_secrets": true,
"mask_secrets_in_memory": true,
"block_sensitive_file_reads": false,
"sensitive_file_globs": [
  ".env",
  ".env.*",
  "**/.env",
  "**/.env.*",
  "*.pem",
  "*.key",
  "**/secrets/**"
]
```

اگر `block_sensitive_file_reads` را `true` کنی، خواندن فایل‌هایی مثل `.env` به‌کلی block می‌شود. اگر `false` باشد، محتوا خوانده می‌شود ولی secretها mask می‌شوند.

### 1) Admin Dashboard

داشبورد به‌صورت local روی سیستم خودت اجرا می‌شود:

```text
http://127.0.0.1:8765
```

در داشبورد می‌بینی و کنترل می‌کنی:

- ثبت task جدید
- pause/resume/cancel/emergency stop
- وضعیت agent: idle/running/stop
- مدل فعال
- task فعلی
- uptime
- project index summary
- git status
- pending approvals
- pending asks
- event log زنده
- runtime config
- session permissions
- policy templates
- save/load policy از فایل `.sg_agent/policy.json`

### 1.5) Admin Token اختیاری

اگر در `config.json` مقدار زیر را پر کنی:

```json
"dashboard_token": "یک-رمز-طولانی-ایمن"
```

داشبورد بدون token باز نمی‌شود و یک صفحه ورود نشان می‌دهد. APIهای داشبورد هم نیاز به token دارند.

اگر مقدار خالی باشد:

```json
"dashboard_token": ""
```

داشبورد بدون login کار می‌کند. برای استفاده جدی، مخصوصاً اگر host را از `127.0.0.1` تغییر می‌دهی، حتماً token بگذار.

### 2) Approval Queue

هر وقت ایجنت بخواهد عملیات حساس انجام دهد، درخواست در داشبورد می‌آید:

- `write_file`
- `edit_file`
- `edit_file_multi`
- `apply_patch`
- `run_command`

ادمین می‌تواند:

- Approve
- Reject
- reason بنویسد

تا وقتی approval نیاید، اجرای همان ابزار pause می‌شود.

### 3) Patch Engine چندفایلی

ابزار `apply_patch` می‌تواند یک unified diff چندفایلی را با `git apply --check` بررسی کند، بعد patch را در داشبورد برای approval نشان دهد، backup بگیرد و اعمال کند.

این برای تغییرات هماهنگ بین چند فایل حرفه‌ای‌تر از `old_text/new_text` است.

### 4) Ask Admin

ایجنت می‌تواند وسط کار از ادمین سؤال بپرسد، مثلاً:

```text
آیا اجازه دارم full test suite را اجرا کنم؟
```

یا:

```text
بین refactor کامل و fix کوچک کدام را ترجیح می‌دهی؟
```

این سؤال در داشبورد نمایش داده می‌شود و ادمین پاسخ می‌دهد.

### 5) Session Permissions / Granular Grant Access

در داشبورد می‌توانی برای همان session دسترسی موقت و جزئی بدهی:

- `Read-only mode`
  - همه write/edit/commandها رد می‌شوند.

- `Auto-approve writes`
  - write/edit/apply_patchها فقط طبق policy تأیید خودکار می‌شوند.

- `Allowed write globs`
  - مثال:
    ```text
    src/**
    README.md
    ```

- `Denied write globs`
  - مثال:
    ```text
    .env
    **/secrets/**
    ```

- `Reject write/edit خارج از allowlist`
  - اگر فعال باشد، مسیرهای خارج از allowlist حتی approval دستی هم نمی‌گیرند و مستقیم reject می‌شوند.

- `Auto-approve commands`
  - commandها فقط طبق policy تأیید خودکار می‌شوند.

- `Allowed command globs`
  - مثال:
    ```text
    python -m pytest*
    npm test*
    npm run build*
    ```

- `Denied command fragments`
  - مثال:
    ```text
    rm -rf
    del /s
    format 
    ```

- `Reject command خارج از allowlist`
  - اگر فعال باشد، commandهای خارج از allowlist مستقیم reject می‌شوند.

- `Auto-answer questions`
  - سؤال‌های ask_admin با پاسخ ثابت جواب داده می‌شوند.

قانون مهم:

```text
Deny > Reject unmatched > Auto approve > Manual approval
```

> توصیه امنیتی: برای اتوماسیون امن، auto-approve را فقط همراه allowlist محدود و reject unmatched فعال کن.

### 6) Policy Templates + Save/Load

در داشبورد چند template آماده اضافه شده است:

- `Cautious Manual`
  - همه عملیات حساس approval دستی می‌خواهند.

- `Read-only Review`
  - همه write/edit/commandها reject می‌شوند.

- `Safe Python`
  - commandهای امن Python مثل `python -m pytest*` و `ruff check*` auto-approve می‌شوند.

- `Safe Node`
  - commandهای امن Node مثل `npm test*` و `npm run build*` auto-approve می‌شوند.

- `Docs Only`
  - فقط فایل‌های markdown/docs auto-approve می‌شوند.

- `Src + Tests Development`
  - فقط `src/**` و `tests/**` قابل ویرایش خودکار هستند و test/buildهای رایج مجازند.

در داشبورد می‌توانی:

```text
Apply Template
Merge Template
Save Policy
Load Policy
Reset Session
```

Policy ذخیره‌شده در workspace پروژه قرار می‌گیرد:

```text
.sg_agent/policy.json
```

اگر `auto_load_policy` در config روشن باشد، policy در شروع اجرای بعدی خودکار load می‌شود.

### 7) Vector Memory + Desktop Logs

در داشبورد بخش جدیدی اضافه شده است:

```text
Vector Memory + Desktop Logs
```

این بخش برای رشد تدریجی ایجنت و چشم/دست امن طراحی شده است.

#### Vector Memory

امکانات:

```text
Search Vector Memory
Monthly Inject
```

`Monthly Inject` تجربه‌های ذخیره‌شده در حافظه SQLite را به حافظه برداری تزریق می‌کند تا agent کم‌کم الگوهای تکراری را بهتر پیدا کند.

فعلاً vector memory با روش dependency-free hashing vector ساخته شده؛ بعداً می‌توان آن را با embedding واقعی محلی مثل Ollama embeddings جایگزین کرد.

#### Desktop Logs / Eye

ایجنت می‌تواند log فایل‌های اپلیکیشن‌ها را به عنوان چشم امن بخواند:

```text
Register Log
Observe Logs
```

مثلاً اگر اپ log بدهد:

```text
screen=LoginPage route=/login state=ready
```

ایجنت می‌تواند بفهمد کجاست، بدون screenshot.

دکمه `Desktop State` در داشبورد، موقعیت فعلی اپ‌ها را به صورت کارت و timeline نشان می‌دهد:

```text
Current app
Current screen
Current route
Current state
Last action/result/message
Confidence score
Timeline
```

#### Shortcut Registry / Hand

shortcutها ثبت، پیشنهاد و در صورت فعال بودن، اجرا می‌شوند:

```text
Register Shortcut
Suggest Shortcut
Dry Run Shortcut
Execute Shortcut
```

اجرای shortcut فقط برای shortcutهای ثبت‌شده است؛ هیچ کلیک آزاد یا تایپ آزاد وجود ندارد. برای تست امن اول `Dry Run Shortcut` را بزن. روی Windows اجرای واقعی با PowerShell/WScript SendKeys انجام می‌شود.

تنظیمات مربوطه:

```json
"enable_shortcut_execution": false,
"require_approval_for_shortcuts": true,
"shortcut_execution_dry_run": false,
"shortcut_execution_method": "powershell_sendkeys",
"shortcut_execution_delay_ms": 120,
"min_desktop_confidence_for_shortcut": 0.0,
"allow_shortcut_without_desktop_state": true
```

برای محیط VM که خودت گفتی و کنترلش دست توست، می‌توانی روان‌تر تنظیم کنی:

```json
"enable_shortcut_execution": true,
"require_approval_for_shortcuts": false,
"min_desktop_confidence_for_shortcut": 0.0,
"allow_shortcut_without_desktop_state": true
```

### 8) Runtime Config Hot Update

از داشبورد می‌توانی بدون restart این‌ها را تغییر بدهی:

- `llm_provider`: `ollama`، `openai_compatible` یا `auto`
- `model`
- `ollama_url`
- `openai_base_url`
- تنظیمات Smart Brain Routing
- `openai_api_key_env`
- `openai_timeout_sec`
- `openai_max_tokens`
- `temperature`
- `num_ctx`
- `max_steps`
- `max_file_read_chars`
- `command_timeout_sec`
- `require_approval_for_writes`
- `require_approval_for_commands`

این تغییرات روی runtime فعلی اعمال می‌شوند. اگر می‌خواهی دائمی شوند، بعداً همان مقدارها را در `config.json` هم ذخیره کن.

---

## نصب پیش‌نیازها در Windows

### 1) Python

Python 3.10+ نصب باشد:

```powershell
python --version
```

### 2) Ollama

Ollama را نصب کن:

https://ollama.com/download

بعد مدل کدنویسی بگیر:

```powershell
ollama pull qwen2.5-coder:7b-instruct
```

اگر سیستم ضعیف‌تر است:

```powershell
ollama pull qwen2.5-coder:3b
```

اگر سیستم قوی‌تر است:

```powershell
ollama pull qwen2.5-coder:14b-instruct
```

تست:

```powershell
ollama run qwen2.5-coder:7b-instruct
```

### استفاده از API به‌جای Ollama، مثل GapGPT

اگر می‌خواهی مغز اصلی agent به‌جای Ollama از API سازگار با OpenAI استفاده کند، در PowerShell اول API key را در environment بگذار:

```powershell
$env:GAPGPT_API_KEY="sk-..."
```

بعد در `config.json` این مقدارها را بگذار:

```json
{
  "llm_provider": "openai_compatible",
  "openai_base_url": "https://api.gapgpt.app/v1",
  "openai_api_key_env": "GAPGPT_API_KEY",
  "model": "gpt-4o",
  "temperature": 0.2
}
```

نکته: `openai_base_url` باید base باشد، یعنی:

```text
https://api.gapgpt.app/v1
```

خود agent به‌صورت داخلی `/chat/completions` را اضافه می‌کند.

توصیه امنیتی: API key را مستقیم داخل `config.json` نگذار مگر برای تست کوتاه. بهتر است از env var استفاده کنی.

### Smart Brain Routing

اگر می‌خواهی agent خودش بین مغز محلی و API تصمیم بگیرد:

```json
{
  "llm_provider": "auto",
  "brain_routing_enabled": true,
  "brain_routing_simple_provider": "ollama",
  "brain_routing_complex_provider": "openai_compatible",
  "brain_routing_sensitive_provider": "ollama",
  "brain_routing_allow_api_for_sensitive": false
}
```

منطق پیش‌فرض:

```text
کار ساده یا خصوصی‌تر       → Ollama
کار پیچیده کدنویسی/دیباگ   → API مثل GapGPT
کار حساس شامل token/.env   → فقط Ollama
```

اگر API key تنظیم نشده باشد، route مربوط به API به Ollama fallback می‌کند.

در داشبورد، Task Manager حالا برای هر task نشان می‌دهد:

```text
Brain provider: ollama یا openai_compatible
Reason: simple_task / complex_task / sensitive_local_policy
Sensitive: yes/no
Complex: yes/no
Fallback reason در صورت نیاز
Language profile: فارسی/لاتین/mixed
```

---

## اجرا

از پوشه‌ی agent:

```powershell
cd local_cursor_agent
copy config.example.json config.json
python agent.py --config config.json --root "C:\path\to\your\project"
```

مثال:

```powershell
python agent.py --config config.json --root "C:\Users\Ali\Desktop\my-app"
```

اگر dashboard فعال باشد، در خروجی می‌بینی:

```text
Dashboard: http://127.0.0.1:8765
```

بعد این آدرس را در مرورگر باز کن.

برای index کردن قبل از شروع:

```powershell
python agent.py --config config.json --root "C:\Users\Ali\Desktop\my-app" --index
```

یا داخل خود CLI:

```text
/index
```

---

## دستورهای محلی داخل CLI

```text
/help              نمایش راهنما
/index             ساخت/بازسازی index پروژه
/status            git status
/diff              git diff کل پروژه
/diff path/file.py git diff برای یک فایل
/search QUERY      جستجو در project index
/memory QUERY      جستجو در حافظه تجربه
/summary           خلاصه index
/dashboard         نمایش آدرس داشبورد
exit               خروج
```

---

## نمونه دستورها به ایجنت

```text
ساختار پروژه را بررسی کن و بگو از چه تکنولوژی‌هایی استفاده شده.
```

```text
در پروژه دنبال بخش login بگرد، فایل‌های مرتبط را بخوان و توضیح بده جریان ورود کاربر چطور کار می‌کند.
```

```text
این خطا را پیدا کن و اگر نیاز به اجرای تست داشتی از ادمین اجازه بگیر: Cannot read property 'token' of undefined
```

```text
README پروژه را بهتر کن. قبل از اعمال تغییر diff را نشان بده و منتظر approval ادمین بمان.
```

```text
وضعیت git و diff را بررسی کن و خلاصه کن چه تغییراتی انجام شده.
```

---

## تنظیمات مهم در config.json

```json
{
  "llm_provider": "ollama",
  "ollama_url": "http://localhost:11434",
  "openai_base_url": "https://api.gapgpt.app/v1",
  "openai_api_key_env": "GAPGPT_API_KEY",
  "openai_api_key": "",
  "openai_timeout_sec": 600,
  "openai_max_tokens": 0,
  "model": "qwen2.5-coder:7b-instruct",
  "temperature": 0.2,
  "num_ctx": 8192,
  "max_steps": 8,

  "enable_dashboard": true,
  "dashboard_host": "127.0.0.1",
  "dashboard_port": 8765,
  "dashboard_token": "",
  "approval_timeout_sec": 0,
  "policy_file": ".sg_agent/policy.json",
  "auto_load_policy": true,
  "vector_memory_file": ".sg_agent/vector_memory.sqlite",
  "vector_dimensions": 384,
  "desktop_state_file": ".sg_agent/desktop_state.json",

  "require_approval_for_writes": true,
  "require_approval_for_commands": true,
  "create_backups": true,
  "mask_secrets": true,
  "mask_secrets_in_memory": true,
  "block_sensitive_file_reads": false,

  "auto_index_on_start": false
}
```

`approval_timeout_sec = 0` یعنی approvalها timeout ندارند و تا پاسخ ادمین منتظر می‌مانند.

---

## حافظه و فایل‌های داخلی

ایجنت داخل workspace پروژه این پوشه را می‌سازد:

```text
.sg_agent/
  memory.sqlite
  vector_memory.sqlite
  desktop_state.json
  intents.json
  skills.json
  policy.json
  events/
    YYYY-MM-DD.jsonl
  distillations/
    YYYY-MM-DD.json
  backups/
```

داخل `memory.sqlite` هم حافظه‌ی مکالمه/تجربه و هم project index ذخیره می‌شود.

پیشنهاد: این مسیر را به `.gitignore` اضافه کن:

```gitignore
.sg_agent/
```

---

## امنیت

این نسخه محافظه‌کار طراحی شده:

- از workspace root بیرون نمی‌رود.
- برای write/edit از ادمین approval می‌گیرد.
- برای command از ادمین approval می‌گیرد.
- چند دستور خطرناک block شده‌اند.
- Git tools فقط read-only هستند.
- backup قبل از تغییر فایل ساخته می‌شود.
- dashboard فقط روی `127.0.0.1` اجرا می‌شود، مگر خودت host را تغییر بدهی.

با این حال، برای استفاده جدی:

1. روی branch جدا کار کن.
2. `.sg_agent/` را gitignore کن.
3. auto-approve را با احتیاط فعال کن.
4. قبل از merge، `git diff` را دستی هم بررسی کن.

---

## فایل‌های مهم

```text
local_cursor_agent/
  agent.py              # هسته ایجنت و ابزارها
  dashboard.py          # داشبورد ادمین و approval/ask/config API
  security.py           # secret scanner/masking و sensitive path helpers
  text_intelligence.py  # تشخیص Unicode فارسی/لاتین و جهت متن
  vector_memory.py      # حافظه برداری محلی و تزریق ماهانه تجربه‌ها
  desktop_io.py         # چشم/دست امن مبتنی بر log و shortcut registry
  intent_registry.py    # تشخیص intent و aliasهای فارسی/انگلیسی
  skill_registry.py     # مهارت‌های پایه، safety level، confidence و آمار استفاده
  reflex_engine.py      # اجرای local intent→skill بدون مغز بزرگ
  event_journal.py      # ثبت JSONL رویدادها برای یادگیری روزانه
  daily_distiller.py    # تحلیل روزانه eventها و پیشنهاد یادگیری
  project_scaffolds.py  # templateهای ساخت پروژه از صفر
  config.example.json   # تنظیمات نمونه
  README.md             # راهنما
```

---

## مسیر توسعه بعدی

مرحله‌های بعدی پیشنهادی:

1. **ذخیره دائمی runtime config از داشبورد** با backup/rollback
2. **Policy editor پیشرفته‌تر** با import/export و history
3. **Patch engine پیشرفته‌تر** با parser داخلی و rollback خودکار
4. **تست‌رانر هوشمند** بر اساس نوع پروژه
5. **RAG/Embedding محلی** برای جستجوی معنایی پروژه
6. **داشبورد پیشرفته‌تر با WebSocket** به‌جای polling
7. **Desktop eye/hand** با screenshot/OCR/pyautogui، با approval سخت‌گیرانه
```


## `QUICKSTART_FA.md`

```markdown
# راه‌اندازی سریع SkyGround Local Agent

این راهنما برای اجرای سریع ایجنت روی Windows/VM است.

---

## 1) پیش‌نیازها

### Python

```powershell
python --version
```

Python 3.10 یا بالاتر کافی است.

### Git

```powershell
git --version
```

برای `git_status`، `git_diff` و `apply_patch` لازم است.

### یکی از مغزها

#### گزینه A: Ollama آفلاین

```powershell
ollama pull qwen2.5-coder:7b-instruct
```

#### گزینه B: API مثل GapGPT

```powershell
$env:GAPGPT_API_KEY="sk-..."
```

کلید را داخل فایل‌های پروژه ذخیره نکن.

---

## 2) ساخت config

از پوشه agent:

```powershell
cd local_cursor_agent
copy config.example.json config.json
```

### اگر می‌خواهی با Ollama شروع کنی

در `config.json`:

```json
{
  "llm_provider": "ollama",
  "model": "qwen2.5-coder:7b-instruct",
  "ollama_url": "http://localhost:11434"
}
```

### اگر می‌خواهی با GapGPT/API شروع کنی

در PowerShell:

```powershell
$env:GAPGPT_API_KEY="sk-..."
```

در `config.json`:

```json
{
  "llm_provider": "openai_compatible",
  "openai_base_url": "https://api.gapgpt.app/v1",
  "openai_api_key_env": "GAPGPT_API_KEY",
  "model": "gpt-4o"
}
```

### حالت پیشنهادی هوشمند

```json
{
  "llm_provider": "auto",
  "brain_routing_enabled": true,
  "brain_routing_simple_provider": "ollama",
  "brain_routing_complex_provider": "openai_compatible",
  "brain_routing_sensitive_provider": "ollama",
  "brain_routing_allow_api_for_sensitive": false
}
```

---

## 3) اجرای ایجنت روی پروژه

```powershell
python agent.py --config config.json --root "C:\path\to\your\project"
```

مثال:

```powershell
python agent.py --config config.json --root "C:\Users\Ali\Desktop\my-app"
```

داشبورد معمولاً اینجاست:

```text
http://127.0.0.1:8765
```

اگر dashboard_token گذاشته‌ای، با همان token وارد شو.

---

## 4) کارهای اولیه بعد از اجرا

### 4.1 Index پروژه

در CLI:

```text
/index
```

یا در شروع اجرا:

```powershell
python agent.py --config config.json --root "C:\path\to\project" --index
```

### 4.2 انتخاب Policy

در داشبورد، بخش `Policy Templates`:

- برای بررسی بدون تغییر:
  ```text
  Read-only Review
  ```

- برای پروژه Python:
  ```text
  Safe Python
  ```

- برای Node/React:
  ```text
  Safe Node
  ```

- برای شروع محافظه‌کار:
  ```text
  Cautious Manual
  ```

بعد اگر خواستی:

```text
Save Policy
```

### 4.3 تست API Chat اگر GapGPT داری

در داشبورد:

```text
External API Chat / کمک‌برنامه‌نویس
```

بزن:

```text
Preset GapGPT
```

بعد API key را در Header جایگزین کن:

```json
{
  "Authorization": "Bearer YOUR_API_KEY",
  "Content-Type": "application/json"
}
```

Prompt بزن و `Ask API` را تست کن.

---

## 5) نحوه استفاده روزمره

### از داشبورد task بده

مثلاً:

```text
ساختار پروژه را بررسی کن، تکنولوژی‌ها را تشخیص بده و فایل‌های مهم را معرفی کن.
```

یا:

```text
این خطای login را بررسی کن. قبل از تغییر فایل‌ها approval بگیر.
```

### اگر از API خارجی جواب گرفتی

بعد از `Ask API` یکی از این‌ها را بزن:

```text
Review with Agent      فقط بررسی
Implement Safely       بررسی و اعمال امن
Apply as Patch         اگر جواب API شامل patch است
```

---

## 6) راه‌اندازی چشم با log

اگر اپلیکیشن log دارد، در داشبورد مسیر log را ثبت کن:

```text
Vector Memory + Desktop Logs
Register Log
Observe Logs
Desktop State
```

فرمت log پیشنهادی:

```text
screen=LoginPage route=/login state=ready action=submit result=error message="Invalid token"
```

---

## 7) راه‌اندازی دست با shortcut در VM

اول shortcut ثبت کن:

```text
Shortcut name: open_search
Shortcut keys: Ctrl+K
Shortcut description: Open global search
```

بعد:

```text
Dry Run Shortcut
```

اگر درست بود، در Runtime Config:

```json
"enable_shortcut_execution": true,
"require_approval_for_shortcuts": false,
"shortcut_execution_dry_run": false
```

سپس:

```text
Execute Shortcut
```

---

## 8) حافظه و تزریق

برای رشد تدریجی ایجنت:

1. از داشبورد taskهای مهم را اجرا کن.
2. تجربه‌ها در `memory.sqlite` ذخیره می‌شوند.
3. در بخش `Vector Memory + Desktop Logs` بزن:

```text
Monthly Inject
```

این تجربه‌ها را وارد حافظه برداری می‌کند:

```text
.sg_agent/vector_memory.sqlite
```

---

## 9) مسیرهای داخلی که بهتر است gitignore شوند

در پروژه اصلی:

```gitignore
.sg_agent/
```

---

## 10) پیشنهاد اولین task

بعد از اجرای ایجنت، این task را از داشبورد بده:

```text
پروژه را onboarding کن: ساختار پوشه‌ها، تکنولوژی‌ها، نحوه اجرا، نحوه تست، فایل‌های مهم، ریسک‌ها و پیشنهاد policy مناسب را استخراج کن. هیچ فایلی را تغییر نده. نتیجه را به صورت خلاصه مدیریتی و فنی بده و نکات مهم را در حافظه ذخیره کن.
```
```


## `INJECTION_GUIDE_FA.md`

```markdown
# راهنمای تزریق اولیه و رشد حافظه ایجنت

هدف تزریق این است که ایجنت زودتر پروژه، سبک کاری تو، مسیرهای مهم، خطاهای پرتکرار و تصمیم‌های قبلی را یاد بگیرد.

---

## 1) تزریق یعنی چه؟

در این سیستم سه سطح حافظه داریم:

```text
1. memory.sqlite
   حافظه خام تجربه‌ها، taskها، نتیجه‌ها، تصمیم‌ها

2. vector_memory.sqlite
   حافظه برداری برای پیدا کردن تجربه‌های مرتبط

3. prompt/context runtime
   چیزی که در هر task به مغز داده می‌شود
```

تزریق یعنی انتقال تجربه‌های مهم به لایه‌ای که agent بتواند بعداً سریع‌تر بازیابی کند.

---

## 2) تزریق اولیه پروژه

اولین task پیشنهادی در داشبورد:

```text
پروژه را onboarding کن. فقط بخوان و تحلیل کن، هیچ تغییری اعمال نکن.
موارد زیر را استخراج کن:
1. تکنولوژی‌ها و frameworkها
2. ساختار پوشه‌ها
3. فایل‌های مهم
4. نحوه اجرا
5. نحوه تست و build
6. مسیرهای حساس مثل .env و configها
7. policy پیشنهادی برای این پروژه
8. خطاها یا ریسک‌های احتمالی
9. چیزهایی که باید در حافظه بلندمدت ذخیره شوند
در پایان، موارد مهم را با ابزار remember و add_vector_memory ذخیره کن.
```

اگر می‌خواهی مطمئن‌تر باشد، اول Policy را بگذار روی:

```text
Read-only Review
```

---

## 3) تزریق سبک کاری تو

این task را بده:

```text
این‌ها ترجیحات کاری من هستند. آن‌ها را به عنوان user_preferences و project_workflow در حافظه ذخیره کن:
- پاسخ‌ها فارسی باشد مگر اینکه کد یا اصطلاح فنی انگلیسی لازم باشد.
- قبل از تغییر فایل‌ها diff نشان بده.
- برای کارهای حساس از approval داشبورد استفاده کن.
- برای پروژه‌های کدنویسی اول git_status بگیر.
- برای خطاها اول فایل‌های مرتبط را بخوان، بعد patch پیشنهاد بده.
- secretها و .env نباید به API خارجی فرستاده شوند.
```

---

## 4) تزریق دستورات اجرای پروژه

بعد از اینکه فهمیدی پروژه چطور اجرا می‌شود، یک task بده:

```text
نحوه اجرای پروژه، تست، build و lint را از فایل‌های پروژه استخراج کن و در حافظه ذخیره کن. اگر مطمئن نیستی، سوال بپرس. هیچ commandی را بدون approval اجرا نکن.
```

نمونه حافظه مطلوب:

```text
project_run_command: npm run dev
project_test_command: npm test
project_build_command: npm run build
project_lint_command: npm run lint
```

---

## 5) تزریق log چشم ایجنت

اگر اپ log دارد، بهتر است logها markerدار باشند:

```text
app=myapp screen=LoginPage route=/login state=ready action=submit result=error message="Invalid token"
```

بعد در داشبورد:

```text
Register Log
Observe Logs
Desktop State
```

سپس task بده:

```text
log observationهای اخیر را تحلیل کن و الگوی موقعیت‌یابی اپ را به حافظه برداری اضافه کن. توضیح بده screen/route/stateهای شناخته‌شده کدامند.
```

---

## 6) تزریق ماهانه

هر ماه یا بعد از چند روز کار جدی:

در داشبورد:

```text
Monthly Inject
```

یا task بده:

```text
تجربه‌های مهم این ماه را خلاصه کن، موارد تکراری و تصمیم‌های مهم را جدا کن، و آن‌ها را به vector memory تزریق کن.
```

---

## 7) تزریق خطاهای پرتکرار

هر بار خطایی حل شد، این را از agent بخواه:

```text
این مشکل حل شد. لطفاً root cause، فایل‌های درگیر، راه‌حل، تست انجام‌شده و نشانه‌های تشخیص آینده را به حافظه و vector memory اضافه کن.
```

---

## 8) تزریق shortcutها

برای چشم/دست، shortcutها باید ثبت شوند:

نمونه:

```text
name: open_search
keys: Ctrl+K
description: Open global search
app: vscode
risk: low
```

بعد:

```text
Dry Run Shortcut
```

اگر درست بود، در VM می‌توانی execution را فعال کنی.

---

## 9) چک‌لیست سریع تزریق برای پروژه جدید

```text
[ ] config.json آماده شد
[ ] dashboard باز شد
[ ] policy مناسب انتخاب شد
[ ] /index اجرا شد
[ ] onboarding task اجرا شد
[ ] run/test/build commands ذخیره شد
[ ] log pathها ثبت شدند
[ ] shortcutهای مهم ثبت شدند
[ ] Monthly Inject انجام شد
```

---

## 10) اگر خواستی من کمک کنم

تو می‌توانی ساختار پروژه یا README یا package.json/pyproject را بدهی، من برایت:

- taskهای تزریق مناسب می‌نویسم
- policy مناسب پیشنهاد می‌دهم
- log marker استاندارد طراحی می‌کنم
- shortcut registry اولیه می‌سازم
- promptهای onboarding مخصوص همان پروژه را آماده می‌کنم
```


## `ARCHITECTURE_NEXT.md`

```markdown
# SkyGround Agent - Next Architecture Priorities

این سند برای موارد جدیدی است که اضافه شد: تشخیص فارسی/لاتین، چشم/دست مبتنی بر shortcut/log، و رشد حافظه برداری.

## اصل‌های معماری

1. **اول متن و زبان را درست بفهمیم**
   - تشخیص فارسی/لاتین با Unicode
   - تشخیص جهت متن: RTL/LTR/Mixed
   - ذخیره language profile کنار task/memory

2. **چشم/دست دسکتاپ اول از log و shortcut استفاده کند**
   - حالت عادی: خواندن log فایل‌ها، title/state، route/screen markers
   - حرکت: فقط shortcutهای ثبت‌شده و policy‌شده
   - screenshot فقط در موارد خاص و با approval جداگانه

3. **یادگیری تدریجی**
   - هر تجربه مهم در SQLite memory ذخیره شود
   - ماهانه memoryها به vector brain تزریق شوند
   - vector brain فعلاً dependency-free hashing vector دارد، بعداً قابل جایگزینی با Ollama embeddings است

4. **امنیت قبل از استقلال**
   - secret masking
   - approval
   - policy templates
   - emergency stop
   - read-only mode

---

## فایل‌های جدید

```text
text_intelligence.py
  Unicode Persian/Latin detection
  RTL/LTR/Mixed direction
  script run splitting

vector_memory.py
  local hashed vector memory
  monthly injection interface
  future-compatible with real embeddings

desktop_io.py
  safe desktop I/O scaffolding
  shortcut registry
  log tail observation
  desktop state journal
```

---

## ترتیب ادامه توسعه

### فاز ۱ - انجام شده/شروع‌شده

- [x] Unicode Persian/Latin detection
- [x] ذخیره language profile کنار task
- [x] secret masking
- [x] API Chat -> Agent Task
- [x] task manager/dashboard
- [x] vector memory scaffold
- [x] desktop shortcut/log scaffold

### فاز ۲ - مرحله بعدی پیشنهادی

- [ ] Dashboard UI برای language profile و text direction
- [ ] ابزار agent برای `search_vector_memory`
- [ ] ابزار agent برای `monthly_inject_memory`
- [ ] Dashboard button برای monthly injection
- [ ] ابزار read desktop logs از داشبورد/agent

### فاز ۳

- [ ] Shortcut policy و اجرای shortcut با approval
- [ ] app-specific log adapters
- [ ] screenshot exceptional mode با approval و masking
- [ ] desktop state timeline

### فاز ۴

- [ ] جایگزینی vector hashing با embedding واقعی local
- [ ] تزریق ماهانه خودکار با خلاصه‌سازی LLM
- [ ] memory pruning/confidence/source tracking

---

## قرارداد log برای چشم ایجنت

برای اینکه agent بدون screenshot بفهمد کجاست، appها بهتر است logهایی شبیه این تولید کنند:

```text
2026-06-09T10:00:00 screen=LoginPage route=/login state=ready
2026-06-09T10:00:05 action=submit_login result=error message="Invalid token"
2026-06-09T10:00:10 screen=Dashboard route=/dashboard state=loaded
```

`desktop_io.py` دنبال markerهای زیر می‌گردد:

```text
route=
path=
url=
screen=
view=
window=
page=
```

---

## قرارداد shortcut

Shortcutها باید با نام و ریسک ثبت شوند:

```json
{
  "name": "open_search",
  "description": "Open global search",
  "keys": ["Ctrl", "K"],
  "app": "vscode",
  "risk": "low",
  "requires_approval": false
}
```

اجرای واقعی shortcut هنوز عمداً فعال نشده؛ باید بعداً با policy و approval اضافه شود.
```
