from pathlib import Path
from docx import Document
from docx.shared import Cm, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn

OUT = Path('/home/user/local_cursor_agent/dsa_outputs')
OUT.mkdir(parents=True, exist_ok=True)

TITLE = 'DSA: Deep Spiral Architecture'
SUBTITLE = 'DeepSpiral Angel — معماری مارپیچی حافظه برای یادگیری پیوسته'
AUTHOR = 'هادی طباطبایی (TaHa111)'
EMAIL = 'Hadi.tabatabaei@gmail.com'
CONF = 'محرمانه | Pre-NDA Concept Brief | صرفاً جهت معرفی اولیه و ارزیابی مسیر محرمانگی'


def set_rtl(paragraph):
    p = paragraph._p
    pPr = p.get_or_add_pPr()
    bidi = pPr.find(qn('w:bidi'))
    if bidi is None:
        bidi = OxmlElement('w:bidi')
        pPr.append(bidi)
    bidi.set(qn('w:val'), '1')
    paragraph.alignment = WD_ALIGN_PARAGRAPH.RIGHT


def set_cell_shading(cell, fill):
    tcPr = cell._tc.get_or_add_tcPr()
    shd = tcPr.find(qn('w:shd'))
    if shd is None:
        shd = OxmlElement('w:shd')
        tcPr.append(shd)
    shd.set(qn('w:fill'), fill)


def set_cell_text(cell, text, bold=False, color=None, size=10):
    cell.text = ''
    p = cell.paragraphs[0]
    set_rtl(p)
    run = p.add_run(str(text))
    run.bold = bold
    run.font.name = 'Tahoma'
    run._element.rPr.rFonts.set(qn('w:cs'), 'Tahoma')
    run.font.size = Pt(size)
    if color:
        run.font.color.rgb = RGBColor(*color)
    cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER


def add_para(doc, text='', bold=False, size=11, color=None, align='right', space_after=5):
    p = doc.add_paragraph()
    if align == 'center':
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    else:
        set_rtl(p)
    p.paragraph_format.space_after = Pt(space_after)
    p.paragraph_format.line_spacing = 1.15
    run = p.add_run(text)
    run.bold = bold
    run.font.name = 'Tahoma'
    run._element.rPr.rFonts.set(qn('w:cs'), 'Tahoma')
    run.font.size = Pt(size)
    if color:
        run.font.color.rgb = RGBColor(*color)
    return p


def add_heading(doc, text, level=1):
    size = 15 if level == 1 else 12
    color = (20, 51, 94) if level == 1 else (49, 80, 130)
    p = add_para(doc, text, bold=True, size=size, color=color, space_after=6)
    return p


def add_bullets(doc, items):
    for item in items:
        add_para(doc, '• ' + item, size=10.5, space_after=2)


def setup_doc():
    doc = Document()
    sec = doc.sections[0]
    sec.top_margin = Cm(1.3)
    sec.bottom_margin = Cm(1.3)
    sec.left_margin = Cm(1.4)
    sec.right_margin = Cm(1.4)
    styles = doc.styles
    styles['Normal'].font.name = 'Tahoma'
    styles['Normal']._element.rPr.rFonts.set(qn('w:cs'), 'Tahoma')
    styles['Normal'].font.size = Pt(10.5)
    return doc


def add_header_block(doc):
    p = add_para(doc, TITLE, bold=True, size=19, color=(12, 37, 78), align='center', space_after=2)
    add_para(doc, SUBTITLE, bold=True, size=12.5, color=(42, 76, 128), align='center', space_after=2)
    add_para(doc, f'ارائه‌دهنده: {AUTHOR}', size=10.5, align='center', space_after=2)
    add_para(doc, CONF, bold=True, size=9.5, color=(150, 80, 20), align='center', space_after=8)


def add_footer_note(doc):
    add_para(doc, 'یادداشت محرمانگی: این سند یک معرفی مفهومی پیش از NDA است و شامل فرمول وزن‌دهی کامل، کد اعتبارسنجی، پارامترهای دقیق و جزئیات پیاده‌سازی هسته اختراع نیست.', bold=True, size=9.5, color=(120, 40, 40), space_after=4)
    add_para(doc, f'{AUTHOR} | {EMAIL} | #DSA #DeepSpiralArchitecture #TaHa111', size=9, color=(80, 80, 80), align='center')


def create_executive_docx():
    doc = setup_doc()
    add_header_block(doc)

    add_heading(doc, '۱. مسئله راهبردی')
    add_para(doc, 'در یادگیری پیوسته، مدل‌های هوش مصنوعی هنگام مواجهه با داده‌های جدید، بخشی از اطلاعات قبلی را از دست می‌دهند. این پدیده با عنوان «فراموشی فاجعه‌بار» شناخته می‌شود و برای سامانه‌های هوش مصنوعی پایدار، بومی و بلندمدت یک چالش بنیادی است.')

    add_heading(doc, '۲. ایده محوری DSA')
    add_para(doc, 'DSA یک معماری حافظه پیشنهادی است که به جای نگاه خطی به زمان و حافظه، بردارهای حافظه را در یک هندسه مارپیچی سازمان‌دهی می‌کند. در این معماری، اطلاعات قدیمی به طور کامل حذف نمی‌شوند؛ بلکه وزن و اثر آن‌ها به شکل کنترل‌شده کاهش یافته و امکان بازیابی ساختاری آن‌ها باقی می‌ماند.')
    add_para(doc, 'شعار مفهومی: «محو شدن، نه فراموشی» | Fade, not Forget', bold=True, size=12, color=(20, 90, 120))

    add_heading(doc, '۳. توضیح فنی در سطح قابل ارائه پیش از NDA')
    add_bullets(doc, [
        'هر Memory Slot به یک موقعیت روی مسیر مارپیچی نگاشت می‌شود.',
        'ارتباط میان حافظه‌ها تنها تابع ترتیب زمانی نیست؛ بلکه فاصله هندسی، فاز و وزن زمانی نیز دخیل هستند.',
        'تابع وزن‌دهی کامل، پارامترها و جزئیات پیاده‌سازی هسته اختراع محسوب شده و پس از NDA قابل ارائه است.',
    ])

    add_heading(doc, '۴. نتایج اولیه Proof-of-Concept')
    add_para(doc, 'توجه: هدف این آزمایش، سنجش پایداری حافظه و Early Recall در یادگیری متوالی بوده است، نه ارائه benchmark نهایی accuracy.')
    table = doc.add_table(rows=1, cols=4)
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    headers = ['N', 'Final Acc', 'Max Acc', 'Early Recall']
    for i, h in enumerate(headers):
        set_cell_text(table.rows[0].cells[i], h, bold=True, color=(255,255,255))
        set_cell_shading(table.rows[0].cells[i], '1F4E79')
    rows = [
        ['۸', '۱۱.۵۷٪', '۱۲.۹۹٪', '۸۳.۰٪'],
        ['۱۲', '۱۰.۰۳٪', '۱۰.۲۶٪', '۱۰۰.۰٪'],
        ['۱۸', '۹.۴۹٪', '۱۰.۵۲٪', '۰.۰٪'],
        ['۲۰', '۹.۱۲٪', '۱۰.۳۵٪', '۷۹.۲٪'],
        ['۳۶', '۱۰.۳۲٪', '۱۱.۷۲٪', '۹۲.۵٪'],
        ['۴۸', '۹.۶۴٪', '۱۰.۵۵٪', '۸۶.۴٪'],
    ]
    for r in rows:
        cells = table.add_row().cells
        for i, val in enumerate(r):
            set_cell_text(cells[i], val, bold=(r[0]=='۱۲'))
            if r[0] == '۱۲':
                set_cell_shading(cells[i], 'D9EAF7')
    add_para(doc, 'مشاهده کلیدی: در N=12، معیار Early Recall به ۱۰۰٪ رسید. این نقطه در کد پروژه به صورت داخلی «نقطه فرشته» نام‌گذاری شده است.', bold=True, color=(20,90,120))
    add_para(doc, 'در N=18 یک افت موقت مشاهده شد و در N=20 بازیابی رخ داد. این رفتار می‌تواند نشانه‌ای از گذار فازی یا بازآرایی حافظه باشد و برای ارائه فنی کامل نیازمند تحلیل تکمیلی است.')

    add_heading(doc, '۵. اهمیت برای زبان فارسی')
    add_para(doc, 'در یک تست اولیه تشخیص ابهام فارسی، تمایز میان «اِعراب» به معنای اعراب‌گذاری و «اعراب» به معنای قوم عرب بررسی شد. مدل خطی ۰٪ و DSA در این تست اولیه ۱۰۰٪ تشخیص ثبت کرد. این نتیجه، ظرفیت بالقوه معماری را برای حفظ تمایزهای ظریف معنایی در زبان فارسی نشان می‌دهد.')

    add_heading(doc, '۶. چشم‌انداز توسعه')
    add_para(doc, 'فاز آینده معماری، بررسی مدل Dual Hemisphere Spiral است: دو مارپیچ مکمل با نقش‌های متفاوت، مشابه تفکیک مفهومی منطق و خلاقیت در مغز انسان. هدف این مسیر، کاهش وابستگی خطی حافظه به زمان و افزایش ظرفیت بازیابی مفهومی است.')

    add_heading(doc, '۷. درخواست جلسه')
    add_bullets(doc, [
        'تعریف مسیر محرمانگی و NDA برای ارائه کامل فرمول، کد و نتایج.',
        'بررسی حمایت برای ثبت اختراع داخلی/بین‌المللی.',
        'تشکیل جلسه فنی دوم با تیم تخصصی AI پس از چارچوب محرمانگی.',
        'حمایت در ارزیابی، اعتبارسنجی و مسیر مالکیت فکری معماری DSA.',
    ])
    add_footer_note(doc)
    path = OUT / 'DSA_PreNDA_Executive_Brief_FA.docx'
    doc.save(path)
    return path


def create_speaker_docx():
    doc = setup_doc()
    add_header_block(doc)
    add_heading(doc, 'متن پیشنهادی صحبت — نسخه ارائه‌دهنده')

    sections = [
        ('شروع', 'سلام و وقت بخیر. هادی طباطبایی هستم. امروز برای افشای کامل اختراع نیامده‌ام؛ هدفم معرفی مفهومی معماری DSA، ارائه شواهد اولیه و درخواست ایجاد مسیر محرمانگی، بررسی فنی و ثبت رسمی است.'),
        ('مسئله', 'مسئله‌ای که روی آن کار کرده‌ام، فراموشی فاجعه‌بار در یادگیری پیوسته است. مدل وقتی داده جدید یاد می‌گیرد، در بسیاری از حالت‌ها بخشی از اطلاعات قبلی را از دست می‌دهد. من این را بحران حافظه در مدل‌های یادگیرنده می‌دانم.'),
        ('راه‌حل', 'ایده DSA این است که حافظه را از حالت خطی خارج کنیم و روی یک ساختار مارپیچی قرار دهیم. هر نقطه روی اسپیرال یک Memory Slot است. ارتباط میان نقاط فقط براساس زمان نیست؛ فاصله هندسی، فاز و وزن زمانی نیز اثر دارند.'),
        ('شعار', 'من شعار این معماری را این‌طور بیان می‌کنم: محو شدن، نه فراموشی. یعنی اطلاعات قدیمی الزاماً حذف نمی‌شوند؛ اثرشان کنترل‌شده کاهش می‌یابد، اما امکان بازیابی ساختاری باقی می‌ماند.'),
        ('نتایج', 'در تست اولیه روی وظایف متوالی CIFAR-10، هدف ما benchmark نهایی accuracy نبود؛ هدف سنجش حافظه و Early Recall بود. در N=12، Early Recall به ۱۰۰٪ رسید. من به صورت داخلی این نقطه را «نقطه فرشته» نام‌گذاری کرده‌ام.'),
        ('افت N=18', 'در N=18 افت موقت دیده می‌شود و در N=20 بازیابی رخ می‌دهد. من فعلاً این رفتار را یک نشانه احتمالی از بازآرایی یا گذار فازی حافظه می‌دانم، نه یک ادعای قطعی. تحلیل کامل‌تر آن را بعد از NDA ارائه می‌دهم.'),
        ('فارسی', 'یک تست کوچک فارسی هم انجام دادم: تمایز میان «اِعراب» به معنای اعراب‌گذاری و «اعراب» به معنای قوم عرب. مدل خطی در این تست صفر درصد بود، اما DSA در نسخه اولیه ۱۰۰٪ تشخیص داد. برای من این بخش از نظر AI فارسی اهمیت راهبردی دارد.'),
        ('آینده', 'مسیر آینده را Dual Hemisphere Spiral می‌بینم؛ دو مارپیچ مکمل، یکی نزدیک‌تر به منطق و دیگری نزدیک‌تر به خلاقیت. این فعلاً چشم‌انداز توسعه است و در نسخه فنی بعدی دقیق‌تر توضیح داده می‌شود.'),
        ('درخواست', 'درخواست من روشن است: یک مسیر محرمانگی یا NDA، یک جلسه فنی دوم برای ارائه فرمول‌ها و کد، و حمایت برای بررسی مسیر ثبت اختراع و مالکیت فکری.'),
        ('پایان', 'ممنونم که وقت گذاشتید. من آماده‌ام در چارچوب محرمانگی، جزئیات فنی، فرمول کامل، کد و نتایج را در جلسه بعد ارائه کنم.'),
    ]
    for title, body in sections:
        add_heading(doc, title, level=2)
        add_para(doc, body, size=11)

    add_heading(doc, 'پاسخ‌های آماده به پرسش‌های احتمالی')
    qa = [
        ('فرق DSA با روش‌های دیگر چیست؟', 'در DSA، حافظه از خط زمانی صرف به هندسه مارپیچی منتقل می‌شود. اطلاعات قدیمی حذف یا overwrite نمی‌شوند؛ بلکه وزنشان کاهش می‌یابد و امکان بازیابی ساختاری باقی می‌ماند.'),
        ('چرا فرمول کامل در برگه نیست؟', 'چون این جلسه پیش از NDA است. فرمول پایه در سطح مفهومی قابل توضیح است، اما تابع وزن‌دهی کامل و پارامترهای دقیق هسته اختراع هستند و پس از مسیر محرمانگی ارائه می‌شوند.'),
        ('چرا Final Accuracy حدود ۱۰٪ است؟', 'این آزمایش برای benchmark نهایی accuracy طراحی نشده؛ هدف سنجش رفتار حافظه و Early Recall در یادگیری متوالی بوده است. به همین دلیل معیار کلیدی در این مرحله Early Recall است.'),
        ('N=18 چرا صفر شده؟', 'این را فعلاً یک افت موقت یا گذار فازی می‌دانم که در N=20 بازیابی می‌شود. تحلیل قطعی آن نیازمند بررسی فنی تکمیلی است و من ادعای قطعی بدون تحلیل بیشتر نمی‌کنم.'),
        ('آیا کد آماده است؟', 'بله، کد تست و اعتبارسنجی موجود است، اما نسخه کامل کد و جزئیات پیاده‌سازی را بعد از NDA یا در جلسه فنی محرمانه ارائه می‌دهم.'),
        ('درخواست شما دقیقاً چیست؟', 'ایجاد مسیر NDA، بررسی فنی رسمی، حمایت در ثبت اختراع و تشکیل جلسه دوم با تیم تخصصی برای ارائه جزئیات کامل.'),
    ]
    for q, a in qa:
        add_para(doc, 'پرسش: ' + q, bold=True, color=(20,51,94))
        add_para(doc, 'پاسخ: ' + a)

    add_heading(doc, 'اگر هول شدی، فقط این سه جمله را بگو')
    add_bullets(doc, [
        'DSA حافظه را از خط زمانی به هندسه مارپیچی منتقل می‌کند.',
        'هدف این مرحله، نشان دادن پایداری حافظه و Early Recall است، نه benchmark نهایی accuracy.',
        'جزئیات فنی کامل، فرمول وزن‌دهی و کد پس از NDA ارائه می‌شود.',
    ])
    add_footer_note(doc)
    path = OUT / 'DSA_Speaker_Notes_FA.docx'
    doc.save(path)
    return path


def create_html_files():
    css = """
    body{font-family:Tahoma,Arial,sans-serif;direction:rtl;line-height:1.8;margin:0;background:#f5f7fb;color:#152238} .page{max-width:900px;margin:24px auto;background:white;padding:36px;border-radius:18px;box-shadow:0 12px 40px #0001} h1{text-align:center;color:#0f2d55} h2{color:#1f4e79;border-bottom:1px solid #d8e2ef;padding-bottom:6px} .conf{text-align:center;color:#9a5a00;font-weight:bold}.tag{background:#e8f3ff;border:1px solid #b8d8f5;padding:10px;border-radius:12px} table{width:100%;border-collapse:collapse;direction:ltr;text-align:center} th{background:#1f4e79;color:white}td,th{border:1px solid #ccd6e3;padding:8px}.gold{background:#d9eaf7;font-weight:bold}.footer{text-align:center;color:#666;font-size:13px;margin-top:30px}.warn{color:#7a2e2e;font-weight:bold}
    """
    html = f"""<!doctype html><html lang='fa' dir='rtl'><head><meta charset='utf-8'><title>DSA Brief</title><style>{css}</style></head><body><div class='page'>
    <h1>{TITLE}</h1><div class='conf'>{CONF}</div><h2>{SUBTITLE}</h2>
    <p><b>ارائه‌دهنده:</b> {AUTHOR}</p><p class='tag'>DSA یک معماری حافظه مارپیچی برای یادگیری پیوسته است که با شعار «محو شدن، نه فراموشی» به دنبال کاهش فراموشی فاجعه‌بار است.</p>
    <h2>مسئله</h2><p>در یادگیری پیوسته، مدل‌ها هنگام یادگیری داده‌های جدید، بخشی از اطلاعات قبلی را از دست می‌دهند. DSA برای مدیریت این بحران حافظه طراحی شده است.</p>
    <h2>راه‌حل پیشنهادی</h2><p>حافظه به جای ترتیب خطی، در یک هندسه مارپیچی سازمان‌دهی می‌شود. هر نقطه یک Memory Slot است و ارتباط‌ها با فاصله، فاز و وزن زمانی کنترل می‌شوند.</p>
    <h2>نتایج اولیه</h2><p class='warn'>این نتایج proof-of-concept هستند و هدف، سنجش Early Recall است نه benchmark نهایی accuracy.</p>
    <table><tr><th>N</th><th>Final Acc</th><th>Max Acc</th><th>Early Recall</th></tr><tr><td>۸</td><td>۱۱.۵۷٪</td><td>۱۲.۹۹٪</td><td>۸۳.۰٪</td></tr><tr class='gold'><td>۱۲</td><td>۱۰.۰۳٪</td><td>۱۰.۲۶٪</td><td>۱۰۰.۰٪</td></tr><tr><td>۱۸</td><td>۹.۴۹٪</td><td>۱۰.۵۲٪</td><td>۰.۰٪</td></tr><tr><td>۲۰</td><td>۹.۱۲٪</td><td>۱۰.۳۵٪</td><td>۷۹.۲٪</td></tr><tr><td>۳۶</td><td>۱۰.۳۲٪</td><td>۱۱.۷۲٪</td><td>۹۲.۵٪</td></tr><tr><td>۴۸</td><td>۹.۶۴٪</td><td>۱۰.۵۵٪</td><td>۸۶.۴٪</td></tr></table>
    <h2>اهمیت فارسی</h2><p>در تست اولیه تشخیص ابهام «اِعراب» و «اعراب»، مدل خطی ۰٪ و DSA ۱۰۰٪ تشخیص ثبت کرد.</p>
    <h2>درخواست</h2><ul><li>ایجاد مسیر NDA</li><li>جلسه فنی دوم</li><li>حمایت برای ثبت اختراع</li><li>بررسی مالکیت فکری</li></ul>
    <p class='warn'>این سند شامل فرمول کامل، کد و پارامترهای دقیق نیست. جزئیات پس از NDA ارائه می‌شود.</p><div class='footer'>{AUTHOR} | {EMAIL} | #DSA #TaHa111</div></div></body></html>"""
    path = OUT / 'DSA_PreNDA_Executive_Brief_FA.html'
    path.write_text(html, encoding='utf-8')
    return path


if __name__ == '__main__':
    paths = [create_executive_docx(), create_speaker_docx(), create_html_files()]
    for p in paths:
        print(p)
