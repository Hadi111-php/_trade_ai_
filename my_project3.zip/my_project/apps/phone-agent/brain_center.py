#!/usr/bin/env python3
"""مرکز مغز (Brain Center) — مرجعِ «کسب تکلیف» برای مامور گوشی.

مدل امنیتی (همون طراحی پرامنیت تو):
- ثبت‌نام یک‌باره: هر دستگاه یک device_id + secret می‌گیرد (هرگز دوباره ارسال نمی‌شود).
- هر درخواست با HMAC‑SHA256(secret, payload+ts+nonce) امضا می‌شود.
- ضد بازپخش: پنجرهٔ زمانی + حافظهٔ nonce.
- مرکز فقط «طرح تأییدشده» برمی‌گرداند (از فهرست مجاز)، نه اختیارات خام؛ و همه‌چیز audit می‌شود.

فقط کتابخانهٔ استاندارد. اجرا/تست: python3 brain_center.py
"""
import hashlib, hmac, json, secrets, time


class BrainCenter:
    def __init__(self, ts_window=120):
        self.ts_window = ts_window
        self.devices = {}       # device_id -> secret
        self.nonces = set()
        self.audit = []

    # -- ثبت‌نام یک‌باره --
    def enroll(self, label=""):
        device_id = "dev-" + secrets.token_hex(4)
        secret = secrets.token_hex(16)
        self.devices[device_id] = secret
        self._log("enroll", device_id, label)
        return device_id, secret   # secret فقط همین یک‌بار برگردانده می‌شود

    # -- امضا و راستی‌آزمایی --
    @staticmethod
    def sign(secret, payload, ts, nonce):
        msg = f"{payload}|{ts}|{nonce}".encode()
        return hmac.new(secret.encode(), msg, hashlib.sha256).hexdigest()

    def verify(self, device_id, payload, ts, nonce, sig):
        sec = self.devices.get(device_id)
        if not sec:
            return False, "unknown device"
        if abs(time.time() - ts) > self.ts_window:
            return False, "stale timestamp"
        if nonce in self.nonces:
            return False, "replay nonce"
        expect = self.sign(sec, payload, ts, nonce)
        if not hmac.compare_digest(expect, sig):
            return False, "bad signature"
        self.nonces.add(nonce)
        return True, "ok"

    # -- کسب تکلیف: فقط طرح تأییدشده از فهرست مجاز --
    POLICY = {
        "battery": ["روش کاهش مصرف را نشان بده", "برنامه‌های پرمصرف را لیست کن"],
        "storage": ["فایل‌های حجیم را لیست کن", "کش را پاک کن"],
        "network": ["تنظیمات wifi را بررسی کن", "حالت پرواز را چک کن"],
        "default": ["تشخیص بیشتر لازم است؛ بدون اقدام خودکار"],
    }

    def instruct(self, device_id, payload, ts, nonce, sig):
        ok, msg = self.verify(device_id, payload, ts, nonce, sig)
        self._log("instruct", device_id, f"{payload} -> {msg}")
        if not ok:
            return {"ok": False, "error": msg}
        try:
            kind = json.loads(payload).get("kind", "default")
        except Exception:
            kind = "default"
        plan = self.POLICY.get(kind, self.POLICY["default"])
        return {"ok": True, "plan": plan}

    def _log(self, act, dev, detail):
        self.audit.append({"t": int(time.time()), "act": act, "dev": dev, "d": detail})


if __name__ == "__main__":
    bc = BrainCenter()
    dev, sec = bc.enroll("گوشی هادی")
    payload = json.dumps({"kind": "battery", "problem": "باتری زود خالی می‌شه"})
    ts, nonce = int(time.time()), secrets.token_hex(8)
    sig = bc.sign(sec, payload, ts, nonce)
    print("درخواست معتبر:", bc.instruct(dev, payload, ts, nonce, sig))
    # بازپخش باید رد شود
    print("بازپخش (باید رد):", bc.instruct(dev, payload, ts, nonce, sig))
    # امضای غلط باید رد شود
    print("امضای بد (باید رد):", bc.instruct(dev, payload, ts, secrets.token_hex(8), "00"))
    print("audit entries:", len(bc.audit))
