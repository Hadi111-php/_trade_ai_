import axios from "axios";
import { io, Socket } from "socket.io-client";
import { Trader, Position, MarketStat, WhaleConfig, RealTimeUpdate } from "../types/trader";

const HYPERLIQUID_API = "https://api.hyperliquid.xyz";
const HYPERLIQUID_WS = "wss://api.hyperliquid.xyz/ws";

// Cache for API responses
const cache = new Map<string, { data: any; timestamp: number }>();
const CACHE_TTL = 30000; // 30 seconds

let ws: Socket | null = null;
let wsCallbacks: ((update: RealTimeUpdate) => void)[] = [];

// Whale detection configuration
export const WHALE_CONFIG: WhaleConfig = {
  minPositionValue: 500000, // $500k default threshold
  minVolume: 1000000, // $1M volume
};

// Real API calls to HyperLiquid
export const fetchTopTraders = async (): Promise<Trader[]> => {
  try {
    const cacheKey = "topTraders";
    const cached = cache.get(cacheKey);
    
    if (cached && Date.now() - cached.timestamp < CACHE_TTL) {
      return cached.data;
    }

    // Fetch leaderboard data from HyperLiquid
    const response = await axios.post(`${HYPERLIQUID_API}/info`, {
      type: "leaderboard",
      "season": "latest"
    });

    const traders = response.data.map((item: any, index: number) => ({
      rank: index + 1,
      address: item.user,
      pnl: item.pnl,
      roi: item.ret,
      volume: item.vol,
      winRate: Math.round(item.win * 100),
      trades: item.n,
      currentPositions: [],
      isMock: false,
    }));

    cache.set(cacheKey, { data: traders, timestamp: Date.now() });
    return traders;
  } catch (error) {
    console.error("Failed to fetch from HyperLiquid API, using mock data:", error);
    return generateMockTraders(50);
  }
};

// Fetch user positions to identify whales
export const fetchUserPositions = async (address: string): Promise<Position[]> => {
  try {
    const response = await axios.post(`${HYPERLIQUID_API}/info`, {
      type: "clearinghouseState",
      user: address,
    });

    if (!response.data.assetPositions) return [];

    return response.data.assetPositions.map((pos: any) => ({
      id: `${address}-${pos.position.coin}`,
      coin: pos.position.coin,
      side: pos.position.szi > 0 ? "long" : "short",
      szi: Math.abs(pos.position.szi),
      entryPx: pos.position.entryPx,
      markPx: pos.position.markPx,
      unrealizedPnl: pos.position.unrealizedPnl || 0,
      marginUsed: pos.position.marginUsed,
      leverage: pos.position.leverage,
      timestamp: Date.now(),
      isOpen: true,
    }));
  } catch (error) {
    console.error(`Failed to fetch positions for ${address}:`, error);
    return [];
  }
};

// Check if a trader is a whale based on current positions
export const detectWhale = async (trader: Trader, config: WhaleConfig): Promise<boolean> => {
  const positions = await fetchUserPositions(trader.address);
  
  // Check position values
  for (const position of positions) {
    const positionValue = position.szi * position.markPx;
    if (positionValue >= config.minPositionValue) {
      trader.currentPositions = positions;
      return true;
    }
  }

  // Check if volume qualifies as whale
  if (trader.volume >= config.minVolume) {
    trader.currentPositions = positions;
    return true;
  }

  return false;
};

// Fetch all whale traders
export const fetchWhaleTraders = async (config: WhaleConfig = WHALE_CONFIG): Promise<Trader[]> => {
  const allTraders = await fetchTopTraders();
  const whalePromises = allTraders.map(trader => detectWhale(trader, config));
  const whaleResults = await Promise.all(whalePromises);
  
  return allTraders.filter((_, index) => whaleResults[index]);
};

// Get market statistics
export const fetchMarketStats = async (): Promise<MarketStat[]> => {
  try {
    const cacheKey = "marketStats";
    const cached = cache.get(cacheKey);
    
    if (cached && Date.now() - cached.timestamp < CACHE_TTL) {
      return cached.data;
    }

    // Fetch all perps info
    const response = await axios.post(`${HYPERLIQUID_API}/info`, {
      type: "meta",
    });

    const coins = response.data.universe.map((u: any) => u.name);
    const statsPromises = coins.map(async (coin: string) => {
      // Get recent trades for this coin
      const tradesResponse = await axios.post(`${HYPERLIQUID_API}/info`, {
        type: "candleSnapshot",
        req: {
          coin: coin,
          interval: "1m",
          startTime: Date.now() - 3600000, // Last hour
        },
      });

      const trades = tradesResponse.data || [];
      const totalVolume = trades.reduce((acc: number, t: any) => acc + (t.v || 0), 0);
      
      return {
        coin,
        totalVolume,
        tradeCount: trades.length,
        longPositions: 0, // Would need to fetch order book for this
        shortPositions: 0,
        topTraders: [],
      };
    });

    const stats = await Promise.all(statsPromises);
    cache.set(cacheKey, { data: stats, timestamp: Date.now() });
    return stats;
  } catch (error) {
    console.error("Failed to fetch market stats:", error);
    return [];
  }
};

// WebSocket connection for real-time updates
export const connectWebSocket = (callback: (update: RealTimeUpdate) => void): void => {
  wsCallbacks.push(callback);

  if (ws) return;

  ws = io(HYPERLIQUID_WS, {
    transports: ["websocket"],
    reconnection: true,
    reconnectionAttempts: 5,
    reconnectionDelay: 1000,
  });

  ws.on("connect", () => {
    console.log("Connected to HyperLiquid WebSocket");
    
    // Subscribe to position updates
    ws?.emit("subscribe", { type: "positionUpdates" });
  });

  ws.on("positionUpdate", (data: any) => {
    const update: RealTimeUpdate = {
      type: data.event === "open" ? "position_open" : data.event === "close" ? "position_close" : "position_update",
      data: {
        id: data.id,
        coin: data.coin,
        side: data.side,
        szi: data.size,
        entryPx: data.entryPrice,
        markPx: data.markPrice,
        unrealizedPnl: data.unrealizedPnl || 0,
        marginUsed: data.marginUsed,
        leverage: data.leverage,
        timestamp: Date.now(),
        isOpen: data.event !== "close",
        closedAt: data.event === "close" ? Date.now() : undefined,
        realizedPnl: data.realizedPnl,
      },
      timestamp: Date.now(),
    };

    wsCallbacks.forEach(cb => cb(update));
  });

  ws.on("disconnect", () => {
    console.log("Disconnected from HyperLiquid WebSocket");
  });

  ws.on("error", (error) => {
    console.error("WebSocket error:", error);
  });
};

export const disconnectWebSocket = (): void => {
  if (ws) {
    ws.disconnect();
    ws = null;
    wsCallbacks = [];
  }
};

// Mock data generator for demo purposes
const generateMockTraders = (count: number): Trader[] => {
  return Array.from({ length: count }).map((_, index) => {
    return {
      rank: index + 1,
      address: `0x${Math.random().toString(16).substr(2, 40)}`,
      pnl: Math.floor(Math.random() * 1000000) * (Math.random() > 0.3 ? 1 : -0.2),
      roi: Math.floor(Math.random() * 500),
      volume: Math.floor(Math.random() * 10000000),
      winRate: Math.floor(Math.random() * 40) + 60,
      trades: Math.floor(Math.random() * 1000),
      currentPositions: [],
      isMock: true,
    };
  });
};
