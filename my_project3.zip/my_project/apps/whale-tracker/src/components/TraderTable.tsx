import React, { useState } from 'react';
import { Trader } from '../types/trader';
import { Copy, Trophy, Activity } from 'lucide-react';

interface TraderTableProps {
  traders: Trader[];
  selectedTraders: Set<string>;
  onToggleSelect: (address: string) => void;
  onSelectAll: (select: boolean) => void;
}

export const TraderTable: React.FC<TraderTableProps> = ({ 
  traders, 
  selectedTraders, 
  onToggleSelect,
  onSelectAll 
}) => {
  const [expanded, setExpanded] = useState<Set<string>>(new Set());
  const allSelected = traders.length > 0 && selectedTraders.size === traders.length;

  const toggleExpand = (address: string) => {
    const newExpanded = new Set(expanded);
    if (newExpanded.has(address)) newExpanded.delete(address);
    else newExpanded.add(address);
    setExpanded(newExpanded);
  };

  const formatCurrency = (val: number) => {
    return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: 0 }).format(val);
  };

  const formatPercentage = (val: number) => {
    return `${val}%`;
  };

  const truncateAddress = (address: string) => {
    return `${address.slice(0, 6)}...${address.slice(-4)}`;
  };

  return (
    <div className="bg-gray-800 rounded-xl border border-gray-700 shadow-xl overflow-hidden">
      <div className="overflow-x-auto">
        <table className="w-full text-left text-sm text-gray-400">
          <thead className="bg-gray-900 text-gray-200 uppercase font-medium">
            <tr>
              <th className="px-6 py-4 w-4">
                <input 
                  type="checkbox" 
                  checked={allSelected}
                  onChange={(e) => onSelectAll(e.target.checked)}
                  className="rounded border-gray-600 bg-gray-700 text-blue-500 focus:ring-blue-500 focus:ring-offset-gray-900"
                />
              </th>
              <th className="px-6 py-4">Rank</th>
              <th className="px-6 py-4">Trader</th>
              <th className="px-6 py-4 text-right">PnL (Total)</th>
              <th className="px-6 py-4 text-right">ROI</th>
              <th className="px-6 py-4 text-right">Win Rate</th>
              <th className="px-6 py-4 text-right">Volume</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-700">
            {traders.map((trader) => (
              <React.Fragment key={trader.address}>
              <tr 
                className={`hover:bg-gray-750 transition-colors cursor-pointer ${selectedTraders.has(trader.address) ? 'bg-blue-900/10' : ''}`}
                onClick={() => toggleExpand(trader.address)}
              >
                <td className="px-6 py-4" onClick={(e) => e.stopPropagation()}>
                  <input 
                    type="checkbox" 
                    checked={selectedTraders.has(trader.address)}
                    onChange={() => onToggleSelect(trader.address)}
                    className="rounded border-gray-600 bg-gray-700 text-blue-500 focus:ring-blue-500 focus:ring-offset-gray-900"
                  />
                </td>
                <td className="px-6 py-4 font-medium text-white">
                  <div className="flex items-center gap-2">
                    {trader.rank <= 3 && <Trophy size={16} className="text-yellow-500" />}
                    #{trader.rank}
                  </div>
                </td>
                <td className="px-6 py-4">
                  <div className="flex items-center gap-2 group cursor-pointer" title={trader.address}>
                    <span className="font-mono text-gray-300">{truncateAddress(trader.address)}</span>
                    <Copy size={14} className="opacity-0 group-hover:opacity-100 transition-opacity" />
                  </div>
                </td>
                <td className={`px-6 py-4 text-right font-medium ${trader.pnl >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                  {trader.pnl >= 0 ? '+' : ''}{formatCurrency(trader.pnl)}
                </td>
                <td className="px-6 py-4 text-right text-white">
                  {formatPercentage(trader.roi)}
                </td>
                <td className="px-6 py-4 text-right">
                  <div className="flex items-center justify-end gap-2">
                    <div className="w-16 h-1.5 bg-gray-700 rounded-full overflow-hidden">
                      <div 
                        className="h-full bg-blue-500" 
                        style={{ width: `${trader.winRate}%` }}
                      />
                    </div>
                    <span>{trader.winRate}%</span>
                  </div>
                </td>
                <td className="px-6 py-4 text-right text-white">
                  {formatCurrency(trader.volume)}
                </td>
              </tr>
              {expanded.has(trader.address) && (
                <tr className="bg-gray-900/50">
                  <td colSpan={7} className="px-6 py-6 border-t border-gray-700">
                    <div className="bg-gray-800 rounded-lg p-4 border border-gray-700">
                      <h4 className="text-white font-medium mb-3 flex items-center gap-2">
                        <Activity size={16} className="text-blue-400" />
                        Open Positions Detail (Buy/Sell Split)
                      </h4>
                      {trader.currentPositions && trader.currentPositions.length > 0 ? (
                        <div className="grid grid-cols-2 gap-4">
                          <div className="space-y-2">
                            <h5 className="text-sm font-semibold text-green-400 border-b border-gray-700 pb-2">Long (Buy) Positions</h5>
                            {trader.currentPositions.filter(p => p.side === 'long').map((pos, idx) => (
                              <div key={idx} className="flex justify-between text-sm text-gray-300">
                                <span>{pos.coin}</span>
                                <span>{new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(pos.szi * pos.markPx)}</span>
                              </div>
                            ))}
                            {trader.currentPositions.filter(p => p.side === 'long').length === 0 && <span className="text-xs text-gray-500">No open Longs</span>}
                          </div>
                          <div className="space-y-2">
                            <h5 className="text-sm font-semibold text-red-400 border-b border-gray-700 pb-2">Short (Sell) Positions</h5>
                            {trader.currentPositions.filter(p => p.side === 'short').map((pos, idx) => (
                              <div key={idx} className="flex justify-between text-sm text-gray-300">
                                <span>{pos.coin}</span>
                                <span>{new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(pos.szi * pos.markPx)}</span>
                              </div>
                            ))}
                            {trader.currentPositions.filter(p => p.side === 'short').length === 0 && <span className="text-xs text-gray-500">No open Shorts</span>}
                          </div>
                        </div>
                      ) : (
                        <div className="text-sm text-gray-500 text-center py-4">No public open positions found.</div>
                      )}
                    </div>
                  </td>
                </tr>
              )}
              </React.Fragment>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};
