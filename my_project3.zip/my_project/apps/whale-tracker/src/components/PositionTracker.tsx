import React, { useState, useEffect } from 'react';
import { connectWebSocket, disconnectWebSocket } from '../services/api';
import { RealTimeUpdate } from '../types/trader';
import { Activity, TrendingUp, TrendingDown, Clock, DollarSign } from 'lucide-react';
import { format } from 'date-fns';

export const PositionTracker: React.FC = () => {
  const [updates, setUpdates] = useState<RealTimeUpdate[]>([]);
  const [connected, setConnected] = useState(false);

  useEffect(() => {
    // Initialize WebSocket connection
    connectWebSocket((update: RealTimeUpdate) => {
      setUpdates(prev => [update, ...prev].slice(0, 50)); // Keep last 50 updates
    });

    setConnected(true);

    // Simulate some mock real-time updates for demo
    const mockInterval = setInterval(() => {
      const mockUpdate: RealTimeUpdate = {
        type: Math.random() > 0.7 ? 'position_close' : 'position_open',
        data: {
          id: `mock-${Date.now()}`,
          coin: ['BTC', 'ETH', 'SOL', 'ARB', 'OP'][Math.floor(Math.random() * 5)],
          side: Math.random() > 0.5 ? 'long' : 'short',
          szi: Math.random() * 10,
          entryPx: Math.random() * 50000,
          markPx: Math.random() * 50000,
          unrealizedPnl: (Math.random() - 0.5) * 10000,
          marginUsed: Math.random() * 50000,
          leverage: Math.floor(Math.random() * 10) + 1,
          timestamp: Date.now(),
          isOpen: Math.random() > 0.7 ? false : true,
        },
        timestamp: Date.now(),
      };
      
      // Only add mock data if no real data is coming through
      if (updates.length < 5) {
        setUpdates(prev => [mockUpdate, ...prev].slice(0, 50));
      }
    }, 5000);

    return () => {
      disconnectWebSocket();
      clearInterval(mockInterval);
    };
  }, []);

  const formatCurrency = (val: number) => {
    return new Intl.NumberFormat('en-US', { 
      style: 'currency', 
      currency: 'USD', 
      maximumFractionDigits: 0 
    }).format(val);
  };

  const formatTime = (timestamp: number) => {
    return format(timestamp, 'HH:mm:ss');
  };

  const getUpdateColor = (type: RealTimeUpdate['type']) => {
    switch (type) {
      case 'position_open': return 'text-green-400 border-green-500/30 bg-green-900/20';
      case 'position_close': return 'text-red-400 border-red-500/30 bg-red-900/20';
      case 'position_update': return 'text-blue-400 border-blue-500/30 bg-blue-900/20';
      default: return 'text-gray-400 border-gray-500/30 bg-gray-900/20';
    }
  };

  const getUpdateIcon = (type: RealTimeUpdate['type']) => {
    switch (type) {
      case 'position_open': return <TrendingUp size={16} />;
      case 'position_close': return <TrendingDown size={16} />;
      case 'position_update': return <Activity size={16} />;
      default: return <Activity size={16} />;
    }
  };

  return (
    <div className="space-y-6">
      {/* Connection Status */}
      <div className="bg-gray-800 rounded-xl border border-gray-700 p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className={`p-2 rounded-full ${connected ? 'bg-green-900/30' : 'bg-red-900/30'}`}>
              <Activity size={18} className={connected ? 'text-green-400' : 'text-red-400'} />
            </div>
            <div>
              <div className="text-white font-medium">
                {connected ? 'Real-Time Tracking Active' : 'Connecting...'}
              </div>
              <div className="text-sm text-gray-400">
                Live position updates from HyperLiquid
              </div>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <div className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-green-500"></span>
            </div>
            <span className="text-sm text-green-400">Live</span>
          </div>
        </div>
      </div>

      {/* Position Updates Feed */}
      <div className="bg-gray-800 rounded-xl border border-gray-700 shadow-xl overflow-hidden">
        <div className="px-6 py-4 border-b border-gray-700 flex justify-between items-center">
          <h3 className="text-lg font-semibold text-white">Live Position Updates</h3>
          <div className="flex items-center gap-2 text-sm text-gray-400">
            <Clock size={14} />
            Last 50 updates
          </div>
        </div>
        
        <div className="max-h-96 overflow-y-auto">
          {updates.length === 0 ? (
            <div className="p-8 text-center text-gray-500">
              <Activity size={32} className="mx-auto mb-2 opacity-50" />
              <p>Waiting for position updates...</p>
            </div>
          ) : (
            <div className="divide-y divide-gray-700">
              {updates.map((update) => (
                <div key={update.data.id + update.timestamp} className="p-4 hover:bg-gray-750 transition-colors">
                  <div className="flex items-start justify-between">
                    <div className="flex items-start gap-3 flex-1">
                      <div className={`p-2 rounded-lg ${getUpdateColor(update.type).split(' ')[1]} ${getUpdateColor(update.type).split(' ')[2]}`}>
                        {getUpdateIcon(update.type)}
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <span className="font-medium text-white">
                            {update.data.coin} Perpetual
                          </span>
                          <span className={`text-xs px-2 py-0.5 rounded ${update.data.side === 'long' ? 'bg-green-600' : 'bg-red-600'} text-white`}>
                            {update.data.side.toUpperCase()}
                          </span>
                          <span className={`text-xs px-2 py-0.5 rounded ${getUpdateColor(update.type).split(' ')[1]} ${getUpdateColor(update.type).split(' ')[2]}`}>
                            {update.type.replace('_', ' ').toUpperCase()}
                          </span>
                        </div>
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-sm text-gray-400">
                          <div className="flex items-center gap-1">
                            <DollarSign size={12} />
                            <span>Size: {update.data.szi.toFixed(3)}</span>
                          </div>
                          <div>
                            Entry: {formatCurrency(update.data.entryPx)}
                          </div>
                          <div>
                            Mark: {formatCurrency(update.data.markPx)}
                          </div>
                          <div>
                            Lev: {update.data.leverage}x
                          </div>
                        </div>
                        {update.type !== 'position_close' && (
                          <div className="mt-2">
                            <span className={`text-sm font-medium ${update.data.unrealizedPnl >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                              Unrealized PnL: {update.data.unrealizedPnl >= 0 ? '+' : ''}{formatCurrency(update.data.unrealizedPnl)}
                            </span>
                          </div>
                        )}
                        {update.type === 'position_close' && update.data.realizedPnl !== undefined && (
                          <div className="mt-2">
                            <span className={`text-sm font-medium ${update.data.realizedPnl >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                              Realized PnL: {update.data.realizedPnl >= 0 ? '+' : ''}{formatCurrency(update.data.realizedPnl)}
                            </span>
                          </div>
                        )}
                      </div>
                    </div>
                    <div className="text-xs text-gray-500 ml-4">
                      {formatTime(update.timestamp)}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Summary Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-gray-900 rounded-lg p-4 border border-gray-700">
          <div className="flex items-center gap-2 text-green-400 mb-1">
            <TrendingUp size={16} />
            <span className="text-sm">Opened</span>
          </div>
          <div className="text-2xl font-bold text-white">
            {updates.filter(u => u.type === 'position_open').length}
          </div>
        </div>
        <div className="bg-gray-900 rounded-lg p-4 border border-gray-700">
          <div className="flex items-center gap-2 text-red-400 mb-1">
            <TrendingDown size={16} />
            <span className="text-sm">Closed</span>
          </div>
          <div className="text-2xl font-bold text-white">
            {updates.filter(u => u.type === 'position_close').length}
          </div>
        </div>
        <div className="bg-gray-900 rounded-lg p-4 border border-gray-700">
          <div className="flex items-center gap-2 text-blue-400 mb-1">
            <Activity size={16} />
            <span className="text-sm">Updated</span>
          </div>
          <div className="text-2xl font-bold text-white">
            {updates.filter(u => u.type === 'position_update').length}
          </div>
        </div>
      </div>
    </div>
  );
};