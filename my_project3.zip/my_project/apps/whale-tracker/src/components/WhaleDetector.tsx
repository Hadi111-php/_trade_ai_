import React, { useState, useEffect } from 'react';
import { Fish, TrendingUp, DollarSign, Activity, Download } from 'lucide-react';
import { fetchWhaleTraders, WHALE_CONFIG } from '../services/api';
import { Trader } from '../types/trader';
import { StatsCard } from './StatsCard';
import { downloadTraders } from '../utils/export';

interface WhaleDetectorProps {
  whaleThreshold: number;
}

export const WhaleDetector: React.FC<WhaleDetectorProps> = ({ whaleThreshold }) => {
  const [whales, setWhales] = useState<Trader[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedWhales, setSelectedWhales] = useState<Set<string>>(new Set());

  useEffect(() => {
    const loadWhales = async () => {
      setLoading(true);
      try {
        const whaleConfig = { ...WHALE_CONFIG, minPositionValue: whaleThreshold };
        const data = await fetchWhaleTraders(whaleConfig);
        setWhales(data);
      } catch (err) {
        console.error("Failed to load whales", err);
      } finally {
        setLoading(false);
      }
    };
    loadWhales();
  }, [whaleThreshold]);

  const handleToggleSelect = (address: string) => {
    const newSelected = new Set(selectedWhales);
    if (newSelected.has(address)) {
      newSelected.delete(address);
    } else {
      newSelected.add(address);
    }
    setSelectedWhales(newSelected);
  };

  const handleSelectAll = (select: boolean) => {
    if (select) {
      setSelectedWhales(new Set(whales.map(w => w.address)));
    } else {
      setSelectedWhales(new Set());
    }
  };

  const handleExport = () => {
    const selectedData = whales.filter(w => selectedWhales.has(w.address));
    downloadTraders(selectedData);
  };

  const totalWhaleVolume = whales.reduce((acc, curr) => acc + curr.volume, 0);
  const totalPositions = whales.reduce((acc, curr) => acc + (curr.currentPositions?.length || 0), 0);
  const avgPositionSize = totalPositions > 0 ? totalWhaleVolume / totalPositions : 0;

  const formatCurrency = (val: number) => {
    return new Intl.NumberFormat('en-US', { 
      style: 'currency', 
      currency: 'USD', 
      maximumFractionDigits: 0 
    }).format(val);
  };

  const truncateAddress = (address: string) => {
    return `${address.slice(0, 6)}...${address.slice(-4)}`;
  };

  return (
    <div className="space-y-6">
      {/* Whale Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <StatsCard 
          title="Whale Traders" 
          value={whales.length.toString()}
          trend="Live"
          isPositive={true}
          icon={<Fish size={20} />}
        />
        <StatsCard 
          title="Total Whale Volume" 
          value={formatCurrency(totalWhaleVolume)}
          trend="Active"
          isPositive={true}
          icon={<DollarSign size={20} />}
        />
        <StatsCard 
          title="Avg Position Size" 
          value={formatCurrency(avgPositionSize)}
          trend="Large Cap"
          isPositive={true}
          icon={<TrendingUp size={20} />}
        />
      </div>

      {/* Whale Table */}
      <div className="bg-gray-800 rounded-xl border border-gray-700 shadow-xl overflow-hidden">
        <div className="px-6 py-4 border-b border-gray-700 flex justify-between items-center">
          <h3 className="text-lg font-semibold text-white">Whale Traders (≥ {formatCurrency(whaleThreshold)})</h3>
          <div className="flex items-center gap-2 text-sm text-gray-400">
            <Activity size={14} className="text-green-400" />
            Real-time tracking
          </div>
        </div>
        
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm text-gray-400">
            <thead className="bg-gray-900 text-gray-200 uppercase font-medium">
              <tr>
                <th className="px-6 py-4 w-4">
                  <input 
                    type="checkbox" 
                    checked={whales.length > 0 && selectedWhales.size === whales.length}
                    onChange={(e) => handleSelectAll(e.target.checked)}
                    className="rounded border-gray-600 bg-gray-700 text-blue-500 focus:ring-blue-500 focus:ring-offset-gray-900"
                  />
                </th>
                <th className="px-6 py-4">Trader</th>
                <th className="px-6 py-4 text-right">Volume</th>
                <th className="px-6 py-4 text-right">Open Positions</th>
                <th className="px-6 py-4 text-right">Total PnL</th>
                <th className="px-6 py-4">Largest Position</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-700">
              {loading ? (
                <tr>
                  <td colSpan={6} className="px-6 py-8">
                    <div className="flex flex-col items-center justify-center text-gray-500">
                      <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-500 mb-2"></div>
                      <p>Scanning for whales...</p>
                    </div>
                  </td>
                </tr>
              ) : whales.length === 0 ? (
                <tr>
                  <td colSpan={6} className="px-6 py-8 text-center text-gray-500">
                    No whale traders found with current threshold
                  </td>
                </tr>
              ) : (
                whales.map((whale) => {
                  const largestPosition = whale.currentPositions?.reduce((max, pos) => {
                    const posValue = pos.szi * pos.markPx;
                    const maxValue = max ? max.szi * max.markPx : 0;
                    return posValue > maxValue ? pos : max;
                  }, null as any);

                  return (
                    <tr 
                      key={whale.address} 
                      className={`hover:bg-gray-750 transition-colors ${selectedWhales.has(whale.address) ? 'bg-blue-900/10' : ''}`}
                    >
                      <td className="px-6 py-4">
                        <input 
                          type="checkbox" 
                          checked={selectedWhales.has(whale.address)}
                          onChange={() => handleToggleSelect(whale.address)}
                          className="rounded border-gray-600 bg-gray-700 text-blue-500 focus:ring-blue-500 focus:ring-offset-gray-900"
                        />
                      </td>
                      <td className="px-6 py-4">
                        <div className="space-y-1">
                          <div className="flex items-center gap-2 group cursor-pointer" title={whale.address}>
                            <span className="font-mono text-white font-medium">{truncateAddress(whale.address)}</span>
                          </div>
                          <div className="text-xs text-gray-500">
                            Rank #{whale.rank} • {whale.trades} trades
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-4 text-right text-white font-medium">
                        {formatCurrency(whale.volume)}
                      </td>
                      <td className="px-6 py-4 text-right">
                        <span className="bg-blue-600 text-white px-2 py-1 rounded-full text-xs font-medium">
                          {whale.currentPositions?.length || 0}
                        </span>
                      </td>
                      <td className={`px-6 py-4 text-right font-medium ${whale.pnl >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                        {whale.pnl >= 0 ? '+' : ''}{formatCurrency(whale.pnl)}
                      </td>
                      <td className="px-6 py-4">
                        {largestPosition ? (
                          <div className="space-y-1">
                            <div className="flex items-center gap-2">
                              <span className="text-white font-medium">{largestPosition.coin}</span>
                              <span className={`text-xs px-2 py-0.5 rounded ${largestPosition.side === 'long' ? 'bg-green-600' : 'bg-red-600'} text-white`}>
                                {largestPosition.side.toUpperCase()}
                              </span>
                            </div>
                            <div className="text-xs text-gray-500">
                              {formatCurrency(largestPosition.szi * largestPosition.markPx)}
                            </div>
                          </div>
                        ) : (
                          <span className="text-gray-500">No positions</span>
                        )}
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Export Button */}
      {selectedWhales.size > 0 && (
        <div className="flex justify-end">
          <button 
            onClick={handleExport}
            className="flex items-center gap-2 bg-green-600 hover:bg-green-500 text-white px-6 py-2 rounded-lg font-medium transition-colors shadow-lg shadow-green-900/20"
          >
            <Download size={18} />
            Export Whale Wallets ({selectedWhales.size})
          </button>
        </div>
      )}
    </div>
  );
};